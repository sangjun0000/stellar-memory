#!/usr/bin/env bash
set -e

echo ""
echo "  ╔═══════════════════════════════════════╗"
echo "  ║     Homunculus Installer v0.5.0       ║"
echo "  ╚═══════════════════════════════════════╝"
echo ""

# Step 0: Check Python
if ! command -v python3 &>/dev/null; then
    echo "  [ERROR] Python 3 not found."
    echo "  Install: https://python.org or 'brew install python3'"
    exit 1
fi

PYVER=$(python3 --version 2>&1 | awk '{print $2}')
echo "  Python ${PYVER} found."

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "${SCRIPT_DIR}/src/homunculus/installer.py" "${SCRIPT_DIR}"

echo ""
echo "  Installation complete!"
