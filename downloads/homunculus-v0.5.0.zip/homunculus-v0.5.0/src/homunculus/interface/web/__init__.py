"""Homunculus Web UI package."""

from homunculus.interface.web.server import WebServer

__all__ = ["WebServer"]
