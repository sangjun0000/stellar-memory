"""ShellTool — executes shell commands via asyncio subprocesses.

Risk level is HIGH because arbitrary shell access can affect the host system.
The BLOCKED_COMMANDS list and the configurable timeout are the primary safety
controls; the SafetyLayer provides the second line of defence.
"""

from __future__ import annotations

import asyncio
import logging
import shlex
from typing import Any

from homunculus.core.types import ActionRisk, ToolDefinition, ToolResult

logger = logging.getLogger(__name__)

# Commands (or prefixes) that are unconditionally refused regardless of safety
# level.  Populated from config at instantiation time so the list can be
# extended via homunculus.toml without touching this file.
_DEFAULT_BLOCKED: list[str] = [
    "rm -rf /",
    "rm -rf /*",
    "format",
    "mkfs",
    "dd if=/dev/zero",
    "shutdown",
    "reboot",
    "> /dev/sda",
]

_DEFINITION = ToolDefinition(
    name="shell",
    display_name="Shell Command",
    description=(
        "Execute a shell command on the host system and return its stdout/stderr. "
        "Use only when no safer tool can accomplish the task."
    ),
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
            "timeout": {
                "type": "integer",
                "description": "Maximum execution time in seconds (default 30).",
                "default": 30,
            },
        },
        "required": ["command"],
    },
    risk_level=ActionRisk.HIGH,
    enabled=True,
    version="1.0.0",
    author="homunculus",
)

# Maximum bytes captured from stdout/stderr to avoid memory exhaustion.
_MAX_OUTPUT_BYTES = 1024 * 64  # 64 KB


class ShellTool:
    """Run shell commands with safety guardrails.

    The tool is intentionally conservative: it refuses blocked commands, caps
    execution time, and truncates large outputs.  The constructor accepts an
    optional ``blocked_commands`` list (from Settings) so operators can extend
    the defaults via configuration.
    """

    def __init__(
        self,
        blocked_commands: list[str] | None = None,
        default_timeout: int = 30,
    ) -> None:
        self._blocked: list[str] = (
            list(blocked_commands) if blocked_commands is not None else list(_DEFAULT_BLOCKED)
        )
        self._default_timeout = default_timeout

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        command = parameters.get("command", "")
        if not isinstance(command, str) or not command.strip():
            logger.warning("ShellTool.validate: 'command' is missing or empty.")
            return False
        if self._is_blocked(command):
            logger.warning("ShellTool.validate: command blocked — '%s'", command)
            return False
        timeout = parameters.get("timeout", self._default_timeout)
        if not isinstance(timeout, int) or timeout <= 0:
            logger.warning("ShellTool.validate: invalid timeout '%s'.", timeout)
            return False
        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        command: str = parameters["command"].strip()
        timeout: int = int(parameters.get("timeout", self._default_timeout))

        # Double-check here in case execute() is called without validate().
        if self._is_blocked(command):
            return ToolResult(
                success=False,
                error=f"Command blocked by safety policy: '{command}'",
            )

        try:
            args = shlex.split(command, posix=True)
        except ValueError as exc:
            return ToolResult(success=False, error=f"Failed to parse command: {exc}")

        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            # Ensure the process is cleaned up on timeout.
            try:
                proc.kill()
                await proc.wait()
            except Exception:
                pass
            return ToolResult(
                success=False,
                error=f"Command timed out after {timeout}s: '{command}'",
            )
        except Exception as exc:
            return ToolResult(success=False, error=f"Subprocess error: {exc}")

        stdout = _decode_and_truncate(stdout_bytes)
        stderr = _decode_and_truncate(stderr_bytes)
        returncode = proc.returncode or 0

        success = returncode == 0
        output = stdout if stdout else stderr
        error = stderr if not success else ""

        logger.debug(
            "ShellTool executed '%s' → returncode=%d, output_len=%d",
            command,
            returncode,
            len(output),
        )
        return ToolResult(success=success, output=output, error=error)

    # ─── Private ───

    def _is_blocked(self, command: str) -> bool:
        lower = command.lower().strip()
        return any(lower.startswith(blocked.lower()) for blocked in self._blocked)


def _decode_and_truncate(raw: bytes) -> str:
    text = raw.decode("utf-8", errors="replace")
    if len(raw) >= _MAX_OUTPUT_BYTES:
        text = text[:_MAX_OUTPUT_BYTES] + "\n[output truncated]"
    return text
