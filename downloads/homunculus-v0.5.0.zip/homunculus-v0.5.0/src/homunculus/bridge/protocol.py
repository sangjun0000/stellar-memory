"""WebSocket message protocol v1.0 for Mobile Homunculus."""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# === Client → Server Message Types ===

class ClientMessageType(Enum):
    USER_INPUT = "user_input"
    COMMAND = "command"
    APPROVAL_RESPONSE = "approval_response"
    STATUS_REQUEST = "status_request"
    MEMORY_QUERY = "memory_query"
    PING = "ping"


# === Server → Client Message Types ===

class ServerMessageType(Enum):
    CHAT_RESPONSE = "chat_response"
    AGENT_STATE = "agent_state"
    CYCLE_UPDATE = "cycle_update"
    TOOL_EXECUTION = "tool_execution"
    APPROVAL_NEEDED = "approval_needed"
    COMMAND_RESULT = "command_result"
    STATUS_SNAPSHOT = "status_snapshot"
    MEMORY_RESULT = "memory_result"
    ERROR = "error"
    PONG = "pong"
    CONNECTION_ACK = "connection_ack"


# === Error Codes ===

class ErrorCode:
    AUTH_FAILED = "AUTH_FAILED"
    AUTH_EXPIRED = "AUTH_EXPIRED"
    INVALID_MESSAGE = "INVALID_MESSAGE"
    AGENT_BUSY = "AGENT_BUSY"
    AGENT_OFFLINE = "AGENT_OFFLINE"
    COMMAND_NOT_FOUND = "COMMAND_NOT_FOUND"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    RATE_LIMITED = "RATE_LIMITED"


# === Message Envelope ===

@dataclass
class Message:
    type: str
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""
    message_id: str = ""
    session_id: str | None = None

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        if not self.message_id:
            self.message_id = uuid.uuid4().hex[:12]

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @staticmethod
    def from_json(raw: str) -> Message:
        data = json.loads(raw)
        return Message(
            type=data.get("type", ""),
            payload=data.get("payload", {}),
            timestamp=data.get("timestamp", ""),
            message_id=data.get("message_id", ""),
            session_id=data.get("session_id"),
        )

    @staticmethod
    def parse_client_message(raw: str) -> Message | None:
        """Parse and validate a client message. Returns None if invalid."""
        try:
            msg = Message.from_json(raw)
            valid_types = {t.value for t in ClientMessageType}
            if msg.type not in valid_types:
                return None
            return msg
        except (json.JSONDecodeError, KeyError, TypeError):
            return None


# === Server Message Builders ===

def chat_response(
    content: str,
    role: str = "agent",
    cycle_id: str = "",
    is_streaming: bool = False,
    is_final: bool = True,
) -> Message:
    return Message(
        type=ServerMessageType.CHAT_RESPONSE.value,
        payload={
            "content": content,
            "role": role,
            "cycle_id": cycle_id,
            "is_streaming": is_streaming,
            "is_final": is_final,
        },
    )


def agent_state(state: str, previous_state: str, cycle_id: str = "") -> Message:
    return Message(
        type=ServerMessageType.AGENT_STATE.value,
        payload={
            "state": state,
            "previous_state": previous_state,
            "cycle_id": cycle_id,
        },
    )


def tool_execution(
    tool_name: str,
    action: str,
    status: str,
    description: str = "",
    output: str = "",
    error: str = "",
    risk_level: str = "safe",
    duration_ms: float = 0.0,
) -> Message:
    return Message(
        type=ServerMessageType.TOOL_EXECUTION.value,
        payload={
            "tool_name": tool_name,
            "action": action,
            "status": status,
            "description": description,
            "output": output,
            "error": error,
            "risk_level": risk_level,
            "duration_ms": duration_ms,
        },
    )


def approval_needed(
    plan_id: str,
    goal: str,
    estimated_risk: str,
    steps: list[dict[str, str]],
) -> Message:
    return Message(
        type=ServerMessageType.APPROVAL_NEEDED.value,
        payload={
            "plan_id": plan_id,
            "goal": goal,
            "estimated_risk": estimated_risk,
            "steps": steps,
        },
    )


def status_snapshot(
    agent_state_val: str,
    model: dict[str, str],
    memory: dict[str, Any],
    tools: list[str],
    safety_level: str,
    personality: str,
    uptime_seconds: float,
) -> Message:
    return Message(
        type=ServerMessageType.STATUS_SNAPSHOT.value,
        payload={
            "agent_state": agent_state_val,
            "model": model,
            "memory": memory,
            "tools": tools,
            "safety_level": safety_level,
            "personality": personality,
            "uptime_seconds": uptime_seconds,
        },
    )


def memory_result(
    query: str,
    memories: list[dict[str, Any]],
    total_count: int,
) -> Message:
    return Message(
        type=ServerMessageType.MEMORY_RESULT.value,
        payload={
            "query": query,
            "memories": memories,
            "total_count": total_count,
        },
    )


def command_result(command: str, result: str) -> Message:
    return Message(
        type=ServerMessageType.COMMAND_RESULT.value,
        payload={
            "command": command,
            "result": result,
        },
    )


def error_message(code: str, message: str, details: dict[str, Any] | None = None) -> Message:
    return Message(
        type=ServerMessageType.ERROR.value,
        payload={
            "code": code,
            "message": message,
            "details": details or {},
        },
    )


def connection_ack(session_id: str, version: str = "0.5.0") -> Message:
    return Message(
        type=ServerMessageType.CONNECTION_ACK.value,
        payload={
            "session_id": session_id,
            "protocol_version": "1.0",
            "homunculus_version": version,
        },
    )


def pong() -> Message:
    return Message(type=ServerMessageType.PONG.value)
