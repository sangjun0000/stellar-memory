"""WebSocket Bridge Server connecting Mobile App to Homunculus Agent."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect
    from fastapi.responses import JSONResponse
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

from homunculus.bridge.auth import BridgeAuth
from homunculus.bridge.config import BridgeConfig
from homunculus.bridge.event_bridge import EventBridge
from homunculus.bridge import protocol

logger = logging.getLogger(__name__)


class BridgeServer:
    """WebSocket server bridging mobile clients to Homunculus Agent."""

    def __init__(self, agent: Any, config: BridgeConfig) -> None:
        if not HAS_FASTAPI:
            raise ImportError(
                "Bridge server requires fastapi and uvicorn. "
                "Install with: pip install 'homunculus[bridge]'"
            )

        self._agent = agent
        self._config = config
        self._app = FastAPI(title="Homunculus Bridge", docs_url=None, redoc_url=None)
        self._clients: dict[str, WebSocket] = {}
        self._auth = BridgeAuth(
            session_timeout=config.session_timeout,
            pairing_timeout=config.pairing_timeout,
            max_sessions=config.max_clients,
        )
        self._event_bridge = EventBridge(
            event_bus=agent.event_bus,
            broadcast=self._broadcast,
        )
        self._started_at: float = 0
        self._server_task: asyncio.Task[None] | None = None
        self._rate_counters: dict[str, list[float]] = {}

        self._setup_routes()

    # --- Route Setup ---

    def _setup_routes(self) -> None:
        app = self._app

        @app.websocket("/ws")
        async def websocket_endpoint(ws: WebSocket) -> None:
            await self._handle_websocket(ws)

        @app.get("/qr")
        async def generate_qr() -> JSONResponse:
            result = self._auth.generate_pairing(
                host=self._get_local_ip(),
                port=self._config.port,
            )
            return JSONResponse({
                "qr_data": result.qr_image_base64,
                "pairing_token": result.pairing_token,
                "connection_url": result.connection_url,
                "expires_at": result.expires_at,
            })

        @app.get("/health")
        async def health() -> JSONResponse:
            return JSONResponse({
                "status": "ok",
                "clients": len(self._clients),
                "uptime": round(time.time() - self._started_at, 1) if self._started_at else 0,
            })

    # --- Lifecycle ---

    async def start(self) -> None:
        """Start the bridge server in a background task."""
        import uvicorn

        self._started_at = time.time()
        self._event_bridge.subscribe_all()

        config = uvicorn.Config(
            app=self._app,
            host=self._config.host,
            port=self._config.port,
            log_level="warning",
            ws_max_size=self._config.message_max_size,
        )
        server = uvicorn.Server(config)

        self._server_task = asyncio.create_task(server.serve())
        logger.info(
            "Bridge server started on ws://%s:%d",
            self._config.host,
            self._config.port,
        )

    async def stop(self) -> None:
        """Stop the bridge server and disconnect all clients."""
        self._event_bridge.unsubscribe_all()

        for session_id, ws in list(self._clients.items()):
            try:
                await ws.close(code=1001, reason="Server shutting down")
            except Exception:
                pass
        self._clients.clear()

        if self._server_task and not self._server_task.done():
            self._server_task.cancel()
            try:
                await self._server_task
            except asyncio.CancelledError:
                pass

        logger.info("Bridge server stopped")

    @property
    def is_running(self) -> bool:
        return self._server_task is not None and not self._server_task.done()

    @property
    def client_count(self) -> int:
        return len(self._clients)

    @property
    def port(self) -> int:
        return self._config.port

    # --- WebSocket Handler ---

    async def _handle_websocket(self, ws: WebSocket) -> None:
        await ws.accept()
        session_id = ""

        try:
            # Step 1: Authenticate
            auth_msg = await asyncio.wait_for(ws.receive_text(), timeout=30.0)
            parsed = protocol.Message.parse_client_message(auth_msg)

            if parsed is None:
                await self._send_error(ws, protocol.ErrorCode.INVALID_MESSAGE, "Invalid auth message")
                await ws.close(code=4001)
                return

            # Expect first message to contain pairing_token or session_token
            payload = parsed.payload
            pairing_token = payload.get("pairing_token", "")
            session_token = payload.get("session_token", "")

            if pairing_token:
                if not self._auth.validate_pairing_token(pairing_token):
                    await self._send_error(ws, protocol.ErrorCode.AUTH_FAILED, "Invalid pairing token")
                    await ws.close(code=4001)
                    return
                device_info = payload.get("device_info", {})
                session_id, token = self._auth.create_session(device_info)
            elif session_token:
                session = self._auth.validate_session(session_token)
                if session is None:
                    await self._send_error(ws, protocol.ErrorCode.AUTH_EXPIRED, "Session expired")
                    await ws.close(code=4001)
                    return
                session_id = session.session_id
                token = session_token
            else:
                await self._send_error(ws, protocol.ErrorCode.AUTH_FAILED, "No auth credentials")
                await ws.close(code=4001)
                return

            # Step 2: Register client
            self._clients[session_id] = ws
            self._rate_counters[session_id] = []
            logger.info("Client connected: %s", session_id)

            # Step 3: Send connection acknowledgement
            ack = protocol.connection_ack(session_id=session_id)
            ack.payload["session_token"] = token
            await ws.send_text(ack.to_json())

            # Step 4: Send initial status snapshot
            snapshot = await self._build_status_snapshot()
            await ws.send_text(snapshot.to_json())

            # Step 5: Message loop
            await self._message_loop(ws, session_id)

        except WebSocketDisconnect:
            logger.info("Client disconnected: %s", session_id or "unauthenticated")
        except asyncio.TimeoutError:
            logger.warning("Client auth timeout")
            try:
                await ws.close(code=4002)
            except Exception:
                pass
        except Exception as e:
            logger.error("WebSocket error: %s", e)
        finally:
            if session_id:
                self._clients.pop(session_id, None)
                self._rate_counters.pop(session_id, None)

    async def _message_loop(self, ws: WebSocket, session_id: str) -> None:
        """Main message processing loop for an authenticated client."""
        while True:
            raw = await ws.receive_text()
            msg = protocol.Message.parse_client_message(raw)

            if msg is None:
                await self._send_error(
                    ws, protocol.ErrorCode.INVALID_MESSAGE, "Cannot parse message"
                )
                continue

            # Rate limiting
            if not self._check_rate_limit(session_id):
                await self._send_error(
                    ws, protocol.ErrorCode.RATE_LIMITED, "Too many messages"
                )
                continue

            msg.session_id = session_id

            # Route by message type
            if msg.type == protocol.ClientMessageType.USER_INPUT.value:
                await self._handle_user_input(session_id, msg.payload)

            elif msg.type == protocol.ClientMessageType.COMMAND.value:
                await self._handle_command(session_id, msg.payload)

            elif msg.type == protocol.ClientMessageType.APPROVAL_RESPONSE.value:
                await self._handle_approval_response(session_id, msg.payload)

            elif msg.type == protocol.ClientMessageType.STATUS_REQUEST.value:
                await self._handle_status_request(session_id)

            elif msg.type == protocol.ClientMessageType.MEMORY_QUERY.value:
                await self._handle_memory_query(session_id, msg.payload)

            elif msg.type == protocol.ClientMessageType.PING.value:
                pong_msg = protocol.pong()
                await ws.send_text(pong_msg.to_json())

    # --- Message Handlers ---

    async def _handle_user_input(self, session_id: str, payload: dict[str, Any]) -> None:
        content = payload.get("content", "").strip()
        if not content:
            return
        await self._agent.handle_message(content, source="mobile")

    async def _handle_command(self, session_id: str, payload: dict[str, Any]) -> None:
        command = payload.get("command", "").strip()
        if not command:
            return

        from homunculus.interface.commands import handle_command

        result = await handle_command(self._agent, command)
        if result is not None:
            msg = protocol.command_result(command=command, result=result)
            await self._send_to(session_id, msg)

    async def _handle_approval_response(
        self, session_id: str, payload: dict[str, Any]
    ) -> None:
        approved = payload.get("approved", False)
        plan_id = payload.get("plan_id", "")
        logger.info(
            "Approval response: plan=%s approved=%s from=%s",
            plan_id, approved, session_id,
        )
        # Approval mechanism integration point
        # The agent's approval flow will be connected here
        self._agent.event_bus.emit(
            "approval_response",
            {"plan_id": plan_id, "approved": approved, "source": "mobile"},
        )

    async def _handle_status_request(self, session_id: str) -> None:
        snapshot = await self._build_status_snapshot()
        await self._send_to(session_id, snapshot)

    async def _handle_memory_query(
        self, session_id: str, payload: dict[str, Any]
    ) -> None:
        query = payload.get("query", "")
        limit = min(payload.get("limit", 10), 50)
        include_graph = payload.get("include_graph", False)

        if not query:
            return

        try:
            memories = await self._agent.memory.recall(
                query=query,
                limit=limit,
                include_graph=include_graph,
            )
            stats = await self._agent.memory.stats()

            memories_data = []
            for mem in memories:
                memories_data.append({
                    "memory_id": getattr(mem, "memory_id", ""),
                    "content": getattr(mem, "content", ""),
                    "zone": getattr(mem, "zone", 0),
                    "score": round(getattr(mem, "score", 0.0), 3),
                    "emotion": getattr(mem, "emotion", {}),
                })

            msg = protocol.memory_result(
                query=query,
                memories=memories_data,
                total_count=stats.get("total", 0),
            )
            await self._send_to(session_id, msg)
        except Exception as e:
            logger.error("Memory query error: %s", e)
            await self._send_to(
                session_id,
                protocol.error_message(
                    protocol.ErrorCode.INTERNAL_ERROR, f"Memory query failed: {e}"
                ),
            )

    # --- Communication ---

    async def _broadcast(self, message: protocol.Message) -> None:
        """Send message to all connected clients."""
        if not self._clients:
            return
        data = message.to_json()
        disconnected = []
        for sid, ws in self._clients.items():
            try:
                await ws.send_text(data)
            except Exception:
                disconnected.append(sid)
        for sid in disconnected:
            self._clients.pop(sid, None)
            self._rate_counters.pop(sid, None)

    async def _send_to(self, session_id: str, message: protocol.Message) -> None:
        """Send message to a specific client."""
        ws = self._clients.get(session_id)
        if ws is None:
            return
        try:
            await ws.send_text(message.to_json())
        except Exception:
            self._clients.pop(session_id, None)

    async def _send_error(self, ws: WebSocket, code: str, message: str) -> None:
        """Send error message to a WebSocket."""
        msg = protocol.error_message(code, message)
        try:
            await ws.send_text(msg.to_json())
        except Exception:
            pass

    # --- Status Snapshot ---

    async def _build_status_snapshot(self) -> protocol.Message:
        """Build current agent status snapshot."""
        agent = self._agent

        # Model info
        model_info = agent.model_manager.active_model
        model_data = {
            "provider": getattr(model_info, "provider", "unknown"),
            "model_id": getattr(model_info, "model_id", "unknown"),
            "display_name": getattr(model_info, "display_name", "Unknown"),
        } if model_info else {"provider": "none", "model_id": "none", "display_name": "No Model"}

        # Memory stats
        try:
            mem_stats = await agent.memory.stats()
        except Exception:
            mem_stats = {"total": 0, "zones": {}}

        # Tools
        try:
            tool_defs = agent.tool_registry.list_all()
            tool_names = [
                getattr(t, "name", str(t))
                for t in tool_defs
                if getattr(t, "enabled", True)
            ]
        except Exception:
            tool_names = []

        # Agent state
        state = agent.state
        state_str = state.value if hasattr(state, "value") else str(state)

        uptime = time.time() - self._started_at if self._started_at else 0

        return protocol.status_snapshot(
            agent_state_val=state_str,
            model=model_data,
            memory=mem_stats,
            tools=tool_names,
            safety_level=agent.safety.safety_level,
            personality=agent.settings.personality_profile,
            uptime_seconds=round(uptime, 1),
        )

    # --- Rate Limiting ---

    def _check_rate_limit(self, session_id: str) -> bool:
        now = time.time()
        window = self._rate_counters.get(session_id, [])
        # Remove entries older than 60 seconds
        window = [t for t in window if now - t < 60]
        if len(window) >= self._config.rate_limit:
            self._rate_counters[session_id] = window
            return False
        window.append(now)
        self._rate_counters[session_id] = window
        return True

    # --- Utilities ---

    @staticmethod
    def _get_local_ip() -> str:
        """Get local IP address for QR code."""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def get_qr_terminal(self) -> str:
        """Generate QR code as terminal ASCII art."""
        return self._auth.generate_qr_terminal(
            host=self._get_local_ip(),
            port=self._config.port,
        )
