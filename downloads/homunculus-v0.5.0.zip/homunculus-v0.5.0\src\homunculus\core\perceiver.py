"""Perceiver - receives and queues incoming perceptions for the agent."""

from __future__ import annotations

import asyncio
import logging

from homunculus.core.types import Perception

logger = logging.getLogger(__name__)


class Perceiver:
    """Receives stimuli from the environment and queues them for the agent.

    Uses a priority queue so that high-priority perceptions (lower priority
    number, following asyncio.PriorityQueue convention) are processed first.
    Perception.priority 1 = highest urgency, 10 = lowest.
    """

    def __init__(self) -> None:
        # PriorityQueue entries are (priority, sequence, perception) tuples.
        # The sequence counter breaks ties and preserves insertion order among
        # equal-priority items, making the sort stable.
        self._queue: asyncio.PriorityQueue[tuple[int, int, Perception]] = (
            asyncio.PriorityQueue()
        )
        self._sequence: int = 0

    def push(self, perception: Perception) -> None:
        """Enqueue a perception.  Thread-safe from any coroutine context."""
        self._sequence += 1
        self._queue.put_nowait((perception.priority, self._sequence, perception))
        logger.debug(
            "Perceiver queued %s (priority=%d, qsize=%d)",
            perception.input_type.value,
            perception.priority,
            self._queue.qsize(),
        )

    async def next(self) -> Perception | None:
        """Return the highest-priority pending Perception, or None if empty.

        Non-blocking: returns immediately rather than waiting for input.
        """
        try:
            _, _, perception = self._queue.get_nowait()
            self._queue.task_done()
            return perception
        except asyncio.QueueEmpty:
            return None

    @property
    def pending(self) -> int:
        """Number of perceptions waiting to be processed."""
        return self._queue.qsize()
