"""JWT authentication and QR code pairing for Bridge Server."""

from __future__ import annotations

import base64
import io
import json
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

try:
    import jwt as pyjwt
except ImportError:
    pyjwt = None  # type: ignore[assignment]

try:
    import qrcode
except ImportError:
    qrcode = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


@dataclass
class PairingInfo:
    token: str
    created_at: float
    expires_at: float
    host: str
    port: int


@dataclass
class PairingResult:
    qr_image_base64: str
    pairing_token: str
    connection_url: str
    expires_at: float


@dataclass
class SessionInfo:
    session_id: str
    device_name: str
    connected_at: float
    last_active: float
    jwt_token: str = ""


class BridgeAuth:
    """JWT authentication with QR code pairing."""

    def __init__(
        self,
        secret_key: str | None = None,
        session_timeout: int = 86400,
        pairing_timeout: int = 300,
        max_sessions: int = 1,
    ) -> None:
        self._secret = secret_key or secrets.token_hex(32)
        self._pairing_tokens: dict[str, PairingInfo] = {}
        self._sessions: dict[str, SessionInfo] = {}
        self._session_timeout = session_timeout
        self._pairing_timeout = pairing_timeout
        self._max_sessions = max_sessions

    # --- QR Pairing ---

    def generate_pairing(self, host: str, port: int) -> PairingResult:
        """Generate QR code for mobile pairing."""
        token = secrets.token_urlsafe(32)
        now = time.time()
        expires_at = now + self._pairing_timeout

        self._pairing_tokens[token] = PairingInfo(
            token=token,
            created_at=now,
            expires_at=expires_at,
            host=host,
            port=port,
        )

        url = f"ws://{host}:{port}/ws"
        qr_data = json.dumps({
            "url": url,
            "token": token,
            "name": "Homunculus",
            "version": "0.5.0",
        }, ensure_ascii=False)

        qr_image_b64 = self._generate_qr_image(qr_data)

        return PairingResult(
            qr_image_base64=qr_image_b64,
            pairing_token=token,
            connection_url=url,
            expires_at=expires_at,
        )

    def validate_pairing_token(self, token: str) -> bool:
        """Validate one-time pairing token."""
        info = self._pairing_tokens.get(token)
        if info is None:
            return False
        if time.time() > info.expires_at:
            del self._pairing_tokens[token]
            return False
        # One-time use: delete after validation
        del self._pairing_tokens[token]
        return True

    # --- JWT Session ---

    def create_session(self, device_info: dict[str, Any] | None = None) -> tuple[str, str]:
        """Create JWT session after successful pairing.

        Returns:
            Tuple of (session_id, jwt_token)
        """
        if pyjwt is None:
            # Fallback: use simple token
            return self._create_simple_session(device_info)

        # Enforce max sessions
        if len(self._sessions) >= self._max_sessions:
            oldest_id = min(self._sessions, key=lambda k: self._sessions[k].connected_at)
            del self._sessions[oldest_id]
            logger.info("Evicted oldest session: %s", oldest_id)

        session_id = uuid.uuid4().hex[:16]
        now = time.time()
        device_name = (device_info or {}).get("device", "Unknown Device")

        payload = {
            "session_id": session_id,
            "device": device_name,
            "iat": now,
            "exp": now + self._session_timeout,
        }
        token = pyjwt.encode(payload, self._secret, algorithm="HS256")

        self._sessions[session_id] = SessionInfo(
            session_id=session_id,
            device_name=device_name,
            connected_at=now,
            last_active=now,
            jwt_token=token,
        )

        return session_id, token

    def validate_session(self, token: str) -> SessionInfo | None:
        """Validate JWT token and return session info."""
        if pyjwt is None:
            return self._validate_simple_session(token)

        try:
            payload = pyjwt.decode(token, self._secret, algorithms=["HS256"])
            session_id = payload.get("session_id", "")
            session = self._sessions.get(session_id)
            if session is not None:
                session.last_active = time.time()
            return session
        except Exception:
            return None

    def revoke_session(self, session_id: str) -> None:
        """Revoke an active session."""
        self._sessions.pop(session_id, None)

    def refresh_session(self, token: str) -> str | None:
        """Refresh JWT token. Returns new token or None."""
        session = self.validate_session(token)
        if session is None:
            return None

        if pyjwt is None:
            return token

        now = time.time()
        payload = {
            "session_id": session.session_id,
            "device": session.device_name,
            "iat": now,
            "exp": now + self._session_timeout,
        }
        new_token = pyjwt.encode(payload, self._secret, algorithm="HS256")
        session.jwt_token = new_token
        return new_token

    @property
    def active_sessions(self) -> list[SessionInfo]:
        return list(self._sessions.values())

    # --- Simple Token Fallback (no PyJWT) ---

    def _create_simple_session(
        self, device_info: dict[str, Any] | None = None,
    ) -> tuple[str, str]:
        session_id = uuid.uuid4().hex[:16]
        token = secrets.token_urlsafe(48)
        now = time.time()
        device_name = (device_info or {}).get("device", "Unknown Device")

        if len(self._sessions) >= self._max_sessions:
            oldest_id = min(self._sessions, key=lambda k: self._sessions[k].connected_at)
            del self._sessions[oldest_id]

        self._sessions[session_id] = SessionInfo(
            session_id=session_id,
            device_name=device_name,
            connected_at=now,
            last_active=now,
            jwt_token=token,
        )
        return session_id, token

    def _validate_simple_session(self, token: str) -> SessionInfo | None:
        for session in self._sessions.values():
            if session.jwt_token == token:
                now = time.time()
                if now - session.connected_at > self._session_timeout:
                    self._sessions.pop(session.session_id, None)
                    return None
                session.last_active = now
                return session
        return None

    # --- QR Code Generation ---

    @staticmethod
    def _generate_qr_image(data: str) -> str:
        """Generate QR code as base64-encoded PNG."""
        if qrcode is None:
            return ""
        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_M,
                box_size=8,
                border=2,
            )
            qr.add_data(data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="white", back_color="#030712")
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception:
            logger.warning("QR code generation failed")
            return ""

    def generate_qr_terminal(self, host: str, port: int) -> str:
        """Generate QR code as ASCII art for terminal display."""
        if qrcode is None:
            return f"[QR not available] Connect: ws://{host}:{port}/ws"

        token = secrets.token_urlsafe(32)
        now = time.time()
        self._pairing_tokens[token] = PairingInfo(
            token=token,
            created_at=now,
            expires_at=now + self._pairing_timeout,
            host=host,
            port=port,
        )

        qr_data = json.dumps({
            "url": f"ws://{host}:{port}/ws",
            "token": token,
            "name": "Homunculus",
            "version": "0.5.0",
        })

        try:
            qr = qrcode.QRCode(box_size=1, border=1)
            qr.add_data(qr_data)
            qr.make(fit=True)
            f = io.StringIO()
            qr.print_ascii(out=f, invert=True)
            return f.getvalue()
        except Exception:
            return f"[QR error] Connect: ws://{host}:{port}/ws  Token: {token}"
