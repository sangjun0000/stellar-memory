"""Configuration loading and management."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from .defaults import DEFAULT_CONFIG

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]


def _deep_merge(base: dict, override: dict) -> dict:
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


class Settings:
    """Homunculus configuration manager."""

    def __init__(self, config_path: str | Path | None = None) -> None:
        self._data: dict[str, Any] = DEFAULT_CONFIG.copy()
        self._config_path = config_path

        if config_path:
            self._load_file(Path(config_path))
        else:
            self._auto_discover()

        self._apply_env_overrides()

    def _load_file(self, path: Path) -> None:
        if path.exists():
            with open(path, "rb") as f:
                user_config = tomllib.load(f)
            self._data = _deep_merge(self._data, user_config)

    def _auto_discover(self) -> None:
        candidates = [
            Path("homunculus.toml"),
            Path.home() / ".config" / "homunculus" / "config.toml",
            Path.home() / ".homunculus.toml",
        ]
        for path in candidates:
            if path.exists():
                self._load_file(path)
                self._config_path = path
                return

    def _apply_env_overrides(self) -> None:
        env_map = {
            "HOMUNCULUS_MODEL_PROVIDER": ("model", "provider"),
            "HOMUNCULUS_MODEL_NAME": ("model", "model_id"),
            "HOMUNCULUS_SAFETY_LEVEL": ("homunculus", "safety_level"),
            "HOMUNCULUS_MEMORY_PATH": ("memory", "db_path"),
            "HOMUNCULUS_LOG_PATH": ("homunculus", "log_path"),
            "HOMUNCULUS_OLLAMA_HOST": ("model", "ollama_host"),
        }
        for env_key, (section, key) in env_map.items():
            value = os.environ.get(env_key)
            if value is not None:
                if section not in self._data:
                    self._data[section] = {}
                self._data[section][key] = value

    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self._data.get(section, {}).get(key, default)

    def section(self, name: str) -> dict[str, Any]:
        return self._data.get(name, {})

    @property
    def model_provider(self) -> str:
        return self.get("model", "provider", "ollama")

    @property
    def model_id(self) -> str:
        return self.get("model", "model_id", "llama3.2:3b")

    @property
    def safety_level(self) -> str:
        return self.get("homunculus", "safety_level", "normal")

    @property
    def memory_db_path(self) -> str:
        return self.get("memory", "db_path", "data/homunculus_brain.db")

    @property
    def personality_profile(self) -> str:
        return self.get("personality", "profile", "jarvis")

    @property
    def log_level(self) -> str:
        return self.get("homunculus", "log_level", "INFO")

    @property
    def data(self) -> dict[str, Any]:
        return self._data
