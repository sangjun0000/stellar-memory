"""Rich-based CLI interface for Homunculus."""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import TYPE_CHECKING

from homunculus.core.types import AgentState

if TYPE_CHECKING:
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)

try:
    from rich.console import Console
    from rich.live import Live
    from rich.panel import Panel
    from rich.text import Text

    HAS_RICH = True
except ImportError:
    HAS_RICH = False


class CLI:
    """Terminal interface for interacting with Homunculus."""

    def __init__(self, agent: Agent) -> None:
        self._agent = agent
        self._console = Console() if HAS_RICH else None
        self._running = False

        # Subscribe to agent events (dot-namespaced convention)
        agent.event_bus.on("agent.response", self._on_response)
        agent.event_bus.on("agent.state.changed", self._on_state_change)

    def _print(self, text: str, style: str = "") -> None:
        if self._console and HAS_RICH:
            self._console.print(text, style=style)
        else:
            print(text)

    def _on_response(self, data: str | None) -> None:
        if data:
            self._print(f"\n[Homunculus] {data}", style="bold cyan")

    def _on_state_change(self, state: AgentState | None) -> None:
        if state and self._agent.show_thinking:
            indicators = {
                AgentState.THINKING: "[dim]Thinking...[/dim]",
                AgentState.PLANNING: "[dim]Planning...[/dim]",
                AgentState.ACTING: "[dim]Acting...[/dim]",
                AgentState.OBSERVING: "[dim]Observing...[/dim]",
                AgentState.LEARNING: "[dim]Learning...[/dim]",
            }
            msg = indicators.get(state)
            if msg and self._console:
                self._console.print(msg)

    def _print_header(self) -> None:
        model = self._agent.model_manager.active_model
        model_str = model.display_name if model else "No model"
        loc = "(local)" if model and model.is_local else "(api)" if model else ""

        header = f"Homunculus v0.5.3 | Model: {model_str} {loc}"
        if self._console and HAS_RICH:
            self._console.print(Panel(header, style="bold blue"))
        else:
            print(f"=== {header} ===")

    async def run(self) -> None:
        """Main CLI loop."""
        self._running = True
        self._print_header()

        greeting = self._agent.personality.greeting()
        self._print(f"\n[Homunculus] {greeting}", style="bold cyan")
        self._print("")

        # Start agent loop in background
        agent_task = asyncio.create_task(self._agent.start())

        try:
            while self._running:
                try:
                    user_input = await self._async_input("[You] ")
                except (EOFError, KeyboardInterrupt):
                    break

                if not user_input.strip():
                    continue

                # Handle slash commands
                if user_input.startswith("/"):
                    from homunculus.interface.commands import handle_command

                    result = await handle_command(self._agent, user_input)
                    if result == "__QUIT__":
                        break
                    if result:
                        self._print(result)
                    continue

                # Send to agent
                await self._agent.handle_message(user_input)

                # Wait a bit for agent to process
                await asyncio.sleep(0.1)

        finally:
            self._running = False
            await self._agent.stop()
            agent_task.cancel()
            try:
                await agent_task
            except asyncio.CancelledError:
                pass
            self._print("\nHomunculus shutting down. Goodbye.", style="dim")

    async def _async_input(self, prompt: str = "") -> str:
        """Non-blocking input using executor."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: input(prompt))
