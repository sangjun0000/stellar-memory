"""Custom Textual messages for Homunculus TUI."""

from __future__ import annotations

from textual.message import Message

from homunculus.core.types import AgentState


class AgentResponse(Message):
    """Agent sent a text response."""

    def __init__(self, text: str) -> None:
        super().__init__()
        self.text = text


class AgentStateChanged(Message):
    """Agent changed state."""

    def __init__(self, state: AgentState) -> None:
        super().__init__()
        self.state = state
