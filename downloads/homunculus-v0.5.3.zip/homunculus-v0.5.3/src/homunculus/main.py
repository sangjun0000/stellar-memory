"""Homunculus entry point."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )


async def async_main(args: argparse.Namespace) -> None:
    from homunculus.config.settings import Settings
    from homunculus.core.agent import Agent
    from homunculus.core.event_bus import EventBus
    from homunculus.memory.bridge import MemoryBridge
    from homunculus.models.manager import ModelManager
    from homunculus.personality.engine import PersonalityEngine
    from homunculus.safety.layer import SafetyLayer
    from homunculus.tools.registry import ToolRegistry

    # Load config
    config_path = args.config if args.config else None
    settings = Settings(config_path)
    setup_logging(settings.log_level)

    logger = logging.getLogger("homunculus")

    # Ensure data directory exists
    data_dir = Path(settings.get("homunculus", "data_path", "data"))
    data_dir.mkdir(parents=True, exist_ok=True)

    # Initialize components
    event_bus = EventBus()

    logger.info("Initializing AI Model Manager...")
    model_manager = ModelManager(settings)
    ok = await model_manager.setup()
    if not ok:
        logger.error(
            "Failed to connect to AI model. "
            "Run 'homunculus --setup' to configure."
        )
        print("Error: Could not connect to AI model.")
        print("Run 'homunculus --setup' to configure your model.")
        return

    # Check Stellar Memory version compatibility
    from homunculus.memory.version_check import get_installed_version, check_compatibility

    sm_version = get_installed_version()
    if sm_version:
        compat = check_compatibility(sm_version)
        if not compat["compatible"]:
            logger.warning(compat["message"])
        else:
            logger.info(compat["message"])

    logger.info("Initializing Stellar Memory brain...")
    memory = MemoryBridge(
        db_path=settings.memory_db_path,
        **settings.section("memory"),
    )

    logger.info("Initializing Tool System...")
    tool_registry = ToolRegistry()
    tool_registry.set_memory_bridge(memory)
    _register_builtin_tools(tool_registry, settings)

    # Load killer use case plugins
    plugin_dir = settings.get("tools", "plugin_dir", "plugins")
    loaded = tool_registry.load_plugins(plugin_dir)
    if loaded:
        logger.info("Loaded %d plugin tool(s)", loaded)

    logger.info("Initializing Safety Layer...")
    safety = SafetyLayer(level=settings.safety_level)

    logger.info("Loading Personality...")
    personality = PersonalityEngine(settings.personality_profile)

    # Create agent
    agent = Agent(
        model_manager=model_manager,
        memory=memory,
        tool_registry=tool_registry,
        safety=safety,
        personality=personality,
        event_bus=event_bus,
        settings=settings,
    )

    # Enable smart routing if configured
    if settings.get("routing", "enabled", False):
        model_manager.enable_routing()
        logger.info("Smart model routing enabled")

    # Start Bridge Server if requested
    bridge_server = None
    bridge_enabled = args.bridge or settings.get("bridge", "auto_start", False)
    if bridge_enabled:
        try:
            from homunculus.bridge import BridgeConfig, BridgeServer

            bridge_config = BridgeConfig.from_settings(settings)
            if args.bridge_port:
                bridge_config.port = args.bridge_port
            bridge_server = BridgeServer(agent, bridge_config)
            await bridge_server.start()
            logger.info("Bridge server running on port %d", bridge_config.port)
            if args.bridge_qr:
                print("\n" + bridge_server.get_qr_terminal())
        except ImportError:
            logger.warning(
                "Bridge dependencies not installed. "
                "Install with: pip install 'homunculus[bridge]'"
            )
        except Exception as e:
            logger.error("Failed to start bridge server: %s", e)

    # Launch interface
    if args.tui:
        from homunculus.interface.tui.app import HomuculusApp

        app = HomuculusApp(agent)
        await app.run_async()
    elif args.classic:
        from homunculus.interface.cli import CLI

        cli = CLI(agent)
        await cli.run()
    else:
        # Default: Web UI
        from homunculus.interface.web.server import WebServer

        server = WebServer(
            agent,
            host=settings.get("web", "host", "127.0.0.1"),
            port=settings.get("web", "port", 7777),
            open_browser=not args.headless,
        )
        await server.run()


def _register_builtin_tools(registry: ToolRegistry, settings: Settings) -> None:
    """Register built-in tools."""
    enabled = settings.get("tools", "enabled", ["shell", "filesystem"])

    if "shell" in enabled:
        from homunculus.tools.builtin.shell import ShellTool

        blocked = settings.get("tools", "shell_blocked_commands", [])
        timeout = settings.get("tools", "shell_timeout", 30)
        registry.register(ShellTool(blocked_commands=blocked, timeout=timeout))

    if "filesystem" in enabled:
        from homunculus.tools.builtin.filesystem import FileSystemTool

        allowed_dirs = settings.get("tools", "filesystem_allowed_dirs", [])
        registry.register(FileSystemTool(allowed_dirs=allowed_dirs))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Homunculus - Autonomous AI Agent",
        prog="homunculus",
    )
    parser.add_argument(
        "--setup", action="store_true",
        help="Run interactive setup wizard",
    )
    parser.add_argument(
        "--config", "-c", type=str, default=None,
        help="Path to config file (homunculus.toml)",
    )
    parser.add_argument(
        "--version", "-v", action="version",
        version="Homunculus 0.5.3",
    )

    # Interface modes (mutually exclusive)
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "--web", action="store_true",
        help="Web UI in browser (default)",
    )
    mode_group.add_argument(
        "--tui", action="store_true",
        help="Terminal TUI (Textual)",
    )
    mode_group.add_argument(
        "--classic", action="store_true",
        help="Legacy Rich CLI",
    )
    mode_group.add_argument(
        "--headless", action="store_true",
        help="API server only (no browser)",
    )

    # Web server options
    parser.add_argument(
        "--port", type=int, default=None,
        help="Web UI port (default: 7777)",
    )
    parser.add_argument(
        "--host", type=str, default=None,
        help="Web UI host (default: 127.0.0.1)",
    )

    # Bridge server options
    parser.add_argument(
        "--bridge", action="store_true",
        help="Enable mobile bridge server",
    )
    parser.add_argument(
        "--bridge-port", type=int, default=None, dest="bridge_port",
        help="Bridge server port (default: 8765)",
    )
    parser.add_argument(
        "--bridge-qr", action="store_true", dest="bridge_qr",
        help="Show QR code in terminal for mobile pairing",
    )

    args = parser.parse_args()

    if args.setup:
        from homunculus.setup import run_setup

        asyncio.run(run_setup())
        return

    asyncio.run(async_main(args))


if __name__ == "__main__":
    main()
