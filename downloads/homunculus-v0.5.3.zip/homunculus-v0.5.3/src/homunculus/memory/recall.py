"""Recall strategies for different agent phases."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from homunculus.core.types import Observation, Perception
    from homunculus.memory.bridge import MemoryBridge, RecalledMemory


class RecallStrategy:
    """Strategies for recalling memories in different agent phases."""

    async def for_thinking(
        self, bridge: MemoryBridge, perception: Perception
    ) -> list[RecalledMemory]:
        """THINK phase: recall context-relevant memories."""
        memories, confidence = await bridge.recall_with_confidence(
            perception.content, limit=7
        )

        # If confidence is low, try broader search
        if confidence < 0.3 and len(perception.content.split()) > 3:
            words = perception.content.split()[:5]
            for keyword in words:
                if len(keyword) > 3:
                    extra = await bridge.recall(keyword, limit=2, include_graph=False)
                    existing_ids = {m.memory_id for m in memories}
                    for m in extra:
                        if m.memory_id not in existing_ids:
                            memories.append(m)
                    break

        return memories

    async def for_planning(
        self, bridge: MemoryBridge, goal: str
    ) -> list[RecalledMemory]:
        """PLAN phase: recall similar past actions and their outcomes."""
        memories = await bridge.recall(
            f"action goal: {goal}", limit=5, include_graph=False
        )
        # Filter to action/observation types
        return [
            m for m in memories
            if m.metadata.get("type") in ("action", "observation", "lesson")
        ]

    async def for_learning(
        self, bridge: MemoryBridge, observation: Observation
    ) -> list[dict]:
        """LEARN phase: detect contradictions before storing new memories."""
        contradictions = await bridge.detect_contradictions()
        return contradictions
