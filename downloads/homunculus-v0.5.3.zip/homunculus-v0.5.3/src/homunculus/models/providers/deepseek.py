"""DeepSeek API provider (OpenAI-compatible)."""

from __future__ import annotations

import os

from .openai_provider import OpenAIProvider


class DeepSeekProvider(OpenAIProvider):
    """DeepSeek uses an OpenAI-compatible API."""

    def __init__(
        self,
        model_id: str = "deepseek-chat",
        api_key: str | None = None,
        timeout: float = 120,
    ) -> None:
        super().__init__(
            model_id=model_id,
            api_key=api_key or os.environ.get("DEEPSEEK_API_KEY", ""),
            base_url="https://api.deepseek.com/v1",
            timeout=timeout,
        )
