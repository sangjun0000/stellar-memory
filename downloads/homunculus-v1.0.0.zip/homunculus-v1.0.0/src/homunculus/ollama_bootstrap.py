"""Ollama auto-detection, installation, and model bootstrapping."""

from __future__ import annotations

import json
import logging
import platform
import shutil
import subprocess
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[str, float], None]


@dataclass
class BootstrapResult:
    success: bool
    ollama_installed: bool = False
    ollama_started: bool = False
    model_available: bool = False
    model_id: str = ""
    install_path: str = ""
    error: str = ""
    steps_completed: list[str] = field(default_factory=list)


class OllamaBootstrap:
    """Detects, installs, and initializes Ollama automatically."""

    OLLAMA_API = "http://localhost:11434"

    def __init__(self, target_model: str = "llama3.2:3b") -> None:
        self._target_model = target_model
        self._system = platform.system()

    # ── Detection ──

    def is_installed(self) -> bool:
        return shutil.which("ollama") is not None

    def is_running(self) -> bool:
        try:
            req = urllib.request.Request(f"{self.OLLAMA_API}/api/tags")
            with urllib.request.urlopen(req, timeout=3) as resp:
                return resp.status == 200
        except Exception:
            return False

    def get_installed_models(self) -> list[str]:
        try:
            req = urllib.request.Request(f"{self.OLLAMA_API}/api/tags")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
                return [m["name"] for m in data.get("models", [])]
        except Exception:
            return []

    def has_target_model(self) -> bool:
        return self._target_model in self.get_installed_models()

    # ── Disk Space ──

    def check_disk_space(self, required_gb: float = 3.0) -> tuple[bool, float]:
        stat = shutil.disk_usage(Path.home())
        available_gb = stat.free / (1024**3)
        return available_gb >= required_gb, available_gb

    # ── Installation ──

    def install(self, progress_callback: ProgressCallback | None = None) -> bool:
        cb = progress_callback or (lambda s, p: None)

        if self.is_installed():
            cb("Ollama already installed", 1.0)
            return True

        cb("Installing Ollama...", 0.1)

        if self._system == "Windows":
            return self._install_windows(cb)
        elif self._system == "Darwin":
            return self._install_macos(cb)
        else:
            return self._install_linux(cb)

    def _install_windows(self, cb: ProgressCallback) -> bool:
        # Try winget first
        if shutil.which("winget"):
            cb("Installing via winget...", 0.3)
            try:
                subprocess.run(
                    ["winget", "install", "Ollama.Ollama", "--accept-source-agreements", "--accept-package-agreements"],
                    check=True,
                    capture_output=True,
                    timeout=300,
                )
                cb("Ollama installed via winget", 0.9)
                return True
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                logger.warning("winget install failed, trying direct download")

        # Fallback: direct download
        cb("Downloading Ollama installer...", 0.3)
        try:
            url = "https://ollama.com/download/OllamaSetup.exe"
            installer_path = Path.home() / "Downloads" / "OllamaSetup.exe"
            urllib.request.urlretrieve(url, str(installer_path))
            cb("Running installer...", 0.6)
            subprocess.run(
                [str(installer_path), "/VERYSILENT", "/NORESTART"],
                check=True,
                timeout=300,
            )
            cb("Ollama installed", 0.9)
            return True
        except Exception as e:
            logger.error("Windows install failed: %s", e)
            cb(f"Install failed: {e}", 0.0)
            return False

    def _install_macos(self, cb: ProgressCallback) -> bool:
        if shutil.which("brew"):
            cb("Installing via Homebrew...", 0.3)
            try:
                subprocess.run(
                    ["brew", "install", "ollama"],
                    check=True,
                    capture_output=True,
                    timeout=300,
                )
                cb("Ollama installed via brew", 0.9)
                return True
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                logger.warning("brew install failed")

        cb("Please install Ollama from https://ollama.com/download", 0.0)
        return False

    def _install_linux(self, cb: ProgressCallback) -> bool:
        cb("Installing via official script...", 0.3)
        try:
            subprocess.run(
                ["bash", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                check=True,
                capture_output=True,
                timeout=300,
            )
            cb("Ollama installed", 0.9)
            return True
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            logger.error("Linux install failed: %s", e)
            cb(f"Install failed: {e}", 0.0)
            return False

    # ── Service Management ──

    def start_service(self, timeout: float = 15.0) -> bool:
        if self.is_running():
            return True

        logger.info("Starting ollama serve...")
        try:
            kwargs = {}
            if self._system == "Windows":
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            else:
                kwargs["start_new_session"] = True

            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                **kwargs,
            )
        except FileNotFoundError:
            logger.error("ollama binary not found")
            return False
        except OSError as e:
            logger.error("Failed to start ollama: %s", e)
            return False

        elapsed = 0.0
        poll_interval = 0.5
        while elapsed < timeout:
            time.sleep(poll_interval)
            elapsed += poll_interval
            if self.is_running():
                logger.info("Ollama ready after %.1fs", elapsed)
                return True

        logger.error("Ollama did not start within %.1fs", timeout)
        return False

    def stop_service(self) -> bool:
        """Stop the ollama serve process."""
        if not self.is_running():
            return True
        try:
            subprocess.run(
                ["ollama", "stop"],
                capture_output=True,
                timeout=10,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            pass
        # Verify it stopped
        time.sleep(1)
        return not self.is_running()

    # ── Model Management ──

    def pull_model(
        self,
        model_id: str | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> bool:
        target = model_id or self._target_model
        cb = progress_callback or (lambda s, p: None)

        if target in self.get_installed_models():
            cb(f"Model {target} already available", 1.0)
            return True

        cb(f"Pulling {target}...", 0.05)
        try:
            payload = json.dumps({"name": target, "stream": True}).encode()
            req = urllib.request.Request(
                f"{self.OLLAMA_API}/api/pull",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=600) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    data = json.loads(line)
                    status = data.get("status", "")

                    if "pulling" in status and "total" in data and "completed" in data:
                        total = data["total"]
                        completed = data["completed"]
                        pct = completed / total if total > 0 else 0
                        size_mb = completed / (1024 * 1024)
                        total_mb = total / (1024 * 1024)
                        cb(f"Downloading: {size_mb:.0f}/{total_mb:.0f} MB", pct * 0.9)
                    elif status == "success":
                        cb(f"Model {target} ready", 1.0)
                        return True
                    else:
                        cb(status, 0.95)

        except Exception as e:
            logger.error("Pull failed: %s", e)
            cb(f"Pull failed: {e}", 0.0)
            return False

        return target in self.get_installed_models()

    # ── Full Bootstrap ──

    def bootstrap(
        self,
        progress_callback: ProgressCallback | None = None,
    ) -> BootstrapResult:
        cb = progress_callback or (lambda s, p: None)
        result = BootstrapResult(success=False, model_id=self._target_model)

        # Step 1: Check disk space
        has_space, avail = self.check_disk_space()
        if not has_space:
            result.error = f"Insufficient disk space: {avail:.1f} GB available, 3 GB required"
            cb(result.error, 0.0)
            return result

        # Step 2: Ollama installation
        result.ollama_installed = self.is_installed()
        if not result.ollama_installed:
            cb("Ollama not found, installing...", 0.05)
            if not self.install(progress_callback=cb):
                result.error = "Failed to install Ollama"
                return result
            result.ollama_installed = True
        result.steps_completed.append("ollama_detected" if result.ollama_installed else "ollama_installed")
        cb("Ollama installed", 0.3)

        # Step 3: Start service
        result.ollama_started = self.is_running()
        if not result.ollama_started:
            cb("Starting Ollama service...", 0.35)
            if not self.start_service():
                result.error = "Failed to start Ollama service"
                return result
            result.ollama_started = True
        result.steps_completed.append("service_started")
        cb("Ollama running", 0.5)

        # Step 4: Pull model
        result.model_available = self.has_target_model()
        if not result.model_available:
            def pull_cb(status: str, pct: float) -> None:
                cb(status, 0.5 + pct * 0.45)

            if not self.pull_model(progress_callback=pull_cb):
                result.error = f"Failed to pull model: {self._target_model}"
                return result
            result.model_available = True
        result.steps_completed.append("model_pulled")
        cb("Model ready", 0.95)

        # Step 5: Verify with a simple test
        try:
            payload = json.dumps({
                "model": self._target_model,
                "messages": [{"role": "user", "content": "Hi"}],
                "stream": False,
                "options": {"num_predict": 10},
            }).encode()
            req = urllib.request.Request(
                f"{self.OLLAMA_API}/api/chat",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                if resp.status == 200:
                    result.steps_completed.append("test_passed")
        except Exception:
            logger.warning("Test prompt failed, but model may still work")

        result.install_path = shutil.which("ollama") or ""
        result.success = True
        cb("Bootstrap complete", 1.0)
        return result
