"""Homunculus exception hierarchy."""

from __future__ import annotations


class HomunculusError(Exception):
    """Base error for all Homunculus exceptions."""


# ─── Model Errors ───


class ModelError(HomunculusError):
    """AI model related error."""


class ModelNotFoundError(ModelError):
    """The requested model could not be found."""


class ModelConnectionError(ModelError):
    """Failed to connect to the model backend."""


class ModelTimeoutError(ModelError):
    """Model response timed out."""


# ─── Memory Errors ───


class MemoryError(HomunculusError):
    """Memory system error."""


# ─── Tool Errors ───


class ToolError(HomunculusError):
    """Tool execution error."""


class ToolExecutionError(ToolError):
    """Error during tool execution."""


class ToolPermissionError(ToolError):
    """Insufficient permissions to run tool."""


# ─── Safety Errors ───


class SafetyError(HomunculusError):
    """Safety layer error."""


class SafetyBlockedError(SafetyError):
    """Action blocked by safety policy."""


# ─── Watcher Errors ───

class WatcherError(HomunculusError):
    """Watcher system error."""

class WatcherStartError(WatcherError):
    """Failed to start a watcher."""

# ─── Scheduler Errors ───

class SchedulerError(HomunculusError):
    """Scheduler system error."""

class SchedulerTaskNotFoundError(SchedulerError):
    """Scheduled task not found."""

# ─── Web Search Errors ───

class WebSearchError(HomunculusError):
    """Web search error."""

# ─── Code Analysis Errors ───

class CodeAnalysisError(HomunculusError):
    """Code analysis error."""

# ─── Rollback Errors ───

class RollbackError(SafetyError):
    """Rollback operation error."""
