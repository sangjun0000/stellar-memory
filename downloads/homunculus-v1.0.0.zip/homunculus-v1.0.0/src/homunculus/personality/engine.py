"""Personality engine - maintains consistent character."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

from homunculus.core.types import PersonalityProfile

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

logger = logging.getLogger(__name__)

PROFILES_DIR = Path(__file__).parent / "profiles"


class PersonalityEngine:
    """Manages agent personality and response styling."""

    def __init__(self, profile_name: str = "jarvis") -> None:
        self._profile: PersonalityProfile | None = None
        self._prompts: dict[str, str] = {}
        self.load_profile(profile_name)

    @property
    def profile(self) -> PersonalityProfile | None:
        return self._profile

    def load_profile(self, name: str) -> None:
        path = PROFILES_DIR / f"{name}.toml"
        if not path.exists():
            logger.warning("Profile '%s' not found at %s, using defaults", name, path)
            self._profile = PersonalityProfile(
                name=name,
                system_prompt="You are Homunculus, a helpful autonomous AI assistant.",
                greeting="Hello. How can I help?",
            )
            return

        with open(path, "rb") as f:
            data = tomllib.load(f)

        p = data.get("personality", {})
        prompts = p.get("prompts", {})

        self._profile = PersonalityProfile(
            name=p.get("name", name),
            system_prompt=prompts.get("system", ""),
            greeting=prompts.get("greeting", "Hello."),
            tone=p.get("tone", "professional"),
            language=p.get("language", "auto"),
            emoji_usage=p.get("emoji_usage", False),
            verbosity=p.get("verbosity", "normal"),
        )
        self._prompts = {
            "system": prompts.get("system", ""),
            "thinking": prompts.get("thinking", {}).get("system", ""),
            "planning": prompts.get("planning", {}).get("system", ""),
        }
        logger.info("Loaded personality profile: %s", name)

    def get_system_prompt(self) -> str:
        return self._prompts.get("system", "") or (
            self._profile.system_prompt if self._profile else ""
        )

    def get_thinking_prompt(self) -> str:
        return self._prompts.get("thinking", "")

    def get_planning_prompt(self) -> str:
        return self._prompts.get("planning", "")

    def greeting(self) -> str:
        return self._profile.greeting if self._profile else "Hello."

    def style(self, raw_response: str) -> str:
        """Apply personality styling to a response.
        Currently a passthrough - can be extended for tone adjustments.
        """
        if not raw_response:
            return raw_response
        return raw_response.strip()

    def list_profiles(self) -> list[str]:
        return [p.stem for p in PROFILES_DIR.glob("*.toml")]
