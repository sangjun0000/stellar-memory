"""Homunculus unified installer -- 5-step setup wizard."""

from __future__ import annotations

import platform
import shutil
import subprocess
import sys
from pathlib import Path

# installer.py runs with SYSTEM Python (not venv).
# Add source directory to path so we can import homunculus modules.
_THIS_DIR = Path(__file__).resolve().parent
_SRC_DIR = _THIS_DIR.parent
if str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))


def main(source_dir: str, auto: bool = False) -> None:
    source = Path(source_dir)
    system = platform.system()  # "Windows", "Darwin", "Linux"

    print_header()

    # Step 1: Install path
    if auto:
        install_dir = Path.home() / "Homunculus"
        install_dir.mkdir(parents=True, exist_ok=True)
        print(f"  Install to: {install_dir}")
        print()
    else:
        install_dir = step_install_path(system)

    # Step 2: Copy files
    copy_project(source, install_dir)

    # Step 3: Create venv + install
    create_venv(install_dir)
    pip_install(install_dir)

    # Step 3.5: Ollama Bootstrap (AI Engine)
    bootstrap_ollama()

    # Step 4: Config
    if auto:
        write_smart_defaults(install_dir)
    else:
        run_setup_wizard(install_dir)

    # Step 5: Create launcher + desktop shortcut
    create_launcher(install_dir, system)
    create_shortcut(install_dir, system)

    print_complete(install_dir, system)


def print_header() -> None:
    print()
    print("  Homunculus Setup Wizard")
    print("  " + "\u2500" * 35)
    print()


def step_install_path(system: str) -> Path:
    """Step 1/5: Choose install location."""
    print("  [Step 1/5] Install Location")
    print()

    default = Path.home() / "Homunculus"

    user_input = input(f"  Install to [{default}]: ").strip()
    install_dir = Path(user_input) if user_input else default

    install_dir.mkdir(parents=True, exist_ok=True)
    print(f"  -> {install_dir}")
    print()
    return install_dir


def copy_project(source: Path, dest: Path) -> None:
    """Copy source files to install directory."""
    print("  Copying files...")

    for item in ["src", "pyproject.toml", "launch.bat", "launch.sh", "assets"]:
        src = source / item
        dst = dest / item
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        elif src.is_file():
            shutil.copy2(src, dst)

    print("  -> Files copied.")
    print()


def create_venv(install_dir: Path) -> None:
    """Create Python virtual environment."""
    print("  Creating virtual environment...")
    venv_dir = install_dir / ".venv"

    if venv_dir.exists():
        shutil.rmtree(venv_dir)

    python = sys.executable
    subprocess.run(
        [python, "-m", "venv", str(venv_dir)],
        check=True,
    )
    print("  -> venv created.")
    print()


def pip_install(install_dir: Path) -> None:
    """Install homunculus into venv."""
    print("  Installing dependencies (this may take a minute)...")

    system = platform.system()
    if system == "Windows":
        pip = install_dir / ".venv" / "Scripts" / "pip"
    else:
        pip = install_dir / ".venv" / "bin" / "pip"

    subprocess.run(
        [str(pip), "install", str(install_dir), "-q"],
        check=True,
    )
    print("  -> Dependencies installed.")
    print()


def bootstrap_ollama() -> None:
    """Step 3.5: Ensure Ollama is ready for first use."""
    print("  [Step 3.5/5] AI Engine Setup")
    print()

    from homunculus.ollama_bootstrap import OllamaBootstrap

    bootstrap = OllamaBootstrap()

    def on_progress(status: str, percent: float) -> None:
        bar_len = 30
        filled = int(percent * bar_len)
        bar = "\u2588" * filled + "\u2591" * (bar_len - filled)
        print(f"\r  [{bar}] {percent * 100:.0f}% {status}", end="", flush=True)

    result = bootstrap.bootstrap(progress_callback=on_progress)
    print()

    if result.success:
        print(f"  -> AI Engine ready: {result.model_id}")
    else:
        print(f"  [WARN] AI Engine setup incomplete: {result.error}")
        print("  You can set up manually later with 'homunculus --setup'")
    print()


def write_smart_defaults(install_dir: Path) -> None:
    """Write sensible default config without user interaction."""
    print("  Applying smart defaults...")

    config = {
        "homunculus": {
            "safety_level": "normal",
        },
        "model": {
            "provider": "ollama",
            "model_id": "llama3.2:3b",
        },
        "tools": {
            "enabled": ["shell", "filesystem"],
            "filesystem_allowed_dirs": [str(Path.home())],
        },
    }

    config_path = install_dir / "homunculus.toml"
    _write_toml(config_path, config)
    print(f"  -> Config: {config_path}")
    print("  -> Tip: Change settings anytime in Homunculus onboarding")
    print()


def _write_toml(path: Path, data: dict) -> None:
    """Write a simple TOML config file."""
    lines = []
    for section, values in data.items():
        if not values:
            continue
        lines.append(f"[{section}]")
        for key, value in values.items():
            if isinstance(value, str):
                lines.append(f'{key} = "{value}"')
            elif isinstance(value, bool):
                lines.append(f"{key} = {'true' if value else 'false'}")
            elif isinstance(value, (int, float)):
                lines.append(f"{key} = {value}")
            elif isinstance(value, list):
                items = ", ".join(f'"{v}"' for v in value)
                lines.append(f"{key} = [{items}]")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def run_setup_wizard(install_dir: Path) -> None:
    """Run the setup wizard (model, scope, safety)."""
    system = platform.system()
    if system == "Windows":
        python = install_dir / ".venv" / "Scripts" / "python"
    else:
        python = install_dir / ".venv" / "bin" / "python"

    subprocess.run(
        [str(python), "-m", "homunculus.installer_wizard", str(install_dir)],
        check=True,
    )


def create_launcher(install_dir: Path, system: str) -> None:
    """Ensure launch scripts have correct paths."""
    if system == "Windows":
        launcher = install_dir / "launch.bat"
        launcher.write_text(
            '@echo off\n'
            f'cd /d "{install_dir}"\n'
            'call .venv\\Scripts\\activate\n'
            'python -m homunculus\n',
            encoding="utf-8",
        )
    else:
        launcher = install_dir / "launch.sh"
        launcher.write_text(
            '#!/usr/bin/env bash\n'
            f'cd "{install_dir}"\n'
            'source .venv/bin/activate\n'
            'python -m homunculus\n',
            encoding="utf-8",
        )
        launcher.chmod(0o755)


def create_shortcut(install_dir: Path, system: str) -> None:
    """Create desktop shortcut."""
    from homunculus.shortcut import create_desktop_shortcut
    create_desktop_shortcut(install_dir, system)


def print_complete(install_dir: Path, system: str) -> None:
    print()
    print("  \u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557")
    print("  \u2551  Installation Complete!                \u2551")
    print("  \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d")
    print()
    print(f"  Installed to: {install_dir}")
    print()
    print("  A shortcut has been created on your Desktop.")
    print("  Double-click 'Homunculus' to start!")
    print()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Homunculus installer")
    parser.add_argument("source_dir", nargs="?", default=".")
    parser.add_argument("--auto", action="store_true",
                        help="Skip wizard, use smart defaults")
    parser.add_argument("--interactive", action="store_true",
                        help="Force interactive wizard (default if no --auto)")
    args = parser.parse_args()

    try:
        main(args.source_dir, auto=args.auto)
    except Exception as e:
        print(f"\n  [ERROR] {e}")
        input("\n  Press Enter to close...")
        sys.exit(1)
