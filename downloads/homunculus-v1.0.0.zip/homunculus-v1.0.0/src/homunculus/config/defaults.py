"""Default configuration values for Homunculus."""

from __future__ import annotations

DEFAULT_CONFIG = {
    "homunculus": {
        "name": "Homunculus",
        "version": "1.0.0",
        "safety_level": "normal",  # strict | normal | permissive
        "log_level": "INFO",
        "log_path": "logs/",
        "data_path": "data/",
    },
    "model": {
        "provider": "ollama",
        "model_id": "llama3.2:3b",
        "temperature": 0.7,
        "max_tokens": 4096,
        "timeout": 60,
    },
    "memory": {
        "db_path": "data/homunculus_brain.db",
        "w_recall": 0.25,
        "w_freshness": 0.25,
        "w_arbitrary": 0.20,
        "w_context": 0.15,
        "w_emotion": 0.15,
        "emotion_enabled": True,
        "graph_enabled": True,
        "graph_auto_link_threshold": 0.65,
        "metacognition_enabled": True,
        "self_learning_enabled": True,
        "reasoning_enabled": True,
        "reorbit_interval": 300,
        "auto_update_check": True,
        "update_check_interval": 86400,
        "allow_major_update": False,
    },
    "tools": {
        "enabled": ["shell", "filesystem", "api_caller", "code_writer", "scheduler", "browser"],
        "plugin_dir": "plugins/",
        "shell_timeout": 30,
        "shell_blocked_commands": [
            "rm -rf /",
            "format",
            "mkfs",
            "dd if=/dev/zero",
            "shutdown",
            "reboot",
        ],
        "filesystem_allowed_dirs": [],  # empty = current dir and below
        "api_caller_timeout": 30,
        "api_caller_blocked_hosts": None,  # None = use default block list
        "scheduler_max_tasks": 100,
        "browser_allowed_domains": None,  # None = all domains allowed
        "browser_js_enabled": False,
    },
    "watchers": {
        "file_watcher_enabled": False,
        "file_watcher_paths": [],
        "file_watcher_debounce": 1.0,
        "schedule_watcher_enabled": False,
        "process_watcher_enabled": False,
        "process_watcher_interval": 5.0,
    },
    "cognition": {
        "web_search_enabled": True,
        "web_search_provider": "duckduckgo",
        "web_search_cache_ttl": 3600,
        "web_search_rate_limit": 20,
        "chain_of_thought": True,
        "self_reflection_threshold": 0.4,
    },
    "personality": {
        "profile": "jarvis",
        "language": "auto",
    },
    "interface": {
        "show_thinking": False,
        "show_memory_stats": True,
    },
    "web": {
        "host": "127.0.0.1",
        "port": 7777,
        "open_browser": True,
    },
    "bridge": {
        "host": "0.0.0.0",
        "port": 8765,
        "auto_start": False,
        "max_clients": 1,
        "heartbeat_interval": 30,
    },
    "routing": {
        "enabled": False,
        "privacy_mode": False,
        "local_provider": "ollama",
        "local_model": "llama3.2:3b",
        "cloud_provider": "",
        "cloud_model": "",
    },
    "onboarding": {
        "completed": False,
        "user_name": "",
    },
}
