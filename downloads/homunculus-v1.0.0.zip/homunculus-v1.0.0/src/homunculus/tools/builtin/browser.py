"""BrowserTool — web automation via Playwright (optional dependency).

Playwright is an optional dependency.  When it is not installed the tool
registers successfully but every ``execute`` call returns a graceful error
rather than raising an ImportError that would crash the agent loop.

Risk levels per action:
  - navigate   → LOW
  - extract    → LOW
  - screenshot → LOW
  - content    → LOW
  - click      → MEDIUM
  - type       → MEDIUM

Features
--------
- Optional domain allowlist: when non-empty, only those domains may be visited.
- JavaScript is *disabled* by default to reduce the attack surface; callers
  may opt-in explicitly via the ``enable_js`` parameter.
- Response content is truncated at ``max_content_bytes`` to avoid OOM.
- Screenshots are returned as base64-encoded PNG strings in ``ToolResult.data``.
"""

from __future__ import annotations

import base64
import logging
import uuid
from typing import Any
from urllib.parse import urlparse

from homunculus.core.types import ActionRisk, ToolDefinition, ToolResult
from homunculus.errors import ToolExecutionError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional dependency guard
# ---------------------------------------------------------------------------
try:
    from playwright.async_api import (
        Browser,
        BrowserContext,
        Page,
        async_playwright,
    )

    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False
    # Provide stub types so type annotations don't break at import time.
    Browser = Any  # type: ignore[misc, assignment]
    BrowserContext = Any  # type: ignore[misc, assignment]
    Page = Any  # type: ignore[misc, assignment]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SUPPORTED_ACTIONS = frozenset(
    {"navigate", "click", "type", "extract", "screenshot", "content"}
)

ACTION_RISK: dict[str, ActionRisk] = {
    "navigate": ActionRisk.LOW,
    "click": ActionRisk.MEDIUM,
    "type": ActionRisk.MEDIUM,
    "extract": ActionRisk.LOW,
    "screenshot": ActionRisk.LOW,
    "content": ActionRisk.LOW,
}

_DEFINITION = ToolDefinition(
    name="browser",
    display_name="Browser",
    description=(
        "Automate a headless web browser via Playwright (optional dependency). "
        "Actions: navigate, click, type, extract, screenshot, content. "
        "JavaScript is disabled by default. Requires 'playwright' package."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": list(_SUPPORTED_ACTIONS),
                "description": "Browser operation to perform.",
            },
            "url": {
                "type": "string",
                "description": "(navigate) Target URL.",
            },
            "selector": {
                "type": "string",
                "description": "(click/type/extract) CSS or XPath selector.",
            },
            "text": {
                "type": "string",
                "description": "(type) Text to type into the selected element.",
            },
            "attribute": {
                "type": "string",
                "description": "(extract) HTML attribute to extract (omit for inner text).",
            },
            "screenshot_path": {
                "type": "string",
                "description": "(screenshot) Optional file path to save the PNG.",
            },
            "enable_js": {
                "type": "boolean",
                "default": False,
                "description": "Enable JavaScript (disabled by default for safety).",
            },
            "timeout": {
                "type": "integer",
                "default": 30,
                "description": "Navigation / action timeout in seconds (1–120).",
            },
        },
        "required": ["action"],
    },
    risk_level=ActionRisk.LOW,
    enabled=True,
    version="1.0.0",
    author="homunculus",
)

_NOT_INSTALLED_MSG = (
    "Playwright is not installed. "
    "Install it with: pip install playwright && playwright install chromium"
)

# Maximum bytes of page content retained in ToolResult.output.
_DEFAULT_MAX_CONTENT_BYTES = 256 * 1024  # 256 KB


class BrowserTool:
    """Headless browser automation backed by Playwright.

    Parameters
    ----------
    allowed_domains:
        When non-empty, navigation is restricted to these domain names.
        Sub-domains must be listed explicitly.
    max_content_bytes:
        Maximum bytes of page text/HTML returned in ToolResult.output.
    """

    def __init__(
        self,
        allowed_domains: list[str] | None = None,
        max_content_bytes: int = _DEFAULT_MAX_CONTENT_BYTES,
    ) -> None:
        self._allowed_domains = allowed_domains or []
        self._max_content_bytes = max_content_bytes
        # Rollback history keyed by exec_id.
        self._history: dict[str, dict[str, Any]] = {}
        # Current browser state (lazily initialised per-session).
        self._playwright: Any = None
        self._browser: Any = None
        self._context: Any = None
        self._page: Any = None
        self._current_url: str = ""

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        action = parameters.get("action", "")
        if action not in _SUPPORTED_ACTIONS:
            logger.warning("BrowserTool.validate: unknown action '%s'.", action)
            return False

        if action == "navigate":
            url = parameters.get("url", "")
            if not isinstance(url, str) or not url.startswith(("http://", "https://")):
                logger.warning(
                    "BrowserTool.validate: URL must start with http:// or https://."
                )
                return False
            if self._allowed_domains and not self._is_domain_allowed(url):
                logger.warning(
                    "BrowserTool.validate: domain not in allowlist for URL '%s'.", url
                )
                return False

        if action in ("click", "type", "extract") and not parameters.get("selector"):
            logger.warning(
                "BrowserTool.validate: 'selector' required for '%s'.", action
            )
            return False

        if action == "type" and not parameters.get("text"):
            logger.warning("BrowserTool.validate: 'text' required for 'type'.")
            return False

        timeout = parameters.get("timeout", 30)
        if not isinstance(timeout, int) or not (1 <= timeout <= 120):
            logger.warning(
                "BrowserTool.validate: timeout must be an integer in [1, 120]."
            )
            return False

        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        if not HAS_PLAYWRIGHT:
            return ToolResult(success=False, error=_NOT_INSTALLED_MSG)

        action: str = parameters["action"]
        timeout_ms: int = int(parameters.get("timeout", 30)) * 1000  # Playwright uses ms.
        enable_js: bool = parameters.get("enable_js", False)

        try:
            await self._ensure_browser(enable_js)
        except Exception as exc:
            return ToolResult(
                success=False,
                error=f"Browser initialisation failed: {exc}",
            )

        exec_id = uuid.uuid4().hex[:12]
        self._history[exec_id] = {
            "action": action,
            "url_before": self._current_url,
            "parameters": {k: v for k, v in parameters.items() if k != "text"},
        }

        dispatch = {
            "navigate": self._navigate,
            "click": self._click,
            "type": self._type,
            "extract": self._extract,
            "screenshot": self._screenshot,
            "content": self._content,
        }
        handler = dispatch.get(action)
        if handler is None:
            return ToolResult(success=False, error=f"Unknown action '{action}'.")

        try:
            return await handler(parameters, timeout_ms, exec_id)
        except Exception as exc:
            raise ToolExecutionError(f"Browser action '{action}' failed: {exc}") from exc

    async def rollback(self, execution_id: str) -> bool:
        # Navigation state is ephemeral; we cannot truly undo clicks/typing.
        record = self._history.get(execution_id)
        if not record:
            logger.warning(
                "BrowserTool.rollback: execution_id '%s' not found.", execution_id
            )
            return False

        prior_url = record.get("url_before")
        if prior_url and self._page is not None:
            try:
                await self._page.goto(prior_url, timeout=15_000)
                logger.info(
                    "BrowserTool.rollback: navigated back to '%s'.", prior_url
                )
                return True
            except Exception as exc:
                logger.error("BrowserTool.rollback: failed to navigate back: %s", exc)
                return False

        return False

    async def close(self) -> None:
        """Release all Playwright resources.  Call when the agent shuts down."""
        if self._browser is not None:
            try:
                await self._browser.close()
            except Exception:
                pass
            self._browser = None
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception:
                pass
            self._playwright = None
        self._context = None
        self._page = None

    # ─── Action Handlers ───

    async def _navigate(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        url: str = params["url"]
        assert self._page is not None
        response = await self._page.goto(url, timeout=timeout_ms, wait_until="domcontentloaded")
        self._current_url = self._page.url

        status = response.status if response else 0
        success = 200 <= status < 400 if response else False
        return ToolResult(
            success=success,
            output=f"Navigated to '{self._current_url}' (HTTP {status}).",
            data={
                "url": self._current_url,
                "status": status,
                "exec_id": exec_id,
            },
            rollback_id=exec_id,
        )

    async def _click(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        selector: str = params["selector"]
        assert self._page is not None
        await self._page.click(selector, timeout=timeout_ms)
        return ToolResult(
            success=True,
            output=f"Clicked element matching '{selector}'.",
            data={"selector": selector, "exec_id": exec_id},
            rollback_id=exec_id,
        )

    async def _type(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        selector: str = params["selector"]
        text: str = params["text"]
        assert self._page is not None
        await self._page.fill(selector, text, timeout=timeout_ms)
        return ToolResult(
            success=True,
            output=f"Typed {len(text)} characters into '{selector}'.",
            data={"selector": selector, "exec_id": exec_id},
            rollback_id=exec_id,
        )

    async def _extract(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        selector: str = params["selector"]
        attribute: str | None = params.get("attribute")
        assert self._page is not None

        elements = await self._page.query_selector_all(selector)
        if not elements:
            return ToolResult(
                success=False,
                error=f"No elements matched selector '{selector}'.",
            )

        results: list[str] = []
        for el in elements:
            if attribute:
                value = await el.get_attribute(attribute) or ""
            else:
                value = (await el.inner_text()) or ""
            results.append(value.strip())

        combined = "\n".join(results)
        truncated = combined[: self._max_content_bytes]
        if len(combined) > self._max_content_bytes:
            truncated += "\n[content truncated]"

        return ToolResult(
            success=True,
            output=truncated,
            data={"selector": selector, "count": len(results), "exec_id": exec_id},
        )

    async def _screenshot(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        save_path: str | None = params.get("screenshot_path")
        assert self._page is not None

        png_bytes: bytes = await self._page.screenshot(full_page=True)

        if save_path:
            from pathlib import Path

            Path(save_path).write_bytes(png_bytes)

        b64 = base64.b64encode(png_bytes).decode()
        return ToolResult(
            success=True,
            output=f"Screenshot captured ({len(png_bytes)} bytes).",
            data={
                "base64_png": b64,
                "size_bytes": len(png_bytes),
                "saved_to": save_path or "",
                "exec_id": exec_id,
            },
        )

    async def _content(
        self, params: dict[str, Any], timeout_ms: int, exec_id: str
    ) -> ToolResult:
        assert self._page is not None
        html: str = await self._page.content()
        truncated = html[: self._max_content_bytes]
        if len(html) > self._max_content_bytes:
            truncated += "\n<!-- content truncated -->"

        return ToolResult(
            success=True,
            output=truncated,
            data={
                "url": self._current_url,
                "size_bytes": len(html),
                "exec_id": exec_id,
            },
        )

    # ─── Private ───

    async def _ensure_browser(self, enable_js: bool) -> None:
        """Launch the browser lazily on first use."""
        if self._page is not None:
            return

        pw = await async_playwright().__aenter__()
        self._playwright = pw
        self._browser = await pw.chromium.launch(headless=True)
        self._context = await self._browser.new_context(
            java_script_enabled=enable_js,
        )
        self._page = await self._context.new_page()

    def _is_domain_allowed(self, url: str) -> bool:
        """Return True when the URL's domain is in the allowlist."""
        try:
            host = urlparse(url).hostname or ""
        except Exception:
            return False
        return host in self._allowed_domains
