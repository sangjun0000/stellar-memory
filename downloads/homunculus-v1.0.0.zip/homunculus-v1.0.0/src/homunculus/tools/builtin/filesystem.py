"""FileSystemTool — read, write, list, and search files.

Risk levels are per-action:
  - read / list / search → SAFE
  - write                → MEDIUM

When ``allowed_dirs`` is non-empty every path is checked against that
allowlist, so operators can sandbox the agent to specific directories via
homunculus.toml.
"""

from __future__ import annotations

import fnmatch
import logging
from pathlib import Path
from typing import Any

from homunculus.core.types import ActionRisk, ToolDefinition, ToolResult

logger = logging.getLogger(__name__)

_DEFINITION = ToolDefinition(
    name="filesystem",
    display_name="File System",
    description=(
        "Interact with the local file system. "
        "Supported actions: read, write, list, search, move, copy, delete."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["read", "write", "list", "search", "move", "copy", "delete"],
                "description": "The file system operation to perform.",
            },
            "path": {
                "type": "string",
                "description": "Absolute or relative path to a file or directory.",
            },
            "content": {
                "type": "string",
                "description": "Content to write (required for 'write' action).",
            },
            "pattern": {
                "type": "string",
                "description": "Glob pattern for 'search' action (e.g. '*.py').",
            },
            "recursive": {
                "type": "boolean",
                "description": "Whether to search recursively (default true).",
                "default": True,
            },
            "destination": {
                "type": "string",
                "description": "Destination path for 'move' and 'copy' actions.",
            },
        },
        "required": ["action", "path"],
    },
    risk_level=ActionRisk.SAFE,  # Highest risk action is write (MEDIUM); registry shows base.
    enabled=True,
    version="1.0.0",
    author="homunculus",
)

# Maximum file size read into memory to avoid OOM on huge files.
_MAX_READ_BYTES = 1024 * 512  # 512 KB

_SUPPORTED_ACTIONS = {"read", "write", "list", "search", "move", "copy", "delete"}

# Risk levels per action — used by SafetyLayer when assessing individual steps.
ACTION_RISK: dict[str, ActionRisk] = {
    "read": ActionRisk.SAFE,
    "list": ActionRisk.SAFE,
    "search": ActionRisk.SAFE,
    "write": ActionRisk.MEDIUM,
    "move": ActionRisk.MEDIUM,
    "copy": ActionRisk.MEDIUM,
    "delete": ActionRisk.HIGH,
}


class FileSystemTool:
    """Perform file system operations within optional directory boundaries.

    ``allowed_dirs`` restricts all path operations to a whitelist of root
    directories.  An empty list means "anywhere accessible to the process",
    which is suitable for trusted environments.
    """

    def __init__(self, allowed_dirs: list[str] | None = None) -> None:
        self._allowed_dirs: list[Path] = (
            [Path(d).resolve() for d in allowed_dirs]
            if allowed_dirs
            else []
        )

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        action = parameters.get("action", "")
        if action not in _SUPPORTED_ACTIONS:
            logger.warning("FileSystemTool.validate: unknown action '%s'.", action)
            return False

        path_str = parameters.get("path", "")
        if not path_str:
            logger.warning("FileSystemTool.validate: 'path' is required.")
            return False

        if action == "write" and "content" not in parameters:
            logger.warning("FileSystemTool.validate: 'content' required for write.")
            return False

        if action == "search" and not parameters.get("pattern"):
            logger.warning("FileSystemTool.validate: 'pattern' required for search.")
            return False

        if action in ("move", "copy") and not parameters.get("destination"):
            logger.warning("FileSystemTool.validate: 'destination' required for %s.", action)
            return False

        if self._allowed_dirs and not self._is_allowed(Path(path_str)):
            logger.warning(
                "FileSystemTool.validate: path '%s' is outside allowed directories.",
                path_str,
            )
            return False

        if action in ("move", "copy"):
            dest = parameters.get("destination", "")
            if dest and self._allowed_dirs and not self._is_allowed(Path(dest)):
                logger.warning(
                    "FileSystemTool.validate: destination '%s' is outside allowed directories.",
                    dest,
                )
                return False

        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        action: str = parameters["action"]
        path = Path(parameters["path"])

        dispatch = {
            "read": self._read,
            "write": self._write,
            "list": self._list,
            "search": self._search,
            "move": self._move,
            "copy": self._copy,
            "delete": self._delete,
        }
        handler = dispatch.get(action)
        if handler is None:
            return ToolResult(success=False, error=f"Unknown action '{action}'.")

        return await handler(path, parameters)

    # ─── Action Handlers ───

    async def _read(self, path: Path, _params: dict[str, Any]) -> ToolResult:
        if not path.exists():
            return ToolResult(success=False, error=f"File not found: '{path}'.")
        if not path.is_file():
            return ToolResult(success=False, error=f"Path is not a file: '{path}'.")

        try:
            raw = path.read_bytes()
            if len(raw) > _MAX_READ_BYTES:
                content = raw[:_MAX_READ_BYTES].decode("utf-8", errors="replace")
                content += "\n[file truncated — exceeded read limit]"
                logger.debug("FileSystemTool._read: truncated '%s'.", path)
            else:
                content = raw.decode("utf-8", errors="replace")
            return ToolResult(
                success=True,
                output=content,
                data={"path": str(path), "size_bytes": len(raw)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Read error: {exc}")

    async def _write(self, path: Path, params: dict[str, Any]) -> ToolResult:
        content: str = params.get("content", "")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            logger.debug("FileSystemTool._write: wrote %d chars to '%s'.", len(content), path)
            return ToolResult(
                success=True,
                output=f"Written {len(content)} characters to '{path}'.",
                data={"path": str(path)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Write error: {exc}")

    async def _list(self, path: Path, _params: dict[str, Any]) -> ToolResult:
        if not path.exists():
            return ToolResult(success=False, error=f"Path not found: '{path}'.")
        if not path.is_dir():
            return ToolResult(success=False, error=f"Path is not a directory: '{path}'.")

        try:
            entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name))
            lines = [
                f"{'[D]' if e.is_dir() else '[F]'} {e.name}"
                for e in entries
            ]
            output = "\n".join(lines) if lines else "(empty directory)"
            return ToolResult(
                success=True,
                output=output,
                data={"path": str(path), "count": len(entries)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"List error: {exc}")

    async def _search(self, path: Path, params: dict[str, Any]) -> ToolResult:
        pattern: str = params.get("pattern", "*")
        recursive: bool = params.get("recursive", True)

        if not path.exists():
            return ToolResult(success=False, error=f"Path not found: '{path}'.")

        try:
            root = path if path.is_dir() else path.parent
            glob_fn = root.rglob if recursive else root.glob
            matches = [str(p) for p in glob_fn(pattern) if p.is_file()]
            matches.sort()
            output = "\n".join(matches) if matches else f"No files matching '{pattern}'."
            return ToolResult(
                success=True,
                output=output,
                data={"pattern": pattern, "count": len(matches)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Search error: {exc}")

    async def _move(self, path: Path, params: dict[str, Any]) -> ToolResult:
        dest = Path(params["destination"])
        if not path.exists():
            return ToolResult(success=False, error=f"Source not found: '{path}'.")
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            import shutil

            shutil.move(str(path), str(dest))
            return ToolResult(
                success=True,
                output=f"Moved '{path}' → '{dest}'.",
                data={"source": str(path), "destination": str(dest)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Move error: {exc}")

    async def _copy(self, path: Path, params: dict[str, Any]) -> ToolResult:
        dest = Path(params["destination"])
        if not path.exists():
            return ToolResult(success=False, error=f"Source not found: '{path}'.")
        try:
            import shutil

            dest.parent.mkdir(parents=True, exist_ok=True)
            if path.is_dir():
                shutil.copytree(str(path), str(dest))
            else:
                shutil.copy2(str(path), str(dest))
            return ToolResult(
                success=True,
                output=f"Copied '{path}' → '{dest}'.",
                data={"source": str(path), "destination": str(dest)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Copy error: {exc}")

    async def _delete(self, path: Path, _params: dict[str, Any]) -> ToolResult:
        if not path.exists():
            return ToolResult(success=False, error=f"Path not found: '{path}'.")
        try:
            import shutil

            if path.is_dir():
                shutil.rmtree(str(path))
            else:
                path.unlink()
            return ToolResult(
                success=True,
                output=f"Deleted '{path}'.",
                data={"path": str(path)},
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Delete error: {exc}")

    # ─── Path Guard ───

    def _is_allowed(self, path: Path) -> bool:
        """Return True when *path* (or its intended parent) falls under an
        allowed directory, or when no restrictions have been configured."""
        if not self._allowed_dirs:
            return True
        resolved = path.resolve()
        return any(
            resolved == allowed or allowed in resolved.parents
            for allowed in self._allowed_dirs
        )
