"""SchedulerTool — asyncio-based cron-like task scheduler.

Risk levels per action:
  - list   → SAFE
  - cancel → LOW
  - pause  → LOW
  - resume → LOW
  - schedule → MEDIUM

Tasks are identified by a short UUID and driven by asyncio.Task objects.
Interval-based tasks fire every N seconds; cron-expression tasks parse a
five-field expression (minute hour dom month dow) and compute the next trigger
time using the system clock.

An optional ``event_callback`` receives a ``WatcherEvent`` each time a task
fires so the agent event bus can react to scheduled triggers.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any, Callable, Coroutine

from homunculus.core.types import (
    ActionRisk,
    ActionStep,
    ScheduledTask,
    ScheduleState,
    ToolDefinition,
    ToolResult,
    WatcherEvent,
    WatcherEventType,
)
from homunculus.errors import SchedulerError, SchedulerTaskNotFoundError

logger = logging.getLogger(__name__)

_SUPPORTED_ACTIONS = frozenset({"schedule", "cancel", "list", "pause", "resume"})

# Risk level exposed per action for the SafetyLayer.
ACTION_RISK: dict[str, ActionRisk] = {
    "schedule": ActionRisk.MEDIUM,
    "cancel": ActionRisk.LOW,
    "list": ActionRisk.SAFE,
    "pause": ActionRisk.LOW,
    "resume": ActionRisk.LOW,
}

_DEFINITION = ToolDefinition(
    name="scheduler",
    display_name="Scheduler",
    description=(
        "Register and manage recurring tasks. "
        "Supports interval-based scheduling (every N seconds) and "
        "simple five-field cron expressions. "
        "Actions: schedule, cancel, list, pause, resume."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["schedule", "cancel", "list", "pause", "resume"],
                "description": "Scheduler operation to perform.",
            },
            "task_id": {
                "type": "string",
                "description": "Unique task identifier (required for cancel/pause/resume).",
            },
            "name": {
                "type": "string",
                "description": "(schedule) Human-readable task name.",
            },
            "interval_seconds": {
                "type": "number",
                "description": "(schedule) Fire every N seconds (mutually exclusive with cron).",
            },
            "cron": {
                "type": "string",
                "description": (
                    "(schedule) Five-field cron expression: "
                    "'minute hour day_of_month month day_of_week'. "
                    "Wildcards (*) and step values (*/n) are supported."
                ),
            },
            "callback_event": {
                "type": "string",
                "description": "(schedule) Event type emitted when the task fires.",
            },
            "max_runs": {
                "type": "integer",
                "description": "(schedule) Stop after this many runs (0 = unlimited).",
                "default": 0,
            },
            "metadata": {
                "type": "object",
                "description": "(schedule) Arbitrary key-value metadata stored with the task.",
            },
        },
        "required": ["action"],
    },
    risk_level=ActionRisk.SAFE,
    enabled=True,
    version="1.0.0",
    author="homunculus",
)

# Type alias for the optional callback.
EventCallback = Callable[[WatcherEvent], Coroutine[Any, Any, None]]


class SchedulerTool:
    """Manage recurring asyncio tasks with interval or cron-based triggers.

    Parameters
    ----------
    event_callback:
        Async callable invoked with a ``WatcherEvent`` each time a task fires.
        When ``None``, events are only logged.
    """

    def __init__(self, event_callback: EventCallback | None = None) -> None:
        self._event_callback = event_callback
        # keyed by task_id
        self._tasks: dict[str, ScheduledTask] = {}
        self._asyncio_tasks: dict[str, asyncio.Task[None]] = {}

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        action = parameters.get("action", "")
        if action not in _SUPPORTED_ACTIONS:
            logger.warning("SchedulerTool.validate: unknown action '%s'.", action)
            return False

        if action == "schedule":
            has_interval = parameters.get("interval_seconds") is not None
            has_cron = bool(parameters.get("cron"))
            if not has_interval and not has_cron:
                logger.warning(
                    "SchedulerTool.validate: 'interval_seconds' or 'cron' required for schedule."
                )
                return False
            if has_interval and has_cron:
                logger.warning(
                    "SchedulerTool.validate: provide either 'interval_seconds' or 'cron', not both."
                )
                return False
            if has_interval:
                interval = parameters.get("interval_seconds")
                if not isinstance(interval, (int, float)) or interval <= 0:
                    logger.warning(
                        "SchedulerTool.validate: interval_seconds must be a positive number."
                    )
                    return False
            if has_cron:
                cron_str = parameters.get("cron", "")
                if not _validate_cron(cron_str):
                    logger.warning(
                        "SchedulerTool.validate: invalid cron expression '%s'.", cron_str
                    )
                    return False

        if action in ("cancel", "pause", "resume") and not parameters.get("task_id"):
            logger.warning(
                "SchedulerTool.validate: 'task_id' required for '%s'.", action
            )
            return False

        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        action: str = parameters["action"]

        dispatch = {
            "schedule": self._schedule,
            "cancel": self._cancel,
            "list": self._list,
            "pause": self._pause,
            "resume": self._resume,
        }
        handler = dispatch.get(action)
        if handler is None:
            return ToolResult(success=False, error=f"Unknown action '{action}'.")

        return await handler(parameters)

    async def rollback(self, execution_id: str) -> bool:
        # execution_id for 'schedule' is the task_id itself.
        if execution_id in self._tasks:
            await self._cancel({"task_id": execution_id})
            return True
        logger.warning(
            "SchedulerTool.rollback: task_id '%s' not found.", execution_id
        )
        return False

    # ─── Action Handlers ───

    async def _schedule(self, params: dict[str, Any]) -> ToolResult:
        task_id = uuid.uuid4().hex[:12]
        name: str = params.get("name") or f"task-{task_id}"
        interval: float = float(params.get("interval_seconds") or 0)
        cron_str: str = params.get("cron") or ""
        callback_event: str = params.get("callback_event") or "schedule_triggered"
        max_runs: int = int(params.get("max_runs") or 0)
        metadata: dict[str, Any] = params.get("metadata") or {}

        next_run = _compute_next_run(interval, cron_str)

        task = ScheduledTask(
            task_id=task_id,
            name=name,
            cron_expression=cron_str,
            interval_seconds=interval,
            callback_event=callback_event,
            state=ScheduleState.PENDING,
            next_run=next_run,
            max_runs=max_runs,
            metadata=metadata,
        )
        self._tasks[task_id] = task

        # Launch the background asyncio task.
        asyncio_task = asyncio.create_task(
            self._run_loop(task_id), name=f"scheduler-{task_id}"
        )
        self._asyncio_tasks[task_id] = asyncio_task
        task.state = ScheduleState.RUNNING

        logger.info(
            "SchedulerTool: scheduled task '%s' (id=%s, interval=%s, cron='%s').",
            name, task_id, interval or None, cron_str or None,
        )
        return ToolResult(
            success=True,
            output=f"Task '{name}' scheduled (id={task_id}).",
            data={
                "task_id": task_id,
                "name": name,
                "next_run": next_run,
                "state": task.state.value,
            },
            rollback_id=task_id,
        )

    async def _cancel(self, params: dict[str, Any]) -> ToolResult:
        task_id: str = params.get("task_id", "")
        task = self._tasks.get(task_id)
        if task is None:
            return ToolResult(
                success=False,
                error=f"Task '{task_id}' not found.",
            )

        asyncio_task = self._asyncio_tasks.pop(task_id, None)
        if asyncio_task and not asyncio_task.done():
            asyncio_task.cancel()
            try:
                await asyncio_task
            except (asyncio.CancelledError, Exception):
                pass

        task.state = ScheduleState.CANCELLED
        logger.info("SchedulerTool: cancelled task '%s' (id=%s).", task.name, task_id)
        return ToolResult(
            success=True,
            output=f"Task '{task.name}' (id={task_id}) cancelled.",
            data={"task_id": task_id, "state": task.state.value},
        )

    async def _list(self, _params: dict[str, Any]) -> ToolResult:
        if not self._tasks:
            return ToolResult(
                success=True,
                output="No scheduled tasks.",
                data={"tasks": []},
            )

        task_summaries: list[dict[str, Any]] = []
        lines: list[str] = []
        for task in self._tasks.values():
            summary = {
                "task_id": task.task_id,
                "name": task.name,
                "state": task.state.value,
                "cron": task.cron_expression,
                "interval_seconds": task.interval_seconds,
                "next_run": task.next_run,
                "last_run": task.last_run,
                "run_count": task.run_count,
                "max_runs": task.max_runs,
            }
            task_summaries.append(summary)
            lines.append(
                f"[{task.state.value.upper()}] {task.name} (id={task.task_id}) "
                f"runs={task.run_count}/{task.max_runs or '∞'}"
            )

        return ToolResult(
            success=True,
            output="\n".join(lines),
            data={"tasks": task_summaries, "count": len(task_summaries)},
        )

    async def _pause(self, params: dict[str, Any]) -> ToolResult:
        task_id: str = params.get("task_id", "")
        task = self._tasks.get(task_id)
        if task is None:
            return ToolResult(success=False, error=f"Task '{task_id}' not found.")
        if task.state != ScheduleState.RUNNING:
            return ToolResult(
                success=False,
                error=f"Task '{task_id}' is not running (state={task.state.value}).",
            )

        task.state = ScheduleState.PAUSED
        logger.info("SchedulerTool: paused task '%s' (id=%s).", task.name, task_id)
        return ToolResult(
            success=True,
            output=f"Task '{task.name}' (id={task_id}) paused.",
            data={"task_id": task_id, "state": task.state.value},
        )

    async def _resume(self, params: dict[str, Any]) -> ToolResult:
        task_id: str = params.get("task_id", "")
        task = self._tasks.get(task_id)
        if task is None:
            return ToolResult(success=False, error=f"Task '{task_id}' not found.")
        if task.state != ScheduleState.PAUSED:
            return ToolResult(
                success=False,
                error=f"Task '{task_id}' is not paused (state={task.state.value}).",
            )

        task.state = ScheduleState.RUNNING
        logger.info("SchedulerTool: resumed task '%s' (id=%s).", task.name, task_id)
        return ToolResult(
            success=True,
            output=f"Task '{task.name}' (id={task_id}) resumed.",
            data={"task_id": task_id, "state": task.state.value},
        )

    # ─── Internal Loop ───

    async def _run_loop(self, task_id: str) -> None:
        """Drive a single scheduled task until it is cancelled, exhausted, or errors out."""
        task = self._tasks.get(task_id)
        if task is None:
            return

        while True:
            # Wait until the next scheduled trigger.
            delay = max(0.0, task.next_run - time.time())
            try:
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                return

            # Respect pause state: spin quietly until resumed.
            if task.state == ScheduleState.PAUSED:
                await asyncio.sleep(1)
                continue

            if task.state not in (ScheduleState.RUNNING,):
                return

            # Fire the task.
            task.last_run = time.time()
            task.run_count += 1
            logger.debug(
                "SchedulerTool: task '%s' fired (run #%d).", task.name, task.run_count
            )

            event = WatcherEvent(
                event_type=WatcherEventType.SCHEDULE_TRIGGERED,
                source=task.task_id,
                data={
                    "task_id": task.task_id,
                    "name": task.name,
                    "run_count": task.run_count,
                    "callback_event": task.callback_event,
                    "metadata": task.metadata,
                },
                priority=5,
            )
            if self._event_callback is not None:
                try:
                    await self._event_callback(event)
                except Exception as exc:
                    logger.error(
                        "SchedulerTool: event_callback raised for task '%s': %s",
                        task.name, exc,
                    )

            # Check run limit.
            if task.max_runs > 0 and task.run_count >= task.max_runs:
                task.state = ScheduleState.COMPLETED
                logger.info(
                    "SchedulerTool: task '%s' completed after %d runs.",
                    task.name, task.run_count,
                )
                return

            # Compute next trigger time.
            task.next_run = _compute_next_run(task.interval_seconds, task.cron_expression)


# ─── Cron helpers ───


def _validate_cron(expr: str) -> bool:
    """Return True when *expr* is a syntactically valid five-field cron expression."""
    fields = expr.strip().split()
    if len(fields) != 5:
        return False
    ranges = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
    for field, (lo, hi) in zip(fields, ranges):
        if not _validate_cron_field(field, lo, hi):
            return False
    return True


def _validate_cron_field(field: str, lo: int, hi: int) -> bool:
    """Return True when *field* is a valid cron field within [lo, hi]."""
    if field == "*":
        return True
    if field.startswith("*/"):
        step_str = field[2:]
        return step_str.isdigit() and int(step_str) > 0
    if field.isdigit():
        return lo <= int(field) <= hi
    # Accept comma-separated lists.
    if "," in field:
        return all(
            part.isdigit() and lo <= int(part) <= hi for part in field.split(",")
        )
    return False


def _compute_next_run(interval_seconds: float, cron_str: str) -> float:
    """Return the unix timestamp of the next scheduled trigger."""
    now = time.time()
    if interval_seconds > 0:
        return now + interval_seconds
    if cron_str:
        return _next_cron_time(cron_str)
    return now + 60  # Fallback: 1 minute.


def _next_cron_time(expr: str) -> float:
    """Compute the next trigger time for a five-field cron expression.

    Resolves to the next whole minute that satisfies every field constraint,
    starting from the current time + 1 minute.
    """
    import datetime

    fields = expr.strip().split()
    if len(fields) != 5:
        raise SchedulerError(f"Invalid cron expression: '{expr}'")

    minute_f, hour_f, dom_f, month_f, dow_f = fields

    now = datetime.datetime.now()
    # Start searching from the next minute.
    candidate = now.replace(second=0, microsecond=0) + datetime.timedelta(minutes=1)

    for _ in range(366 * 24 * 60):  # search up to 1 year ahead
        if (
            _cron_field_matches(minute_f, candidate.minute, 0, 59)
            and _cron_field_matches(hour_f, candidate.hour, 0, 23)
            and _cron_field_matches(dom_f, candidate.day, 1, 31)
            and _cron_field_matches(month_f, candidate.month, 1, 12)
            and _cron_field_matches(dow_f, candidate.weekday(), 0, 6)
        ):
            return candidate.timestamp()
        candidate += datetime.timedelta(minutes=1)

    raise SchedulerError(f"Could not compute next run time for cron '{expr}'.")


def _cron_field_matches(field: str, value: int, lo: int, hi: int) -> bool:
    """Return True when *value* satisfies the cron *field* constraint."""
    if field == "*":
        return True
    if field.startswith("*/"):
        step = int(field[2:])
        return (value - lo) % step == 0
    if "," in field:
        return value in {int(p) for p in field.split(",") if p.isdigit()}
    if field.isdigit():
        return value == int(field)
    return False
