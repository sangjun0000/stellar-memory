"""Built-in tool implementations for Homunculus.

All tools satisfy the ``BaseTool`` Protocol defined in ``homunculus.tools.base``.
``BrowserTool`` is guarded by a try/except because Playwright is an optional
dependency; the other three tools rely only on the standard library and httpx
(which is a required dependency).
"""

from __future__ import annotations

from homunculus.tools.builtin.api_caller import APICallerTool
from homunculus.tools.builtin.code_writer import CodeWriterTool
from homunculus.tools.builtin.filesystem import FileSystemTool
from homunculus.tools.builtin.scheduler import SchedulerTool
from homunculus.tools.builtin.shell import ShellTool

# BrowserTool requires Playwright, which is optional.
try:
    from homunculus.tools.builtin.browser import BrowserTool

    __all__ = [
        "APICallerTool",
        "BrowserTool",
        "CodeWriterTool",
        "FileSystemTool",
        "SchedulerTool",
        "ShellTool",
    ]
except ImportError:
    __all__ = [
        "APICallerTool",
        "CodeWriterTool",
        "FileSystemTool",
        "SchedulerTool",
        "ShellTool",
    ]
