"""APICallerTool — HTTP/REST API caller using httpx.

Risk level is MEDIUM because outbound network calls may expose credentials,
trigger side-effects on remote systems, or be used to reach internal services.
The host blocklist and optional allowlist are the primary safety controls.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any
from urllib.parse import urlparse

import httpx

from homunculus.core.types import ActionRisk, ToolDefinition, ToolResult
from homunculus.errors import ToolExecutionError

logger = logging.getLogger(__name__)

# Hosts that are unconditionally refused to prevent SSRF attacks against
# loopback interfaces and cloud metadata endpoints.
_DEFAULT_BLOCKED_HOSTS: list[str] = [
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
    "::1",
    "metadata.google.internal",
    "169.254.169.254",
]

# Response header keys whose values are masked in execution records to avoid
# leaking credentials into logs.
_DEFAULT_MASK_HEADERS: list[str] = [
    "authorization",
    "x-api-key",
    "cookie",
    "set-cookie",
]

_SUPPORTED_METHODS = frozenset(
    {"get", "post", "put", "delete", "patch", "head", "options"}
)

# Methods that carry a body (per RFC 7231).
_BODY_METHODS = frozenset({"post", "put", "patch"})

# Methods that produce side-effects on the remote system and therefore warrant
# a rollback record.
_MUTABLE_METHODS = frozenset({"post", "put", "delete", "patch"})

_DEFINITION = ToolDefinition(
    name="api_caller",
    display_name="API Caller",
    description=(
        "Make HTTP/REST API calls. "
        "Supported methods: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS. "
        "Internal / loopback hosts are blocked by default."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": list(_SUPPORTED_METHODS),
                "description": "HTTP method to use (case-insensitive).",
            },
            "url": {
                "type": "string",
                "description": "Fully-qualified URL starting with http:// or https://.",
            },
            "headers": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "description": "Optional request headers.",
            },
            "body": {
                "oneOf": [{"type": "object"}, {"type": "string"}],
                "description": "Request body — dict is sent as JSON, string as raw bytes.",
            },
            "timeout": {
                "type": "integer",
                "default": 30,
                "description": "Request timeout in seconds (1–120).",
            },
            "follow_redirects": {
                "type": "boolean",
                "default": True,
                "description": "Whether to follow HTTP redirects automatically.",
            },
        },
        "required": ["action", "url"],
    },
    risk_level=ActionRisk.MEDIUM,
    enabled=True,
    version="1.0.0",
    author="homunculus",
)


class APICallerTool:
    """HTTP/REST API caller with SSRF protection and execution history.

    Outbound requests are gated by a host blocklist (and optional allowlist).
    Execution records are stored in ``_history`` keyed by a short UUID so that
    the safety layer can inspect what was called.  Automatic rollback is not
    possible for most HTTP mutations; the ``rollback`` method logs a warning and
    returns ``False`` for those cases.

    Constructor parameters
    ----------------------
    default_timeout:
        Seconds to wait before abandoning a request (default 30).
    max_response_bytes:
        Maximum bytes of response body retained in ``ToolResult.output``
        (default 256 KB).  The raw HTTP body may be larger; it is simply
        truncated at this boundary.
    allowed_hosts:
        When non-``None``, only hostnames in this list are permitted.  Takes
        precedence over ``blocked_hosts``.
    blocked_hosts:
        Hostnames that are unconditionally refused.  Defaults to the built-in
        SSRF protection list.
    mask_headers:
        Header names whose values are replaced with ``***MASKED***`` in the
        execution history.
    """

    def __init__(
        self,
        default_timeout: int = 30,
        max_response_bytes: int = 256 * 1024,
        allowed_hosts: list[str] | None = None,
        blocked_hosts: list[str] | None = None,
        mask_headers: list[str] | None = None,
    ) -> None:
        self._default_timeout = default_timeout
        self._max_response_bytes = max_response_bytes
        self._allowed_hosts = allowed_hosts
        self._blocked_hosts = list(blocked_hosts or _DEFAULT_BLOCKED_HOSTS)
        self._mask_headers = [h.lower() for h in (mask_headers or _DEFAULT_MASK_HEADERS)]
        # Execution history keyed by exec_id for rollback inspection.
        self._history: dict[str, dict[str, Any]] = {}

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        action = parameters.get("action", "")
        if action not in _SUPPORTED_METHODS:
            logger.warning("APICallerTool.validate: unsupported action '%s'.", action)
            return False

        url = parameters.get("url", "")
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            logger.warning(
                "APICallerTool.validate: URL must start with http:// or https://, got '%s'.",
                url,
            )
            return False

        if not self._is_host_allowed(url):
            logger.warning("APICallerTool.validate: host blocked for URL '%s'.", url)
            return False

        timeout = parameters.get("timeout", self._default_timeout)
        if not isinstance(timeout, int) or not (1 <= timeout <= 120):
            logger.warning(
                "APICallerTool.validate: timeout must be an integer in [1, 120], got '%s'.",
                timeout,
            )
            return False

        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        action: str = parameters.get("action", "get").lower()
        url: str = parameters.get("url", "")
        headers: dict[str, str] = parameters.get("headers") or {}
        body: Any = parameters.get("body")
        timeout: int = int(parameters.get("timeout", self._default_timeout))
        follow_redirects: bool = parameters.get("follow_redirects", True)

        exec_id = uuid.uuid4().hex[:12]
        self._record_execution(exec_id, action, url, headers, body)

        # Guard: double-check host even when called without validate().
        if not self._is_host_allowed(url):
            return ToolResult(
                success=False,
                error=f"Host blocked by safety policy for URL '{url}'.",
            )

        try:
            async with httpx.AsyncClient(
                timeout=timeout,
                follow_redirects=follow_redirects,
            ) as client:
                method = action.upper()
                kwargs: dict[str, Any] = {"headers": headers}

                if body is not None and action in _BODY_METHODS:
                    if isinstance(body, dict):
                        kwargs["json"] = body
                    else:
                        kwargs["content"] = str(body).encode()

                response = await client.request(method, url, **kwargs)

                # Truncate large bodies to avoid memory pressure.
                raw_text = response.text
                content = (
                    raw_text[: self._max_response_bytes]
                    if len(raw_text) > self._max_response_bytes
                    else raw_text
                )
                if len(raw_text) > self._max_response_bytes:
                    content += "\n[response truncated]"

                success = response.status_code < 400
                logger.debug(
                    "APICallerTool: %s %s → %d (exec_id=%s)",
                    method, url, response.status_code, exec_id,
                )
                return ToolResult(
                    success=success,
                    output=content,
                    error="" if success else f"HTTP {response.status_code}",
                    data={
                        "status_code": response.status_code,
                        "headers": dict(response.headers),
                        "url": str(response.url),
                        "method": method,
                        "exec_id": exec_id,
                    },
                    rollback_id=exec_id if action in _MUTABLE_METHODS else "",
                )

        except httpx.TimeoutException:
            return ToolResult(
                success=False,
                error=f"Request timed out after {timeout}s.",
            )
        except httpx.RequestError as exc:
            return ToolResult(success=False, error=f"Request error: {exc}")
        except Exception as exc:
            raise ToolExecutionError(f"API call failed: {exc}") from exc

    async def rollback(self, execution_id: str) -> bool:
        record = self._history.get(execution_id)
        if not record:
            logger.warning(
                "APICallerTool.rollback: execution_id '%s' not found.", execution_id
            )
            return False

        method = record.get("method", "").upper()

        # Read-only methods have no side-effects — rollback is trivially a no-op.
        if method in ("GET", "HEAD", "OPTIONS"):
            return True

        # Mutating methods cannot be automatically reversed without knowing the
        # remote API's semantics.  Log a warning so operators can act manually.
        logger.warning(
            "APICallerTool.rollback: cannot auto-rollback %s %s (exec_id=%s). "
            "Manual rollback required.",
            method,
            record.get("url"),
            execution_id,
        )
        return False

    # ─── Private ───

    def _is_host_allowed(self, url: str) -> bool:
        """Return True when the URL's hostname passes blocklist and allowlist checks."""
        try:
            parsed = urlparse(url)
            host = parsed.hostname or ""
        except Exception:
            return False

        if host in self._blocked_hosts:
            return False

        if self._allowed_hosts is not None and host not in self._allowed_hosts:
            return False

        return True

    def _mask_sensitive_headers(self, headers: dict[str, str]) -> dict[str, str]:
        """Return a copy of *headers* with sensitive values replaced."""
        return {
            key: ("***MASKED***" if key.lower() in self._mask_headers else value)
            for key, value in headers.items()
        }

    def _record_execution(
        self,
        exec_id: str,
        method: str,
        url: str,
        headers: dict[str, str],
        body: Any,
    ) -> None:
        """Persist a sanitised record of the execution for rollback inspection."""
        self._history[exec_id] = {
            "method": method.upper(),
            "url": url,
            "headers": self._mask_sensitive_headers(headers or {}),
            "body": str(body)[:1000] if body is not None else None,
        }
