"""CodeWriterTool — create, edit, analyze, and refactor Python source files.

Risk levels per action:
  - analyze  → LOW   (read-only, uses ast module)
  - create   → MEDIUM (new file; reversible via rollback)
  - edit     → HIGH  (mutates existing file; backup stored for rollback)
  - refactor → HIGH  (broad text replacement; backup stored for rollback)

Backups of mutated files are kept in an in-memory dict keyed by a short UUID
so that ``rollback`` can restore the previous content exactly.
"""

from __future__ import annotations

import ast
import logging
import uuid
from pathlib import Path
from typing import Any

from homunculus.core.types import ActionRisk, CodeAnalysis, ToolDefinition, ToolResult
from homunculus.errors import CodeAnalysisError, ToolExecutionError

logger = logging.getLogger(__name__)

_SUPPORTED_ACTIONS = frozenset({"create", "edit", "analyze", "refactor"})

# Risk level exposed per action for the SafetyLayer.
ACTION_RISK: dict[str, ActionRisk] = {
    "analyze": ActionRisk.LOW,
    "create": ActionRisk.MEDIUM,
    "edit": ActionRisk.HIGH,
    "refactor": ActionRisk.HIGH,
}

_DEFINITION = ToolDefinition(
    name="code_writer",
    display_name="Code Writer",
    description=(
        "Create, edit, analyze, and refactor Python source files. "
        "Actions: create (new file), edit (replace a function/class body), "
        "analyze (AST-based structure report), refactor (rename identifiers)."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["create", "edit", "analyze", "refactor"],
                "description": "Operation to perform on the target file.",
            },
            "path": {
                "type": "string",
                "description": "Absolute or relative path to the Python file.",
            },
            "content": {
                "type": "string",
                "description": "(create) Full source code for the new file.",
            },
            "target_name": {
                "type": "string",
                "description": (
                    "(edit) Name of the function or class whose body will be replaced. "
                    "(refactor) Old identifier name to rename."
                ),
            },
            "new_content": {
                "type": "string",
                "description": "(edit) Replacement source for the function/class body.",
            },
            "new_name": {
                "type": "string",
                "description": "(refactor) New identifier name to substitute.",
            },
        },
        "required": ["action", "path"],
    },
    risk_level=ActionRisk.LOW,  # Registry baseline; SafetyLayer uses ACTION_RISK per call.
    enabled=True,
    version="1.0.0",
    author="homunculus",
)

# Maximum source file size we are willing to load into memory.
_MAX_FILE_BYTES = 512 * 1024  # 512 KB


class CodeWriterTool:
    """Perform structured operations on Python source files.

    All mutating operations (create, edit, refactor) store a backup of the
    prior file state in ``_backups`` before touching disk.  The ``rollback``
    method restores from that backup, or deletes the file if the action was
    ``create`` (i.e. the file did not exist before).
    """

    def __init__(self) -> None:
        # Maps rollback_id → {"path": str, "prior_content": str | None}
        # prior_content is None when the file was created from scratch.
        self._backups: dict[str, dict[str, Any]] = {}

    # ─── BaseTool Protocol ───

    @property
    def definition(self) -> ToolDefinition:
        return _DEFINITION

    async def validate(self, parameters: dict[str, Any]) -> bool:
        action = parameters.get("action", "")
        if action not in _SUPPORTED_ACTIONS:
            logger.warning("CodeWriterTool.validate: unknown action '%s'.", action)
            return False

        path_str = parameters.get("path", "")
        if not path_str:
            logger.warning("CodeWriterTool.validate: 'path' is required.")
            return False

        if action == "create" and not parameters.get("content"):
            logger.warning("CodeWriterTool.validate: 'content' required for create.")
            return False

        if action == "edit":
            if not parameters.get("target_name"):
                logger.warning(
                    "CodeWriterTool.validate: 'target_name' required for edit."
                )
                return False
            if not parameters.get("new_content"):
                logger.warning(
                    "CodeWriterTool.validate: 'new_content' required for edit."
                )
                return False

        if action == "refactor":
            if not parameters.get("target_name"):
                logger.warning(
                    "CodeWriterTool.validate: 'target_name' required for refactor."
                )
                return False
            if not parameters.get("new_name"):
                logger.warning(
                    "CodeWriterTool.validate: 'new_name' required for refactor."
                )
                return False

        return True

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        action: str = parameters["action"]
        path = Path(parameters["path"])

        dispatch = {
            "create": self._create,
            "edit": self._edit,
            "analyze": self._analyze,
            "refactor": self._refactor,
        }
        handler = dispatch.get(action)
        if handler is None:
            return ToolResult(success=False, error=f"Unknown action '{action}'.")

        return await handler(path, parameters)

    async def rollback(self, execution_id: str) -> bool:
        record = self._backups.get(execution_id)
        if not record:
            logger.warning(
                "CodeWriterTool.rollback: execution_id '%s' not found.", execution_id
            )
            return False

        path = Path(record["path"])
        prior_content: str | None = record.get("prior_content")

        try:
            if prior_content is None:
                # The file was newly created; remove it to undo.
                if path.exists():
                    path.unlink()
                    logger.info(
                        "CodeWriterTool.rollback: deleted created file '%s'.", path
                    )
            else:
                path.write_text(prior_content, encoding="utf-8")
                logger.info(
                    "CodeWriterTool.rollback: restored '%s' to prior state.", path
                )
            return True
        except OSError as exc:
            logger.error(
                "CodeWriterTool.rollback: failed to restore '%s': %s", path, exc
            )
            return False

    # ─── Action Handlers ───

    async def _create(self, path: Path, params: dict[str, Any]) -> ToolResult:
        content: str = params["content"]
        exec_id = uuid.uuid4().hex[:12]

        # Validate that the content is syntactically correct before writing.
        syntax_error = _check_syntax(content)
        if syntax_error:
            return ToolResult(
                success=False,
                error=f"Syntax error in content: {syntax_error}",
            )

        # Record prior state (None = file did not exist).
        prior: str | None = None
        if path.exists():
            prior = path.read_text(encoding="utf-8")

        self._backups[exec_id] = {"path": str(path), "prior_content": prior}

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            logger.debug("CodeWriterTool._create: wrote '%s' (%d chars).", path, len(content))
            return ToolResult(
                success=True,
                output=f"Created '{path}' ({len(content)} characters).",
                data={"path": str(path), "size": len(content)},
                rollback_id=exec_id,
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Create error: {exc}")

    async def _edit(self, path: Path, params: dict[str, Any]) -> ToolResult:
        target_name: str = params["target_name"]
        new_content: str = params["new_content"]
        exec_id = uuid.uuid4().hex[:12]

        result = _load_file(path)
        if result is None:
            return ToolResult(success=False, error=f"File not found: '{path}'.")
        original_source, _tree = result

        self._backups[exec_id] = {"path": str(path), "prior_content": original_source}

        try:
            updated_source = _replace_node_body(original_source, target_name, new_content)
        except CodeAnalysisError as exc:
            return ToolResult(success=False, error=str(exc))

        syntax_error = _check_syntax(updated_source)
        if syntax_error:
            return ToolResult(
                success=False,
                error=f"Resulting source has a syntax error: {syntax_error}",
            )

        try:
            path.write_text(updated_source, encoding="utf-8")
            logger.debug("CodeWriterTool._edit: updated '%s' (target=%s).", path, target_name)
            return ToolResult(
                success=True,
                output=f"Edited '{target_name}' in '{path}'.",
                data={"path": str(path), "target": target_name},
                rollback_id=exec_id,
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Edit write error: {exc}")

    async def _analyze(self, path: Path, _params: dict[str, Any]) -> ToolResult:
        result = _load_file(path)
        if result is None:
            return ToolResult(success=False, error=f"File not found: '{path}'.")
        source, tree = result

        analysis = _analyze_tree(str(path), source, tree)
        lines = [
            f"File: {analysis.file_path}",
            f"Lines: {analysis.line_count}",
            f"Language: {analysis.language}",
            "",
            "Imports:",
        ]
        lines.extend(f"  {imp}" for imp in analysis.imports) or lines.append("  (none)")
        lines.append("")
        lines.append("Functions:")
        for fn in analysis.functions:
            lines.append(
                f"  {fn['name']}  (line {fn['line']}, args={fn['args']}, async={fn['is_async']})"
            )
        if not analysis.functions:
            lines.append("  (none)")
        lines.append("")
        lines.append("Classes:")
        for cls in analysis.classes:
            methods_str = ", ".join(cls["methods"])
            lines.append(f"  {cls['name']}  (line {cls['line']}, methods=[{methods_str}])")
        if not analysis.classes:
            lines.append("  (none)")
        if analysis.issues:
            lines.append("")
            lines.append("Issues:")
            lines.extend(f"  {issue}" for issue in analysis.issues)

        return ToolResult(
            success=True,
            output="\n".join(lines),
            data={
                "file_path": analysis.file_path,
                "line_count": analysis.line_count,
                "functions": analysis.functions,
                "classes": analysis.classes,
                "imports": analysis.imports,
                "issues": analysis.issues,
            },
        )

    async def _refactor(self, path: Path, params: dict[str, Any]) -> ToolResult:
        old_name: str = params["target_name"]
        new_name: str = params["new_name"]
        exec_id = uuid.uuid4().hex[:12]

        result = _load_file(path)
        if result is None:
            return ToolResult(success=False, error=f"File not found: '{path}'.")
        source, _tree = result

        self._backups[exec_id] = {"path": str(path), "prior_content": source}

        # Token-level rename: replace whole-word occurrences of old_name.
        updated_source, count = _rename_identifier(source, old_name, new_name)
        if count == 0:
            return ToolResult(
                success=False,
                error=f"Identifier '{old_name}' not found in '{path}'.",
            )

        syntax_error = _check_syntax(updated_source)
        if syntax_error:
            return ToolResult(
                success=False,
                error=f"Resulting source has a syntax error: {syntax_error}",
            )

        try:
            path.write_text(updated_source, encoding="utf-8")
            logger.debug(
                "CodeWriterTool._refactor: renamed '%s' → '%s' (%d occurrences) in '%s'.",
                old_name, new_name, count, path,
            )
            return ToolResult(
                success=True,
                output=(
                    f"Renamed '{old_name}' → '{new_name}' "
                    f"({count} occurrence(s)) in '{path}'."
                ),
                data={
                    "path": str(path),
                    "old_name": old_name,
                    "new_name": new_name,
                    "occurrences": count,
                },
                rollback_id=exec_id,
            )
        except OSError as exc:
            return ToolResult(success=False, error=f"Refactor write error: {exc}")


# ─── Module-level helpers ───


def _load_file(path: Path) -> tuple[str, ast.Module] | None:
    """Read *path*, parse it, and return (source, ast_tree), or None if missing."""
    if not path.exists() or not path.is_file():
        return None
    try:
        raw = path.read_bytes()
        if len(raw) > _MAX_FILE_BYTES:
            raise ToolExecutionError(
                f"File '{path}' exceeds the {_MAX_FILE_BYTES // 1024} KB read limit."
            )
        source = raw.decode("utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
        return source, tree
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Cannot parse '{path}': {exc}") from exc


def _check_syntax(source: str) -> str:
    """Return an error message string if *source* has a syntax error, else empty string."""
    try:
        ast.parse(source)
        return ""
    except SyntaxError as exc:
        return f"line {exc.lineno}: {exc.msg}"


def _analyze_tree(file_path: str, source: str, tree: ast.Module) -> CodeAnalysis:
    """Build a CodeAnalysis dataclass from the parsed AST."""
    lines = source.splitlines()
    functions: list[dict[str, Any]] = []
    classes: list[dict[str, Any]] = []
    imports: list[str] = []
    issues: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append(ast.unparse(node))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Only include top-level and class-level functions, not nested ones.
            arg_names = [a.arg for a in node.args.args]
            functions.append(
                {
                    "name": node.name,
                    "line": node.lineno,
                    "args": arg_names,
                    "is_async": isinstance(node, ast.AsyncFunctionDef),
                }
            )
        elif isinstance(node, ast.ClassDef):
            methods = [
                n.name
                for n in ast.walk(node)
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            ]
            classes.append(
                {
                    "name": node.name,
                    "line": node.lineno,
                    "methods": methods,
                }
            )

    # Basic issue detection.
    if not imports:
        issues.append("No imports found.")

    return CodeAnalysis(
        file_path=file_path,
        language="python",
        functions=functions,
        classes=classes,
        imports=imports,
        line_count=len(lines),
        issues=issues,
    )


def _replace_node_body(source: str, target_name: str, new_content: str) -> str:
    """Replace the source of the function or class named *target_name* with *new_content*.

    The replacement uses line numbers from the AST to splice the original
    source text, preserving all surrounding code exactly.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Cannot parse source: {exc}") from exc

    target_node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef | None = None
    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and node.name == target_name
        ):
            target_node = node  # type: ignore[assignment]
            break

    if target_node is None:
        raise CodeAnalysisError(
            f"No function or class named '{target_name}' found in source."
        )

    lines = source.splitlines(keepends=True)
    start = target_node.lineno - 1  # convert 1-based to 0-based
    end = (target_node.end_lineno or target_node.lineno)  # end_lineno is 1-based inclusive

    # Detect indentation of the definition line to reindent the replacement.
    def_line = lines[start]
    indent = len(def_line) - len(def_line.lstrip())
    prefix = " " * indent

    # Ensure new_content ends with a newline.
    if not new_content.endswith("\n"):
        new_content += "\n"

    # Indent every line of the replacement.
    indented_lines = [
        (prefix + line) if line.strip() else line
        for line in new_content.splitlines(keepends=True)
    ]

    updated = lines[:start] + indented_lines + lines[end:]
    return "".join(updated)


def _rename_identifier(source: str, old_name: str, new_name: str) -> tuple[str, int]:
    """Replace all whole-word occurrences of *old_name* with *new_name*.

    Returns (updated_source, replacement_count).  A word boundary check
    prevents partial matches (e.g. renaming "foo" does not touch "foobar").
    """
    import re

    pattern = re.compile(r"\b" + re.escape(old_name) + r"\b")
    updated, count = pattern.subn(new_name, source)
    return updated, count
