"""ToolRegistry — central catalogue of all registered tools."""

from __future__ import annotations

import importlib
import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any

from homunculus.core.types import ActionRisk, ToolDefinition

from .base import BaseTool

logger = logging.getLogger(__name__)

# Risk level string → enum mapping used when building JSON Schema definitions.
_RISK_LABELS: dict[ActionRisk, str] = {
    ActionRisk.SAFE: "safe",
    ActionRisk.LOW: "low",
    ActionRisk.MEDIUM: "medium",
    ActionRisk.HIGH: "high",
    ActionRisk.CRITICAL: "critical",
}


class ToolRegistry:
    """Thread-safe in-memory registry that manages available tools.

    Extension point: call ``register`` at startup with any ``BaseTool``
    implementation — built-ins, plugins, or test doubles — and the rest of
    the system will pick them up automatically.
    """

    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}
        self._memory_bridge: Any = None

    def set_memory_bridge(self, bridge: Any) -> None:
        """Set the shared MemoryBridge for memory-aware plugins."""
        self._memory_bridge = bridge

    # ─── Mutation ───

    def register(self, tool: BaseTool) -> None:
        """Add *tool* to the registry.

        Overwrites a previously registered tool with the same name, which
        enables hot-reloading of plugins during development.
        """
        name = tool.definition.name
        if name in self._tools:
            logger.warning("Tool '%s' is already registered — replacing it.", name)
        self._tools[name] = tool
        logger.debug("Registered tool '%s' (risk=%s)", name, tool.definition.risk_level.value)

    def unregister(self, name: str) -> None:
        """Remove a tool by name.  No-op when the name is unknown."""
        removed = self._tools.pop(name, None)
        if removed is None:
            logger.debug("unregister('%s') — tool not found, skipping.", name)

    # ─── Query ───

    def get(self, name: str) -> BaseTool | None:
        """Return the tool registered under *name*, or ``None``."""
        return self._tools.get(name)

    def list_all(self) -> list[ToolDefinition]:
        """Return definitions for every registered tool, sorted by name."""
        return [t.definition for t in sorted(self._tools.values(), key=lambda t: t.definition.name)]

    # ─── AI Model Integration ───

    def get_tool_definitions(self) -> list[dict[str, Any]]:
        """Serialise all enabled tools into the JSON Schema format expected by
        AI model tool-calling APIs (OpenAI / Anthropic / Ollama compatible).

        Only tools whose ``definition.enabled`` flag is ``True`` are included.
        """
        result: list[dict[str, Any]] = []

        for tool in self._tools.values():
            defn = tool.definition
            if not defn.enabled:
                continue

            # The outer shape follows the OpenAI function-calling schema which
            # is also accepted by Anthropic and most Ollama models.
            tool_schema: dict[str, Any] = {
                "type": "function",
                "function": {
                    "name": defn.name,
                    "description": (
                        f"[{_RISK_LABELS[defn.risk_level].upper()} risk] {defn.description}"
                    ),
                    "parameters": defn.parameters or {
                        "type": "object",
                        "properties": {},
                        "required": [],
                    },
                },
            }
            result.append(tool_schema)

        return result

    # ─── Plugin Loading ───

    def load_plugins(self, plugin_dir: str) -> int:
        """Scan *plugin_dir* for tool plugins and register each one found.

        A plugin is a subdirectory that contains a ``manifest.toml`` file.
        The manifest must declare at least ``module`` (dotted import path) and
        ``class`` (class name within that module).  Optionally it may declare
        ``package_dir`` — a path relative to the plugin subdirectory to add to
        ``sys.path`` before importing.

        Example manifest.toml::

            module = "my_plugin.tool"
            class  = "MyTool"

        Parameters
        ----------
        plugin_dir:
            Absolute or relative path to the directory that contains plugin
            subdirectories.

        Returns
        -------
        int
            Number of tools successfully loaded and registered.
        """
        base = Path(plugin_dir)
        if not base.is_dir():
            logger.debug("load_plugins: directory '%s' does not exist, skipping.", plugin_dir)
            return 0

        try:
            import tomllib  # Python 3.11+
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[no-reattr,import-not-found]
            except ImportError:
                logger.error(
                    "load_plugins: neither 'tomllib' nor 'tomli' is available. "
                    "Cannot parse manifest.toml files."
                )
                return 0

        loaded = 0
        for subdir in sorted(base.iterdir()):
            if not subdir.is_dir():
                continue

            manifest_path = subdir / "manifest.toml"
            if not manifest_path.exists():
                logger.debug("load_plugins: no manifest.toml in '%s', skipping.", subdir)
                continue

            try:
                with manifest_path.open("rb") as fh:
                    manifest = tomllib.load(fh)

                module_name: str = manifest["module"]
                class_name: str = manifest["class"]

                # Optionally extend sys.path so relative imports work.
                package_dir = manifest.get("package_dir")
                if package_dir:
                    pkg_path = str(subdir / package_dir)
                    if pkg_path not in sys.path:
                        sys.path.insert(0, pkg_path)
                else:
                    # Add the plugin subdirectory itself by default.
                    plugin_path = str(subdir)
                    if plugin_path not in sys.path:
                        sys.path.insert(0, plugin_path)

                module = importlib.import_module(module_name)
                tool_class = getattr(module, class_name)
                tool_instance: BaseTool = tool_class()

                # Inject MemoryBridge into memory-aware tools
                if hasattr(tool_instance, "set_memory") and callable(tool_instance.set_memory):
                    if self._memory_bridge is not None:
                        tool_instance.set_memory(self._memory_bridge)
                        logger.info("Injected MemoryBridge into '%s'", class_name)

                self.register(tool_instance)
                loaded += 1
                logger.info(
                    "load_plugins: loaded '%s.%s' from '%s'.",
                    module_name, class_name, subdir.name,
                )
            except Exception as exc:
                logger.error(
                    "load_plugins: failed to load plugin from '%s': %s",
                    subdir, exc,
                )

        return loaded
