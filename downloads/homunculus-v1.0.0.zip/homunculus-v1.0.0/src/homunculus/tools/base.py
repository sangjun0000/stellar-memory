"""BaseTool Protocol — the contract every tool must satisfy."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from homunculus.core.types import ToolDefinition, ToolResult


@runtime_checkable
class BaseTool(Protocol):
    """Structural protocol that all Homunculus tools must implement.

    Using a Protocol (rather than an ABC) keeps the domain layer free of
    concrete inheritance and allows third-party plugins to satisfy the
    contract without importing this module.
    """

    @property
    def definition(self) -> ToolDefinition:
        """Metadata describing this tool to the registry and AI model."""
        ...

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        """Run the tool with the supplied parameters.

        Parameters are expected to have already been validated; implementations
        may still perform light defensive checks.
        """
        ...

    async def validate(self, parameters: dict[str, Any]) -> bool:
        """Return True when *parameters* satisfy the tool's requirements.

        Should be called by the executor before ``execute`` so that invalid
        inputs are caught early and reported cleanly.
        """
        ...

    async def rollback(self, execution_id: str) -> bool:
        """Attempt to undo the side-effects produced by a previous execution.

        Parameters
        ----------
        execution_id:
            Opaque identifier returned (or recorded) when the original
            ``execute`` call was made.

        Returns
        -------
        bool
            ``True`` when the rollback succeeded, ``False`` when the tool does
            not support rollback or the operation failed.

        The default implementation always returns ``False``.  Tools that
        perform reversible actions (e.g. file writes, API mutations) should
        override this method.
        """
        return False
