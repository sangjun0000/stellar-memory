"""Code quality metrics for Python source files."""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from homunculus.errors import CodeAnalysisError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Cyclomatic-complexity branch nodes
# Each of these AST node types introduces an independent control-flow path.
# ---------------------------------------------------------------------------
_BRANCH_NODES = (
    ast.If,
    ast.For,
    ast.AsyncFor,
    ast.While,
    ast.ExceptHandler,
    ast.With,
    ast.AsyncWith,
    ast.Assert,
    ast.comprehension,
)

# Boolean operators (and / or) also add branches
_BOOL_OP_NODES = (ast.BoolOp,)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def calculate_complexity(source: str) -> float:
    """Return the cyclomatic complexity of *source*.

    Complexity is computed as::

        M = E - N + 2P

    approximated here as ``1 + number_of_decision_points`` for the whole
    module, which is the standard McCabe approximation.

    Decision points counted:
    - ``if`` / ``elif``
    - ``for`` / ``async for``
    - ``while``
    - ``except`` handlers
    - ``with`` / ``async with``
    - ``assert``
    - ``comprehension`` (list/set/dict comp, generator)
    - ``and`` / ``or`` boolean operators (each operator counted once)

    Raises :class:`~homunculus.errors.CodeAnalysisError` on syntax errors.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(
            f"Syntax error while calculating complexity: {exc}"
        ) from exc

    decision_points = 0

    for node in ast.walk(tree):
        if isinstance(node, _BRANCH_NODES):
            decision_points += 1
        elif isinstance(node, ast.BoolOp):
            # Each additional operand after the first is a branch
            decision_points += len(node.values) - 1

    return float(1 + decision_points)


def calculate_metrics(path: str | Path) -> dict[str, Any]:
    """Analyse *path* and return a metrics dictionary.

    The returned dict contains:

    ``line_count`` (int)
        Total number of lines in the file.

    ``blank_lines`` (int)
        Lines that are empty or contain only whitespace.

    ``comment_lines`` (int)
        Lines whose first non-whitespace character is ``#``.

    ``code_lines`` (int)
        ``line_count - blank_lines - comment_lines``.

    ``complexity`` (float)
        Module-level cyclomatic complexity (see :func:`calculate_complexity`).

    ``function_lengths`` (list[dict])
        Per-function metrics — each entry has ``name``, ``line_number``,
        ``length`` (number of lines in the function body).

    ``max_nesting_depth`` (int)
        Deepest nesting level found in the file.

    ``average_function_length`` (float)
        Mean function body length; ``0.0`` when no functions are present.

    Raises :class:`~homunculus.errors.CodeAnalysisError` on I/O or syntax
    errors.
    """
    file_path = Path(path)
    try:
        source = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise CodeAnalysisError(f"Cannot read file {path}: {exc}") from exc

    lines = source.splitlines()
    line_count = len(lines)
    blank_lines = sum(1 for ln in lines if not ln.strip())
    comment_lines = sum(1 for ln in lines if ln.strip().startswith("#"))
    code_lines = line_count - blank_lines - comment_lines

    complexity = calculate_complexity(source)
    function_lengths = _function_lengths(source)
    max_nesting = _max_nesting_depth(source)

    avg_length = (
        sum(f["length"] for f in function_lengths) / len(function_lengths)
        if function_lengths
        else 0.0
    )

    return {
        "line_count": line_count,
        "blank_lines": blank_lines,
        "comment_lines": comment_lines,
        "code_lines": code_lines,
        "complexity": complexity,
        "function_lengths": function_lengths,
        "max_nesting_depth": max_nesting,
        "average_function_length": avg_length,
    }


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _function_lengths(source: str) -> list[dict[str, Any]]:
    """Return line-length metadata for every function in *source*."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    results: list[dict[str, Any]] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        # end_lineno is available in Python 3.8+
        end = getattr(node, "end_lineno", node.lineno)
        length = max(1, end - node.lineno + 1)

        results.append(
            {
                "name": node.name,
                "line_number": node.lineno,
                "length": length,
                "is_async": isinstance(node, ast.AsyncFunctionDef),
            }
        )

    return results


def _max_nesting_depth(source: str) -> int:
    """Walk the AST and return the maximum compound-statement nesting depth."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    # Compound statement types that increase nesting depth
    _NESTING = (
        ast.If,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.With,
        ast.AsyncWith,
        ast.Try,
        ast.FunctionDef,
        ast.AsyncFunctionDef,
        ast.ClassDef,
    )

    max_depth = 0

    def _walk(node: ast.AST, depth: int) -> None:
        nonlocal max_depth
        if depth > max_depth:
            max_depth = depth
        for child in ast.iter_child_nodes(node):
            extra = 1 if isinstance(child, _NESTING) else 0
            _walk(child, depth + extra)

    _walk(tree, 0)
    return max_depth
