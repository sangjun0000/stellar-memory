"""AST-based Python code analysis."""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from homunculus.core.types import CodeAnalysis
from homunculus.errors import CodeAnalysisError

logger = logging.getLogger(__name__)

# Standard library module names that should not be reported as external deps.
# This set is representative; a full list would use sys.stdlib_module_names (3.10+).
_STDLIB_TOP_LEVEL: frozenset[str] = frozenset(
    {
        "__future__", "abc", "ast", "asyncio", "builtins", "collections",
        "contextlib", "copy", "dataclasses", "datetime", "enum", "functools",
        "hashlib", "importlib", "inspect", "io", "itertools", "json", "logging",
        "math", "operator", "os", "pathlib", "pickle", "platform", "queue",
        "random", "re", "shutil", "signal", "socket", "sqlite3", "string",
        "struct", "subprocess", "sys", "tempfile", "threading", "time",
        "traceback", "types", "typing", "unittest", "urllib", "uuid",
        "warnings", "weakref",
    }
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def analyze_file(path: str | Path) -> CodeAnalysis:
    """Parse *path* and return a fully-populated :class:`CodeAnalysis`.

    Raises :class:`~homunculus.errors.CodeAnalysisError` when the file cannot
    be read or parsed.
    """
    file_path = Path(path)
    try:
        source = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise CodeAnalysisError(f"Cannot read file {path}: {exc}") from exc

    try:
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError as exc:
        raise CodeAnalysisError(
            f"Syntax error in {path} at line {exc.lineno}: {exc.msg}"
        ) from exc

    functions = extract_functions(source)
    classes = extract_classes(source)
    imports = extract_imports(source)
    dependencies = get_dependencies(source)
    line_count = len(source.splitlines())

    return CodeAnalysis(
        file_path=str(file_path),
        language="python",
        functions=functions,
        classes=classes,
        imports=imports,
        line_count=line_count,
        complexity=0.0,  # caller can enrich with code_metrics.calculate_complexity
        dependencies=dependencies,
        issues=[],
    )


def extract_functions(source: str) -> list[dict[str, Any]]:
    """Return metadata for every function/async-function defined in *source*.

    Each entry contains:
      - ``name`` (str)
      - ``args`` (list[str]) — positional and keyword argument names
      - ``decorators`` (list[str])
      - ``line_number`` (int)
      - ``is_async`` (bool)
      - ``docstring`` (str | None)
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Syntax error while extracting functions: {exc}") from exc

    results: list[dict[str, Any]] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        args: list[str] = [
            arg.arg
            for arg in (
                node.args.posonlyargs
                + node.args.args
                + node.args.kwonlyargs
            )
        ]
        if node.args.vararg:
            args.append(f"*{node.args.vararg.arg}")
        if node.args.kwarg:
            args.append(f"**{node.args.kwarg.arg}")

        decorators: list[str] = []
        for dec in node.decorator_list:
            decorators.append(ast.unparse(dec) if hasattr(ast, "unparse") else _unparse_decorator(dec))

        docstring: str | None = ast.get_docstring(node)

        results.append(
            {
                "name": node.name,
                "args": args,
                "decorators": decorators,
                "line_number": node.lineno,
                "is_async": isinstance(node, ast.AsyncFunctionDef),
                "docstring": docstring,
            }
        )

    return results


def extract_classes(source: str) -> list[dict[str, Any]]:
    """Return metadata for every class defined in *source*.

    Each entry contains:
      - ``name`` (str)
      - ``bases`` (list[str]) — base class names
      - ``methods`` (list[str]) — method names defined directly on the class
      - ``decorators`` (list[str])
      - ``line_number`` (int)
      - ``docstring`` (str | None)
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Syntax error while extracting classes: {exc}") from exc

    results: list[dict[str, Any]] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue

        bases: list[str] = []
        for base in node.bases:
            bases.append(ast.unparse(base) if hasattr(ast, "unparse") else _unparse_name(base))

        methods: list[str] = [
            item.name
            for item in node.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]

        decorators: list[str] = []
        for dec in node.decorator_list:
            decorators.append(ast.unparse(dec) if hasattr(ast, "unparse") else _unparse_decorator(dec))

        docstring: str | None = ast.get_docstring(node)

        results.append(
            {
                "name": node.name,
                "bases": bases,
                "methods": methods,
                "decorators": decorators,
                "line_number": node.lineno,
                "docstring": docstring,
            }
        )

    return results


def extract_imports(source: str) -> list[str]:
    """Return a flat list of fully-qualified import strings from *source*.

    Examples: ``"import os"``, ``"from pathlib import Path"``.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Syntax error while extracting imports: {exc}") from exc

    imports: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                stmt = f"import {alias.name}"
                if alias.asname:
                    stmt += f" as {alias.asname}"
                imports.append(stmt)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            names = ", ".join(
                (f"{a.name} as {a.asname}" if a.asname else a.name)
                for a in node.names
            )
            dots = "." * (node.level or 0)
            imports.append(f"from {dots}{module} import {names}")

    return imports


def get_dependencies(source: str) -> list[str]:
    """Return top-level external module names imported by *source*.

    Standard-library and relative imports are excluded.  The list is
    deduplicated and sorted alphabetically.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise CodeAnalysisError(f"Syntax error while resolving dependencies: {exc}") from exc

    deps: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top = alias.name.split(".")[0]
                if top not in _STDLIB_TOP_LEVEL:
                    deps.add(top)
        elif isinstance(node, ast.ImportFrom):
            # Relative imports (level > 0) are always internal
            if node.level and node.level > 0:
                continue
            if node.module:
                top = node.module.split(".")[0]
                if top not in _STDLIB_TOP_LEVEL:
                    deps.add(top)

    return sorted(deps)


# ---------------------------------------------------------------------------
# Private fallback helpers for Python < 3.9 (no ast.unparse)
# ---------------------------------------------------------------------------


def _unparse_name(node: ast.expr) -> str:
    """Best-effort name extraction for simple name/attribute nodes."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{_unparse_name(node.value)}.{node.attr}"
    return "<expr>"


def _unparse_decorator(node: ast.expr) -> str:
    """Best-effort decorator stringification for Python < 3.9."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{_unparse_name(node.value)}.{node.attr}"
    if isinstance(node, ast.Call):
        func = _unparse_decorator(node.func)
        return f"{func}(...)"
    return "<decorator>"
