"""ToolExecutor — validates parameters then runs a tool, wrapping the result
in an ActionResult with timing information."""

from __future__ import annotations

import logging
import time
from typing import Any

from homunculus.core.types import ActionResult, ActionStep
from homunculus.errors import ToolError, ToolExecutionError, ToolPermissionError

from .registry import ToolRegistry

logger = logging.getLogger(__name__)


class ToolExecutor:
    """Orchestrates the validate → execute → measure cycle for a single step.

    Keeping this class thin means each concern (lookup, validation, execution,
    timing) is handled in exactly one place and can be tested in isolation via
    a mock registry.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry = registry

    async def execute(self, step: ActionStep) -> ActionResult:
        """Find the tool for *step*, validate parameters, run it, and return
        a fully populated ``ActionResult``.

        Failure modes are captured in ``ActionResult.error`` rather than raised
        so that the caller (Actor) can continue executing remaining steps.
        """
        start_ms = time.monotonic() * 1000

        tool = self._registry.get(step.tool_name)
        if tool is None:
            return ActionResult(
                step=step,
                success=False,
                error=f"No tool registered with name '{step.tool_name}'.",
                duration_ms=self._elapsed(start_ms),
            )

        # Merge the step-level action into the parameters dict so tools can
        # dispatch on it internally (e.g. FileSystemTool dispatching on "read").
        parameters: dict[str, Any] = {"action": step.action, **step.parameters}

        # Validate before incurring side-effects.
        try:
            valid = await tool.validate(parameters)
        except ToolPermissionError as exc:
            logger.warning("Permission denied in validation for tool '%s': %s", step.tool_name, exc)
            return ActionResult(
                step=step,
                success=False,
                error=f"Permission error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )
        except ToolError as exc:
            logger.warning("Tool error in validation for tool '%s': %s", step.tool_name, exc)
            return ActionResult(
                step=step,
                success=False,
                error=f"Validation error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )
        except Exception as exc:
            logger.exception("Validation raised for tool '%s'", step.tool_name)
            return ActionResult(
                step=step,
                success=False,
                error=f"Validation error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )

        if not valid:
            return ActionResult(
                step=step,
                success=False,
                error=f"Parameter validation failed for tool '{step.tool_name}'.",
                duration_ms=self._elapsed(start_ms),
            )

        # Execute.
        try:
            tool_result = await tool.execute(parameters)
        except ToolExecutionError as exc:
            logger.warning("Execution error for tool '%s': %s", step.tool_name, exc)
            return ActionResult(
                step=step,
                success=False,
                error=f"Execution error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )
        except ToolError as exc:
            logger.warning("Tool error for tool '%s': %s", step.tool_name, exc)
            return ActionResult(
                step=step,
                success=False,
                error=f"Tool error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )
        except Exception as exc:
            logger.exception("Execution raised for tool '%s'", step.tool_name)
            return ActionResult(
                step=step,
                success=False,
                error=f"Execution error: {exc}",
                duration_ms=self._elapsed(start_ms),
            )

        return ActionResult(
            step=step,
            success=tool_result.success,
            output=tool_result.output,
            error=tool_result.error,
            duration_ms=self._elapsed(start_ms),
            # Propagate rollback_id as a side-effect annotation when present.
            side_effects=[f"rollback_id:{tool_result.rollback_id}"] if tool_result.rollback_id else [],
        )

    @staticmethod
    def _elapsed(start_ms: float) -> float:
        return time.monotonic() * 1000 - start_ms
