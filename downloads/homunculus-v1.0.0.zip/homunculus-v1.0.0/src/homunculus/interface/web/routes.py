"""REST API routes for Homunculus Web UI."""

from __future__ import annotations

import logging
import time
import uuid
from typing import TYPE_CHECKING

from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from homunculus.core.agent import Agent
    from homunculus.interface.web.ws_bridge import WsBridge

_start_time = time.time()

# Module-level references set by create_routes()
_agent: Agent | None = None
_bridge: WsBridge | None = None


def create_routes(agent: Agent, bridge: WsBridge) -> list[Route]:
    global _agent, _bridge
    _agent = agent
    _bridge = bridge

    return [
        Route("/api/chat", endpoint=chat_handler, methods=["POST"]),
        Route("/api/status", endpoint=status_handler, methods=["GET"]),
        Route("/api/memory", endpoint=memory_handler, methods=["GET"]),
        Route("/api/memory/search", endpoint=memory_search_handler, methods=["GET"]),
        Route("/api/tools", endpoint=tools_handler, methods=["GET"]),
        Route("/api/command", endpoint=command_handler, methods=["POST"]),
        Route("/api/onboarding", endpoint=onboarding_handler, methods=["GET"]),
        Route("/api/model", endpoint=model_handler, methods=["GET"]),
    ]


async def chat_handler(request: Request) -> JSONResponse:
    body = await request.json()
    message = body.get("message", "")
    if not message:
        return JSONResponse({"error": "message required"}, status_code=400)

    cycle_id = uuid.uuid4().hex[:12]
    await _agent.handle_message(message, source="web")
    return JSONResponse({"status": "queued", "cycle_id": cycle_id})


async def status_handler(request: Request) -> JSONResponse:
    model = _agent.model_manager.active_model
    model_info = None
    if model:
        model_info = {
            "provider": model.provider,
            "model_id": model.model_id,
            "display_name": model.display_name,
            "is_local": model.is_local,
        }

    memory_stats = {}
    try:
        stats = await _agent.memory.stats()
        if stats:
            memory_stats = {
                "total": stats.get("total", 0),
                "zones": stats.get("zones", {}),
            }
    except Exception as exc:
        logger.warning("Failed to fetch memory stats for status: %s", exc)

    onboarding_done = _agent.settings.get("onboarding", "completed", False)

    return JSONResponse({
        "state": _agent.state.value,
        "model": model_info,
        "memory": memory_stats,
        "safety_level": _agent.settings.safety_level,
        "uptime_seconds": int(time.time() - _start_time),
        "onboarding_completed": onboarding_done,
    })


async def memory_handler(request: Request) -> JSONResponse:
    limit = int(request.query_params.get("limit", "20"))
    stats = {}
    recent = []

    try:
        raw_stats = await _agent.memory.stats()
        if raw_stats:
            zone_names = {0: "Core", 1: "Inner", 2: "Outer", 3: "Belt", 4: "Cloud"}
            stats = {
                "total": raw_stats.get("total", 0),
                "zones": {
                    zone_names.get(z, str(z)): c
                    for z, c in raw_stats.get("zones", {}).items()
                },
            }
    except Exception as exc:
        logger.warning("Failed to fetch memory stats: %s", exc)

    try:
        entries = await _agent.memory.timeline(limit=limit)
        for e in entries:
            recent.append({
                "id": e.get("id", ""),
                "content": e.get("content", "")[:200],
                "zone": e.get("zone", -1),
                "importance": e.get("importance", 0),
            })
    except Exception as exc:
        logger.warning("Failed to fetch memory timeline: %s", exc)

    return JSONResponse({"stats": stats, "recent": recent})


async def memory_search_handler(request: Request) -> JSONResponse:
    query = request.query_params.get("q", "")
    limit = int(request.query_params.get("limit", "5"))

    if not query:
        return JSONResponse({"error": "q parameter required"}, status_code=400)

    results = []
    try:
        memories = await _agent.memory.recall(query, limit=limit, include_graph=False)
        for m in memories:
            results.append({
                "id": m.memory_id,
                "content": m.content[:200],
                "zone": m.zone,
                "score": round(m.score, 3),
            })
    except Exception as exc:
        logger.warning("Memory search failed for query '%s': %s", query, exc)

    return JSONResponse({"query": query, "results": results})


async def tools_handler(request: Request) -> JSONResponse:
    tools = _agent.tool_registry.list_all()
    tool_list = []
    for t in tools:
        tool_list.append({
            "name": t.name,
            "display_name": t.display_name,
            "description": t.description,
            "risk_level": t.risk_level.value,
            "enabled": t.enabled,
        })
    return JSONResponse({"tools": tool_list})


async def command_handler(request: Request) -> JSONResponse:
    body = await request.json()
    cmd = body.get("command", "")
    if not cmd:
        return JSONResponse({"error": "command required"}, status_code=400)

    from homunculus.interface.commands import handle_command

    result = await handle_command(_agent, cmd)
    if result == "__QUIT__":
        return JSONResponse({"result": "Quit is not supported in Web UI. Close the browser tab instead."})
    return JSONResponse({"result": result or ""})


async def onboarding_handler(request: Request) -> JSONResponse:
    completed = _agent.settings.get("onboarding", "completed", False)
    return JSONResponse({
        "completed": completed,
        "current_step": 0 if not completed else -1,
        "total_steps": 4,
    })


async def model_handler(request: Request) -> JSONResponse:
    model = _agent.model_manager.active_model
    active = None
    if model:
        active = {
            "provider": model.provider,
            "model_id": model.model_id,
            "is_local": model.is_local,
        }

    routing_enabled = _agent.settings.get("routing", "enabled", False)

    return JSONResponse({
        "active": active,
        "available_providers": ["ollama", "openai", "anthropic", "deepseek", "google"],
        "routing_enabled": routing_enabled,
    })
