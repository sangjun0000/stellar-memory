"""Lightweight web server for Homunculus Web UI."""

from __future__ import annotations

import logging
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.routing import Mount, WebSocketRoute
from starlette.staticfiles import StaticFiles

from homunculus.interface.web.routes import create_routes
from homunculus.interface.web.ws_bridge import WsBridge

if TYPE_CHECKING:
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)


class WebServer:
    """Starlette-based web server for Homunculus Web UI.

    Serves a single-page application with:
    - REST API endpoints for status, memory, tools
    - WebSocket endpoint for real-time agent communication
    - Static files for the frontend SPA
    """

    def __init__(
        self,
        agent: Agent,
        host: str = "127.0.0.1",
        port: int = 7777,
        open_browser: bool = True,
    ) -> None:
        self._agent = agent
        self._host = host
        self._port = port
        self._open_browser = open_browser
        self._bridge: WsBridge | None = None
        self._app: Starlette | None = None

    def create_app(self) -> Starlette:
        self._bridge = WsBridge(self._agent)
        api_routes = create_routes(self._agent, self._bridge)
        static_dir = Path(__file__).parent / "static"

        self._app = Starlette(
            routes=[
                *api_routes,
                WebSocketRoute("/ws", self._bridge.websocket_endpoint),
                Mount("/", app=StaticFiles(directory=str(static_dir), html=True)),
            ],
            middleware=[
                Middleware(
                    CORSMiddleware,
                    allow_origins=[
                        "http://127.0.0.1:*",
                        "http://localhost:*",
                    ],
                    allow_methods=["*"],
                    allow_headers=["*"],
                ),
            ],
            on_startup=[self._on_startup],
            on_shutdown=[self._on_shutdown],
        )
        return self._app

    async def _on_startup(self) -> None:
        await self._agent.start()
        self._bridge.subscribe()
        url = f"http://{self._host}:{self._port}"
        logger.info("Homunculus Web UI running at %s", url)
        if self._open_browser:
            webbrowser.open(url)

    async def _on_shutdown(self) -> None:
        self._bridge.unsubscribe()
        await self._agent.stop()

    async def run(self) -> None:
        import uvicorn

        app = self.create_app()
        config = uvicorn.Config(
            app,
            host=self._host,
            port=self._port,
            log_level="warning",
        )
        server = uvicorn.Server(config)
        await server.serve()
