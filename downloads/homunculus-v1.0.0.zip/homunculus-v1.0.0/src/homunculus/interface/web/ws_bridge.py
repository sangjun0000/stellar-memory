"""EventBus to WebSocket bridge for real-time UI updates."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

from starlette.websockets import WebSocket, WebSocketDisconnect

if TYPE_CHECKING:
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)


class WsBridge:
    """Bridges EventBus events to WebSocket clients.

    Subscribes to agent events and broadcasts them as JSON messages
    to all connected WebSocket clients.
    """

    def __init__(self, agent: Agent) -> None:
        self._agent = agent
        self._clients: set[WebSocket] = set()

    @property
    def client_count(self) -> int:
        return len(self._clients)

    def subscribe(self) -> None:
        bus = self._agent.event_bus
        bus.on("agent.response", self._on_response)
        bus.on("agent.state.changed", self._on_state_change)
        bus.on("agent.cycle.started", self._on_cycle_started)
        bus.on("agent.cycle.completed", self._on_cycle_completed)
        bus.on("agent.error", self._on_error)

    def unsubscribe(self) -> None:
        bus = self._agent.event_bus
        bus.off("agent.response", self._on_response)
        bus.off("agent.state.changed", self._on_state_change)
        bus.off("agent.cycle.started", self._on_cycle_started)
        bus.off("agent.cycle.completed", self._on_cycle_completed)
        bus.off("agent.error", self._on_error)

    # ── WebSocket Endpoint ──

    async def websocket_endpoint(self, ws: WebSocket) -> None:
        await ws.accept()
        self._clients.add(ws)
        logger.info("WebSocket client connected (total: %d)", len(self._clients))

        try:
            while True:
                data = await ws.receive_text()
                msg = json.loads(data)
                await self._handle_client_message(msg, ws)
        except WebSocketDisconnect:
            pass
        except Exception:
            logger.exception("WebSocket error")
        finally:
            self._clients.discard(ws)
            logger.info("WebSocket client disconnected (total: %d)", len(self._clients))

    async def _handle_client_message(self, msg: dict, ws: WebSocket) -> None:
        msg_type = msg.get("type", "")

        if msg_type == "chat":
            text = msg.get("message", "")
            if text:
                await self._agent.handle_message(text, source="web")

        elif msg_type == "command":
            from homunculus.interface.commands import handle_command

            cmd = msg.get("command", "")
            result = await handle_command(self._agent, cmd)
            if result and result != "__QUIT__":
                await self._broadcast({
                    "type": "command_result",
                    "result": result,
                })

        elif msg_type == "ping":
            await ws.send_text(json.dumps({"type": "pong"}, ensure_ascii=False))

    # ── Event Handlers (EventBus → WebSocket) ──

    def _on_response(self, data: str | None) -> None:
        if data:
            asyncio.ensure_future(self._broadcast({
                "type": "agent_response",
                "content": data,
            }))

    def _on_state_change(self, state: Any | None) -> None:
        if state:
            asyncio.ensure_future(self._broadcast({
                "type": "state_change",
                "state": state.value if hasattr(state, "value") else str(state),
            }))

    def _on_cycle_started(self, cycle: Any | None) -> None:
        if cycle:
            asyncio.ensure_future(self._broadcast({
                "type": "cycle_started",
                "cycle_id": getattr(cycle, "cycle_id", ""),
            }))

    def _on_cycle_completed(self, cycle: Any | None) -> None:
        if cycle:
            asyncio.ensure_future(self._broadcast({
                "type": "cycle_completed",
                "cycle_id": getattr(cycle, "cycle_id", ""),
            }))

    def _on_error(self, exc: Exception | None) -> None:
        if exc:
            asyncio.ensure_future(self._broadcast({
                "type": "error",
                "message": str(exc),
            }))

    # ── Broadcast ──

    async def _broadcast(self, message: dict) -> None:
        text = json.dumps(message, ensure_ascii=False)
        dead: set[WebSocket] = set()
        for ws in self._clients:
            try:
                await ws.send_text(text)
            except Exception:
                dead.add(ws)
        self._clients -= dead
