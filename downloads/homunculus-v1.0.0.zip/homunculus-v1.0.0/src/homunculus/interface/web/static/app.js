/* Homunculus Web UI — Client Application */

class HomuculusApp {
    constructor() {
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.reconnectDelay = 1000;
        this.el = {};
    }

    init() {
        this.bindElements();
        this.bindEvents();
        this.connectWebSocket();
        this.loadInitialData();
    }

    bindElements() {
        this.el = {
            messages: document.getElementById('messages'),
            input: document.getElementById('message-input'),
            sendBtn: document.getElementById('send-btn'),
            form: document.getElementById('input-form'),
            agentState: document.getElementById('agent-state'),
            modelName: document.getElementById('model-name'),
            typing: document.getElementById('typing-indicator'),
            sidebar: document.getElementById('sidebar'),
            sidebarToggle: document.getElementById('sidebar-toggle'),
            statusContent: document.getElementById('status-content'),
            memoryStats: document.getElementById('memory-stats'),
            toolsList: document.getElementById('tools-list'),
        };
    }

    bindEvents() {
        this.el.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendMessage();
        });

        this.el.input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        this.el.input.addEventListener('input', () => this.autoResize());

        this.el.sidebarToggle.addEventListener('click', () => {
            this.el.sidebar.classList.toggle('hidden');
            // Mobile: use 'visible' class
            if (window.innerWidth <= 768) {
                this.el.sidebar.classList.toggle('visible');
            }
        });
    }

    // ── WebSocket ──

    connectWebSocket() {
        const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.ws = new WebSocket(`${proto}//${location.host}/ws`);

        this.ws.onopen = () => {
            this.reconnectAttempts = 0;
        };

        this.ws.onmessage = (event) => {
            const msg = JSON.parse(event.data);
            this.handleServerMessage(msg);
        };

        this.ws.onclose = () => {
            this.scheduleReconnect();
        };

        this.ws.onerror = () => {};
    }

    scheduleReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) return;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts);
        this.reconnectAttempts++;
        setTimeout(() => this.connectWebSocket(), Math.min(delay, 30000));
    }

    // ── Server Messages ──

    handleServerMessage(msg) {
        switch (msg.type) {
            case 'agent_response':
                this.hideTyping();
                this.addMessage('agent', msg.content);
                this.refreshSidebar();
                break;
            case 'state_change':
                this.updateState(msg.state);
                break;
            case 'cycle_started':
                this.showTyping();
                break;
            case 'cycle_completed':
                this.hideTyping();
                break;
            case 'command_result':
                this.addMessage('system', msg.result);
                break;
            case 'error':
                this.addMessage('error', msg.message);
                this.hideTyping();
                break;
            case 'onboarding':
                this.handleOnboarding(msg);
                break;
            case 'pong':
                break;
        }
    }

    // ── Sending ──

    sendMessage() {
        const text = this.el.input.value.trim();
        if (!text) return;

        if (text.startsWith('/')) {
            this.ws.send(JSON.stringify({ type: 'command', command: text }));
            this.addMessage('system', text);
        } else {
            this.addMessage('user', text);
            this.ws.send(JSON.stringify({ type: 'chat', message: text }));
        }

        this.el.input.value = '';
        this.autoResize();
        this.el.input.focus();
    }

    // ── Message Rendering ──

    addMessage(role, content) {
        const div = document.createElement('div');
        div.className = `message message-${role}`;

        if (role === 'agent') {
            div.innerHTML = this.renderMarkdown(content);
        } else {
            div.textContent = content;
        }

        this.el.messages.appendChild(div);
        this.scrollToBottom();
    }

    renderMarkdown(text) {
        // Lightweight markdown: code blocks, inline code, bold, lists
        let html = this.escapeHtml(text);

        // Code blocks: ```...```
        html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
            return `<pre><code>${code.trim()}</code></pre>`;
        });

        // Inline code: `...`
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

        // Bold: **...**
        html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

        // List items: - item (at start of line)
        html = html.replace(/^- (.+)$/gm, '\u2022 $1');

        return html;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    scrollToBottom() {
        requestAnimationFrame(() => {
            this.el.messages.scrollTop = this.el.messages.scrollHeight;
        });
    }

    // ── State ──

    updateState(state) {
        this.el.agentState.textContent = state;
        this.el.agentState.setAttribute('data-state', state);
    }

    showTyping() {
        this.el.typing.classList.remove('hidden');
        this.scrollToBottom();
    }

    hideTyping() {
        this.el.typing.classList.add('hidden');
    }

    // ── Input ──

    autoResize() {
        const el = this.el.input;
        el.style.height = 'auto';
        el.style.height = Math.min(el.scrollHeight, 150) + 'px';
    }

    // ── Sidebar Data ──

    async loadInitialData() {
        try {
            const [status, memory, tools] = await Promise.all([
                fetch('/api/status').then(r => r.json()),
                fetch('/api/memory').then(r => r.json()),
                fetch('/api/tools').then(r => r.json()),
            ]);
            this.renderStatus(status);
            this.renderMemory(memory);
            this.renderTools(tools);

            if (status.model) {
                this.el.modelName.textContent = status.model.model_id || '...';
            }

            // Check onboarding
            if (!status.onboarding_completed) {
                this.startOnboarding();
            }
        } catch (e) {
            // Server may not be ready yet; retry after delay
            setTimeout(() => this.loadInitialData(), 2000);
        }
    }

    async refreshSidebar() {
        try {
            const [status, memory] = await Promise.all([
                fetch('/api/status').then(r => r.json()),
                fetch('/api/memory').then(r => r.json()),
            ]);
            this.renderStatus(status);
            this.renderMemory(memory);
        } catch (e) { /* ignore */ }
    }

    renderStatus(data) {
        const el = this.el.statusContent;
        let html = '';
        html += this.statRow('State', data.state || 'unknown');
        if (data.model) {
            const loc = data.model.is_local ? 'Local' : 'API';
            html += this.statRow('Model', `${data.model.display_name} (${loc})`);
        }
        html += this.statRow('Safety', data.safety_level || '-');
        if (data.uptime_seconds) {
            const m = Math.floor(data.uptime_seconds / 60);
            html += this.statRow('Uptime', m > 0 ? `${m} min` : `${data.uptime_seconds}s`);
        }
        el.innerHTML = html;
    }

    renderMemory(data) {
        const el = this.el.memoryStats;
        if (!data.stats || !data.stats.total) {
            el.innerHTML = this.statRow('Total', '0');
            return;
        }

        let html = this.statRow('Total', data.stats.total);
        const zones = data.stats.zones || {};
        const total = data.stats.total || 1;

        // Zone bar
        html += '<div class="zone-bar">';
        const classes = ['core', 'inner', 'outer', 'belt', 'cloud'];
        const names = ['Core', 'Inner', 'Outer', 'Belt', 'Cloud'];
        names.forEach((name, i) => {
            const count = zones[name] || 0;
            const pct = (count / total * 100).toFixed(1);
            html += `<div class="segment ${classes[i]}" style="width:${pct}%" title="${name}: ${count}"></div>`;
        });
        html += '</div>';

        // Zone details
        names.forEach(name => {
            const count = zones[name] || 0;
            if (count > 0) html += this.statRow(name, count);
        });

        el.innerHTML = html;
    }

    renderTools(data) {
        const el = this.el.toolsList;
        if (!data.tools || data.tools.length === 0) {
            el.innerHTML = '<div style="color:var(--text-muted);font-size:13px">No tools</div>';
            return;
        }

        el.innerHTML = data.tools.map(t => `
            <div class="tool-item">
                <div class="tool-dot ${t.enabled ? 'on' : 'off'}"></div>
                <span>${t.display_name}</span>
            </div>
        `).join('');
    }

    statRow(label, value) {
        return `<div class="stat-row"><span class="label">${label}</span><span class="value">${value}</span></div>`;
    }

    // ── Onboarding ──

    startOnboarding() {
        this.addMessage('agent',
            '안녕하세요! 저는 **Homunculus**입니다.\n' +
            '당신의 컴퓨터 안에 사는 AI예요.\n\n' +
            '저는 ChatGPT와 다릅니다:\n' +
            '- 모든 대화를 **영구적으로 기억**합니다\n' +
            '- 당신의 **파일을 읽고 관리**할 수 있습니다\n' +
            '- **인터넷 없이도** 동작합니다\n' +
            '- 그리고... **무료**입니다.\n\n' +
            '먼저 이름을 알려주시겠어요?'
        );
    }

    handleOnboarding(msg) {
        if (msg.message) {
            this.addMessage('agent', msg.message);
        }
        if (msg.options && msg.options.length > 0) {
            this.showOnboardingOptions(msg.options);
        }
    }

    showOnboardingOptions(options) {
        const container = document.createElement('div');
        container.className = 'onboarding-options';
        options.forEach(opt => {
            const btn = document.createElement('button');
            btn.className = 'onboarding-btn';
            btn.textContent = opt;
            btn.addEventListener('click', () => {
                container.remove();
                this.el.input.value = opt;
                this.sendMessage();
            });
            container.appendChild(btn);
        });
        this.el.messages.appendChild(container);
        this.scrollToBottom();
    }
}

// ── Bootstrap ──
document.addEventListener('DOMContentLoaded', () => {
    const app = new HomuculusApp();
    app.init();
});
