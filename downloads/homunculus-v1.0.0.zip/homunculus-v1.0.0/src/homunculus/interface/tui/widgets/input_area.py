"""Text input widget for user messages."""

from __future__ import annotations

from textual.message import Message
from textual.widgets import TextArea


class InputArea(TextArea):
    """Multi-line text input for user messages."""

    class Submitted(Message):
        """Fired when user presses Enter to send."""

        def __init__(self, text: str) -> None:
            super().__init__()
            self.text = text

    def __init__(self, **kwargs) -> None:
        super().__init__(
            language=None,
            show_line_numbers=False,
            **kwargs,
        )
        self.placeholder = "Type a message... (Enter to send, Shift+Enter for newline)"

    async def _on_key(self, event) -> None:
        if event.key == "enter" and not event.shift:
            text = self.text.strip()
            if text:
                self.post_message(self.Submitted(text))
                self.clear()
            event.prevent_default()
