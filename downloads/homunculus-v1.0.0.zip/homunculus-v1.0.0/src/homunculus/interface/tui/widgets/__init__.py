"""TUI widgets for Homunculus."""
