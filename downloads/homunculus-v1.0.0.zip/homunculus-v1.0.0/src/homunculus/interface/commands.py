"""CLI slash commands for Homunculus."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from homunculus.core.agent import Agent


HELP_TEXT = """
Available commands:
  /status      - Show current state, model, memory stats
  /memory      - Memory statistics and zone distribution
  /memory <q>  - Search memories for query
  /tools       - List available tools
  /safety      - Show safety level and recent actions
  /safety log  - Show action log
  /personality - Show/switch personality profile
  /model       - Show/switch AI model
  /think       - Toggle detailed thinking display
  /history     - Recent conversation history
  /help        - Show this help
  /quit        - Exit Homunculus
"""


async def handle_command(agent: Agent, command: str) -> str | None:
    """Process a slash command. Returns response text or None if not a command."""
    if not command.startswith("/"):
        return None

    parts = command[1:].strip().split(maxsplit=1)
    cmd = parts[0].lower() if parts else ""
    arg = parts[1] if len(parts) > 1 else ""

    handlers = {
        "help": _cmd_help,
        "status": _cmd_status,
        "memory": _cmd_memory,
        "tools": _cmd_tools,
        "safety": _cmd_safety,
        "personality": _cmd_personality,
        "model": _cmd_model,
        "think": _cmd_think,
        "history": _cmd_history,
        "quit": _cmd_quit,
        "exit": _cmd_quit,
    }

    handler = handlers.get(cmd)
    if handler:
        return await handler(agent, arg)
    return f"Unknown command: /{cmd}. Type /help for available commands."


async def _cmd_help(agent: Agent, arg: str) -> str:
    return HELP_TEXT


async def _cmd_status(agent: Agent, arg: str) -> str:
    lines = ["--- Homunculus Status ---"]

    model = agent.model_manager.active_model
    if model:
        loc = "Local" if model.is_local else "API"
        lines.append(f"Model: {model.display_name} ({loc})")
    else:
        lines.append("Model: Not configured")

    lines.append(f"State: {agent.state.value}")

    stats = await agent.memory.stats()
    if stats:
        lines.append(f"Memories: {stats.get('total', 0)}")
        zones = stats.get("zones", {})
        zone_names = {0: "Core", 1: "Inner", 2: "Outer", 3: "Belt", 4: "Cloud"}
        zone_parts = [f"{zone_names.get(z, z)}:{c}" for z, c in sorted(zones.items())]
        if zone_parts:
            lines.append(f"Zones: [{' '.join(zone_parts)}]")

    lines.append(f"Safety: {agent.settings.safety_level}")
    return "\n".join(lines)


async def _cmd_memory(agent: Agent, arg: str) -> str:
    if arg:
        results = await agent.memory.recall(arg, limit=5, include_graph=False)
        if not results:
            return f"No memories found for: {arg}"
        lines = [f"--- Memories matching '{arg}' ---"]
        for m in results:
            zone_name = {0: "Core", 1: "Inner", 2: "Outer", 3: "Belt", 4: "Cloud"}.get(m.zone, "?")
            lines.append(f"  [{zone_name}] (score:{m.score:.2f}) {m.content[:100]}")
        return "\n".join(lines)

    stats = await agent.memory.stats()
    if not stats:
        return "Memory system not available."
    lines = ["--- Memory Stats ---"]
    lines.append(f"Total memories: {stats.get('total', 0)}")
    zone_names = {0: "Core", 1: "Inner", 2: "Outer", 3: "Belt", 4: "Cloud"}
    for z, count in sorted(stats.get("zones", {}).items()):
        cap = stats.get("capacities", {}).get(z)
        cap_str = f"/{cap}" if cap else ""
        lines.append(f"  {zone_names.get(z, z)}: {count}{cap_str}")
    return "\n".join(lines)


async def _cmd_tools(agent: Agent, arg: str) -> str:
    tools = agent.tool_registry.list_all()
    if not tools:
        return "No tools available."
    lines = ["--- Available Tools ---"]
    for t in tools:
        status = "ON" if t.enabled else "OFF"
        lines.append(f"  [{status}] {t.display_name} ({t.name}) - {t.description[:60]}")
        lines.append(f"         Risk: {t.risk_level.value}")
    return "\n".join(lines)


async def _cmd_safety(agent: Agent, arg: str) -> str:
    if arg == "log":
        logs = agent.safety.get_action_log(limit=10)
        if not logs:
            return "No actions logged yet."
        lines = ["--- Recent Actions ---"]
        for entry in logs:
            status = "OK" if entry.success else "FAIL"
            lines.append(
                f"  [{status}] {entry.tool_name}.{entry.action} "
                f"(risk:{entry.risk_level.value})"
            )
        return "\n".join(lines)

    return (
        f"Safety level: {agent.settings.safety_level}\n"
        f"Use '/safety log' to view recent actions."
    )


async def _cmd_personality(agent: Agent, arg: str) -> str:
    if arg:
        agent.personality.load_profile(arg)
        return f"Switched personality to: {arg}"

    profiles = agent.personality.list_profiles()
    current = agent.personality.profile.name if agent.personality.profile else "none"
    lines = [f"Current: {current}", "Available:"]
    for p in profiles:
        marker = " <--" if p == current else ""
        lines.append(f"  {p}{marker}")
    return "\n".join(lines)


async def _cmd_model(agent: Agent, arg: str) -> str:
    if arg:
        parts = arg.split("/", 1)
        if len(parts) == 2:
            ok = await agent.model_manager.switch(parts[0], parts[1])
            if ok:
                return f"Switched to {arg}"
            return f"Failed to switch to {arg}"
        return "Usage: /model provider/model_id (e.g., /model ollama/llama3.2:3b)"

    model = agent.model_manager.active_model
    if model:
        loc = "Local" if model.is_local else "API"
        return f"Current model: {model.display_name} ({model.provider}/{model.model_id}) [{loc}]"
    return "No model configured."


async def _cmd_think(agent: Agent, arg: str) -> str:
    agent.show_thinking = not agent.show_thinking
    state = "ON" if agent.show_thinking else "OFF"
    return f"Thinking display: {state}"


async def _cmd_history(agent: Agent, arg: str) -> str:
    entries = await agent.memory.timeline(limit=10)
    if not entries:
        return "No history yet."
    lines = ["--- Recent History ---"]
    for e in entries:
        lines.append(f"  {e['content'][:100]}")
    return "\n".join(lines)


async def _cmd_quit(agent: Agent, arg: str) -> str:
    return "__QUIT__"
