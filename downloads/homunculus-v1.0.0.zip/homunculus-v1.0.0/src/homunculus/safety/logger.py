"""ActionLogger — append-only in-memory audit log of every executed action."""

from __future__ import annotations

import logging
from typing import Any

from homunculus.core.types import ActionLogEntry, ActionResult, ActionRisk, ActionStep

logger = logging.getLogger(__name__)

# Ordinal for risk-level filtering.
_RISK_ORDER: list[ActionRisk] = [
    ActionRisk.SAFE,
    ActionRisk.LOW,
    ActionRisk.MEDIUM,
    ActionRisk.HIGH,
    ActionRisk.CRITICAL,
]


def _risk_index(risk: ActionRisk) -> int:
    try:
        return _RISK_ORDER.index(risk)
    except ValueError:
        return 0


class ActionLogger:
    """Records ``ActionLogEntry`` items in an in-memory list.

    Design notes:
    - Storage is intentionally in-memory so this module has zero infrastructure
      dependencies.  Persistence (SQLite, files) belongs in an outer layer and
      can be added by composing this class with a flush hook.
    - Entries are always appended; the list is never sorted or deduplicated so
      that the true execution sequence is preserved.
    """

    def __init__(self) -> None:
        self._entries: list[ActionLogEntry] = []

    # ─── Write ───

    def log(self, step: ActionStep, result: ActionResult) -> ActionLogEntry:
        """Create and store a log entry from *step* and *result*.

        Returns the created entry so callers can inspect or forward it (e.g.
        to an EventBus).
        """
        # Build a short summary from the result output (first 200 chars).
        summary = (result.output or result.error or "")[:200]

        rollback_available = bool(
            step.rollback_action
            or any(e.startswith("rollback_id:") for e in result.side_effects)
        )

        entry = ActionLogEntry(
            tool_name=step.tool_name,
            action=step.action,
            parameters=dict(step.parameters),
            risk_level=step.risk_level,
            success=result.success,
            output_summary=summary,
            rollback_available=rollback_available,
        )
        self._entries.append(entry)
        logger.debug(
            "Logged action '%s.%s' (risk=%s, success=%s).",
            step.tool_name,
            step.action,
            step.risk_level.value,
            result.success,
        )
        return entry

    # ─── Read ───

    def get_log(
        self,
        limit: int = 50,
        risk_filter: ActionRisk | None = None,
    ) -> list[ActionLogEntry]:
        """Return up to *limit* recent entries, newest first.

        When *risk_filter* is supplied only entries whose risk level is at
        least as severe as the filter are returned (e.g. ``HIGH`` returns both
        HIGH and CRITICAL entries).
        """
        entries = list(reversed(self._entries))

        if risk_filter is not None:
            min_index = _risk_index(risk_filter)
            entries = [e for e in entries if _risk_index(e.risk_level) >= min_index]

        return entries[:limit]

    def clear(self) -> None:
        """Remove all stored entries.  Intended for testing only."""
        self._entries.clear()

    @property
    def entry_count(self) -> int:
        return len(self._entries)
