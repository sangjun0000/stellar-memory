"""ActionRollbacker — manages rollback transactions for reversible actions."""

from __future__ import annotations

import logging
import uuid
from typing import Any, Callable, Awaitable

from homunculus.core.types import ActionLogEntry, RollbackTransaction
from homunculus.errors import RollbackError

logger = logging.getLogger(__name__)

# Type for rollback handler functions
RollbackHandler = Callable[[RollbackTransaction], Awaitable[bool]]


class ActionRollbacker:
    """Records and executes rollback transactions.

    Rollback handlers are registered per undo_type. When rollback() is called,
    the matching handler is invoked to reverse the action.

    Built-in handlers:
    - "file_restore": Restores a file from backup data
    - "file_delete": Deletes a file that was created
    """

    def __init__(self, max_transactions: int = 1000) -> None:
        self._transactions: dict[str, RollbackTransaction] = {}
        self._handlers: dict[str, RollbackHandler] = {}
        self._max_transactions = max_transactions

        # Register built-in handlers
        self._register_builtin_handlers()

    def record(
        self,
        action_id: str,
        tool_name: str,
        action: str,
        undo_type: str,
        undo_data: dict[str, Any] | None = None,
    ) -> str:
        """Record a rollback transaction. Returns the transaction_id."""
        transaction_id = uuid.uuid4().hex[:12]

        transaction = RollbackTransaction(
            transaction_id=transaction_id,
            action_id=action_id,
            tool_name=tool_name,
            action=action,
            undo_type=undo_type,
            undo_data=undo_data or {},
        )

        self._transactions[transaction_id] = transaction
        self._enforce_limit()

        logger.debug(
            "Recorded rollback transaction %s for %s.%s (undo_type=%s)",
            transaction_id, tool_name, action, undo_type,
        )
        return transaction_id

    async def rollback(self, transaction_id: str) -> bool:
        """Execute rollback for the given transaction."""
        transaction = self._transactions.get(transaction_id)
        if transaction is None:
            logger.warning("Rollback transaction %s not found", transaction_id)
            return False

        if transaction.executed:
            logger.warning("Transaction %s already rolled back", transaction_id)
            return transaction.success

        handler = self._handlers.get(transaction.undo_type)
        if handler is None:
            logger.warning(
                "No handler for undo_type '%s' (transaction %s)",
                transaction.undo_type, transaction_id,
            )
            transaction.executed = True
            transaction.success = False
            return False

        try:
            success = await handler(transaction)
            transaction.executed = True
            transaction.success = success
            logger.info(
                "Rollback %s: %s (transaction %s)",
                "succeeded" if success else "failed",
                transaction.undo_type,
                transaction_id,
            )
            return success
        except Exception as exc:
            transaction.executed = True
            transaction.success = False
            logger.exception("Rollback handler failed for %s", transaction_id)
            raise RollbackError(f"Rollback failed: {exc}") from exc

    async def rollback_by_action(self, action_id: str) -> bool:
        """Rollback all transactions for a given action_id (LIFO order)."""
        related = [
            t for t in self._transactions.values()
            if t.action_id == action_id and not t.executed
        ]
        related.sort(key=lambda t: t.created_at, reverse=True)  # LIFO

        if not related:
            return False

        all_success = True
        for transaction in related:
            success = await self.rollback(transaction.transaction_id)
            if not success:
                all_success = False

        return all_success

    def register_handler(self, undo_type: str, handler: RollbackHandler) -> None:
        """Register a rollback handler for the given undo_type."""
        self._handlers[undo_type] = handler
        logger.debug("Registered rollback handler for '%s'", undo_type)

    def get_transaction(self, transaction_id: str) -> RollbackTransaction | None:
        """Get a transaction by ID."""
        return self._transactions.get(transaction_id)

    def get_pending(self) -> list[RollbackTransaction]:
        """Get all transactions not yet executed."""
        return [t for t in self._transactions.values() if not t.executed]

    def _enforce_limit(self) -> None:
        """Remove oldest executed transactions when limit is exceeded."""
        if len(self._transactions) <= self._max_transactions:
            return

        executed = sorted(
            (t for t in self._transactions.values() if t.executed),
            key=lambda t: t.created_at,
        )

        to_remove = len(self._transactions) - self._max_transactions
        for tx in executed[:to_remove]:
            del self._transactions[tx.transaction_id]

    def _register_builtin_handlers(self) -> None:
        """Register built-in rollback handlers."""

        async def file_restore(tx: RollbackTransaction) -> bool:
            import aiofiles
            path = tx.undo_data.get("path")
            content = tx.undo_data.get("original_content")
            if not path or content is None:
                return False
            try:
                import pathlib
                pathlib.Path(path).write_text(content, encoding="utf-8")
                return True
            except OSError:
                logger.exception("Failed to restore file %s", path)
                return False

        async def file_delete(tx: RollbackTransaction) -> bool:
            path = tx.undo_data.get("path")
            if not path:
                return False
            try:
                import pathlib
                p = pathlib.Path(path)
                if p.exists():
                    p.unlink()
                return True
            except OSError:
                logger.exception("Failed to delete file %s", path)
                return False

        self._handlers["file_restore"] = file_restore
        self._handlers["file_delete"] = file_delete
