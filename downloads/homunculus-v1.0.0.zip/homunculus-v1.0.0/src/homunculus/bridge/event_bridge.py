"""Bridges Homunculus EventBus events to WebSocket clients."""

from __future__ import annotations

import logging
from typing import Any, Callable, Awaitable

from homunculus.bridge import protocol

logger = logging.getLogger(__name__)


class EventBridge:
    """Subscribes to Homunculus EventBus and forwards events as WebSocket messages."""

    def __init__(
        self,
        event_bus: Any,  # homunculus.core.event_bus.EventBus
        broadcast: Callable[[protocol.Message], Awaitable[None]],
    ) -> None:
        self._bus = event_bus
        self._broadcast = broadcast
        self._prev_state: str = "idle"
        self._subscribed = False

    def subscribe_all(self) -> None:
        """Subscribe to all agent events for WebSocket forwarding."""
        if self._subscribed:
            return

        # Agent core events
        self._bus.on("agent.state.changed", self._on_state_changed)
        self._bus.on("agent.response", self._on_response)
        self._bus.on("agent.cycle.started", self._on_cycle_started)
        self._bus.on("agent.cycle.completed", self._on_cycle_completed)
        self._bus.on("agent.error", self._on_error)

        # Actor events
        self._bus.on("actor.step.started", self._on_tool_started)
        self._bus.on("actor.step.succeeded", self._on_tool_succeeded)
        self._bus.on("actor.step.failed", self._on_tool_failed)

        # Safety events
        self._bus.on("approval_needed", self._on_approval_needed)

        # Memory events
        self._bus.on("memory_stored", self._on_memory_stored)

        self._subscribed = True
        logger.info("EventBridge subscribed to all agent events")

    def unsubscribe_all(self) -> None:
        """Unsubscribe from all events."""
        if not self._subscribed:
            return

        self._bus.off("agent.state.changed", self._on_state_changed)
        self._bus.off("agent.response", self._on_response)
        self._bus.off("agent.cycle.started", self._on_cycle_started)
        self._bus.off("agent.cycle.completed", self._on_cycle_completed)
        self._bus.off("agent.error", self._on_error)
        self._bus.off("actor.step.started", self._on_tool_started)
        self._bus.off("actor.step.succeeded", self._on_tool_succeeded)
        self._bus.off("actor.step.failed", self._on_tool_failed)
        self._bus.off("approval_needed", self._on_approval_needed)
        self._bus.off("memory_stored", self._on_memory_stored)

        self._subscribed = False
        logger.info("EventBridge unsubscribed from all events")

    # --- Agent Core Event Handlers ---

    async def _on_state_changed(self, state: Any) -> None:
        """Forward agent state transition."""
        state_str = state.value if hasattr(state, "value") else str(state)
        msg = protocol.agent_state(
            state=state_str,
            previous_state=self._prev_state,
        )
        self._prev_state = state_str
        await self._broadcast(msg)

    async def _on_response(self, content: str) -> None:
        """Forward agent text response."""
        msg = protocol.chat_response(content=content, role="agent")
        await self._broadcast(msg)

    async def _on_cycle_started(self, cycle: Any) -> None:
        """Forward cycle start notification."""
        cycle_id = getattr(cycle, "cycle_id", "")
        msg = protocol.Message(
            type=protocol.ServerMessageType.CYCLE_UPDATE.value,
            payload={
                "cycle_id": cycle_id,
                "status": "started",
            },
        )
        await self._broadcast(msg)

    async def _on_cycle_completed(self, cycle: Any) -> None:
        """Forward cycle completion summary."""
        cycle_id = getattr(cycle, "cycle_id", "")
        started = getattr(cycle, "started_at", 0)
        completed = getattr(cycle, "completed_at", 0)
        duration_ms = (completed - started) * 1000 if completed > started else 0

        msg = protocol.Message(
            type=protocol.ServerMessageType.CYCLE_UPDATE.value,
            payload={
                "cycle_id": cycle_id,
                "status": "completed",
                "duration_ms": round(duration_ms, 2),
            },
        )
        await self._broadcast(msg)

    async def _on_error(self, error: Exception) -> None:
        """Forward agent error."""
        msg = protocol.error_message(
            code=protocol.ErrorCode.INTERNAL_ERROR,
            message=str(error),
        )
        await self._broadcast(msg)

    # --- Actor Event Handlers ---

    async def _on_tool_started(self, result: Any) -> None:
        """Forward tool execution start."""
        step = getattr(result, "step", None)
        if step is None:
            return
        msg = protocol.tool_execution(
            tool_name=getattr(step, "tool_name", ""),
            action=getattr(step, "action", ""),
            status="started",
            description=getattr(step, "description", ""),
            risk_level=getattr(getattr(step, "risk_level", None), "value", "safe"),
        )
        await self._broadcast(msg)

    async def _on_tool_succeeded(self, result: Any) -> None:
        """Forward tool execution success."""
        step = getattr(result, "step", None)
        if step is None:
            return
        msg = protocol.tool_execution(
            tool_name=getattr(step, "tool_name", ""),
            action=getattr(step, "action", ""),
            status="succeeded",
            description=getattr(step, "description", ""),
            output=str(getattr(result, "output", ""))[:500],
            risk_level=getattr(getattr(step, "risk_level", None), "value", "safe"),
            duration_ms=getattr(result, "duration_ms", 0.0),
        )
        await self._broadcast(msg)

    async def _on_tool_failed(self, result: Any) -> None:
        """Forward tool execution failure."""
        step = getattr(result, "step", None)
        if step is None:
            return
        msg = protocol.tool_execution(
            tool_name=getattr(step, "tool_name", ""),
            action=getattr(step, "action", ""),
            status="failed",
            description=getattr(step, "description", ""),
            error=str(getattr(result, "error", "")),
            risk_level=getattr(getattr(step, "risk_level", None), "value", "safe"),
            duration_ms=getattr(result, "duration_ms", 0.0),
        )
        await self._broadcast(msg)

    # --- Safety Event Handlers ---

    async def _on_approval_needed(self, plan: Any) -> None:
        """Forward safety approval request."""
        steps_data = []
        for step in getattr(plan, "steps", []):
            steps_data.append({
                "tool_name": getattr(step, "tool_name", ""),
                "action": getattr(step, "action", ""),
                "description": getattr(step, "description", ""),
                "risk_level": getattr(
                    getattr(step, "risk_level", None), "value", "safe"
                ),
            })

        msg = protocol.approval_needed(
            plan_id=str(id(plan)),
            goal=getattr(plan, "goal", ""),
            estimated_risk=getattr(
                getattr(plan, "estimated_risk", None), "value", "safe"
            ),
            steps=steps_data,
        )
        await self._broadcast(msg)

    # --- Memory Event Handlers ---

    async def _on_memory_stored(self, memory_id: str) -> None:
        """Forward memory storage notification."""
        msg = protocol.Message(
            type=protocol.ServerMessageType.CYCLE_UPDATE.value,
            payload={
                "event": "memory_stored",
                "memory_id": memory_id,
            },
        )
        await self._broadcast(msg)
