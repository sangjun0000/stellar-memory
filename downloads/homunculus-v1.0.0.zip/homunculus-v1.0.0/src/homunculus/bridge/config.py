"""Bridge server configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from homunculus.config.settings import Settings


@dataclass
class BridgeConfig:
    """Configuration for the Bridge Server."""

    host: str = "0.0.0.0"
    port: int = 8765
    enable_tls: bool = False
    tls_cert_path: str = ""
    tls_key_path: str = ""
    max_clients: int = 1
    heartbeat_interval: int = 30
    session_timeout: int = 86400
    pairing_timeout: int = 300
    message_max_size: int = 65536
    rate_limit: int = 60
    auto_start: bool = False

    @staticmethod
    def from_settings(settings: Settings) -> BridgeConfig:
        """Load bridge config from [bridge] section of homunculus.toml."""
        section = settings.section("bridge") if hasattr(settings, "section") else {}
        return BridgeConfig(
            host=section.get("host", "0.0.0.0"),
            port=int(section.get("port", 8765)),
            enable_tls=bool(section.get("enable_tls", False)),
            tls_cert_path=str(section.get("tls_cert_path", "")),
            tls_key_path=str(section.get("tls_key_path", "")),
            max_clients=int(section.get("max_clients", 1)),
            heartbeat_interval=int(section.get("heartbeat_interval", 30)),
            session_timeout=int(section.get("session_timeout", 86400)),
            pairing_timeout=int(section.get("pairing_timeout", 300)),
            message_max_size=int(section.get("message_max_size", 65536)),
            rate_limit=int(section.get("rate_limit", 60)),
            auto_start=bool(section.get("auto_start", False)),
        )
