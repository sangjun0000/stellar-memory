"""Onboarding flow engine for first-run experience."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from homunculus.onboarding.demos import demo_file_scan, demo_memory

if TYPE_CHECKING:
    from homunculus.config.settings import Settings
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)


@dataclass
class OnboardingResponse:
    message: str
    step_completed: int
    next_step: int | None
    demo_result: str | None = None
    options: list[str] = field(default_factory=list)
    is_final: bool = False


class OnboardingFlow:
    """Manages the first-run onboarding experience.

    Guides the user through a scripted conversation demonstrating
    Homunculus's key differentiators: memory, file tools, personality.
    """

    TOTAL_STEPS = 4

    def __init__(self, agent: Agent, settings: Settings) -> None:
        self._agent = agent
        self._settings = settings
        self._current_step: int = 0
        self._user_name: str = ""
        self._completed: bool = settings.get("onboarding", "completed", False)

    @property
    def is_completed(self) -> bool:
        return self._completed

    @property
    def current_step(self) -> int:
        return self._current_step

    @property
    def total_steps(self) -> int:
        return self.TOTAL_STEPS

    @property
    def user_name(self) -> str:
        return self._user_name

    async def process_input(self, user_input: str) -> OnboardingResponse:
        step = self._current_step

        if step == 0:
            return await self._handle_name_input(user_input)
        elif step == 1:
            return await self._handle_memory_demo(user_input)
        elif step == 2:
            return await self._handle_file_demo(user_input)
        elif step == 3:
            return self._handle_complete(user_input)
        else:
            return OnboardingResponse(
                message="",
                step_completed=step,
                next_step=None,
                is_final=True,
            )

    async def _handle_name_input(self, user_input: str) -> OnboardingResponse:
        self._user_name = self._extract_name(user_input)
        self._current_step = 1

        # Store name and demonstrate memory
        demo_result = await demo_memory(self._agent, self._user_name)

        return OnboardingResponse(
            message=f"반갑습니다, **{self._user_name}**님!",
            step_completed=0,
            next_step=1,
            demo_result=demo_result,
        )

    async def _handle_memory_demo(self, user_input: str) -> OnboardingResponse:
        self._current_step = 2

        # Scan desktop
        scan_result = await demo_file_scan(self._agent)

        return OnboardingResponse(
            message=scan_result,
            step_completed=1,
            next_step=2,
            options=["파일 정리해줘", "다른 거 보여줘", "건너뛰기"],
        )

    async def _handle_file_demo(self, user_input: str) -> OnboardingResponse:
        self._current_step = 3
        return self._handle_complete(user_input)

    def _handle_complete(self, user_input: str) -> OnboardingResponse:
        self._completed = True
        self._current_step = self.TOTAL_STEPS
        self._persist_completion()

        name_part = f" {self._user_name}님," if self._user_name else ""

        message = (
            f"좋습니다!{name_part} 이제 자유롭게 대화하실 수 있어요.\n\n"
            f"제가 잘하는 것들:\n"
            f"- 질문에 대답 (기억하면서!)\n"
            f"- 파일 정리 & 관리\n"
            f"- 명령어 실행 (자동화)\n"
            f"- 코드 작성 & 리뷰\n\n"
            f"무엇이든 물어보세요!"
        )

        return OnboardingResponse(
            message=message,
            step_completed=3,
            next_step=None,
            is_final=True,
        )

    def _extract_name(self, text: str) -> str:
        """Extract a name from user input.

        Handles Korean and English patterns:
            "홍길동이야", "제 이름은 홍길동입니다", "홍길동", "John"
        """
        text = text.strip()

        # Korean patterns: "제 이름은 X입니다", "X이야", "X야", "X라고 해"
        patterns = [
            r"이름은?\s*(.+?)(?:입니다|이에요|예요|야|이야|라고|이라고)",
            r"저는?\s*(.+?)(?:입니다|이에요|예요|야|이야|라고|이라고)",
            r"^(.+?)(?:입니다|이에요|예요|이야|야|이요|요)$",
        ]

        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                name = match.group(1).strip()
                # Remove common prefixes
                name = re.sub(r"^(제\s*이름은?|저는?|나는?)\s*", "", name).strip()
                if name:
                    return name

        # English patterns: "I'm X", "My name is X", "Call me X"
        en_patterns = [
            r"(?:my name is|i'?m|call me|i am)\s+(.+)",
        ]
        for pattern in en_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip().rstrip(".")
                if name:
                    return name

        # Fallback: use the entire input (likely just a name)
        # Remove trailing punctuation
        cleaned = re.sub(r"[.!?~\s]+$", "", text)
        return cleaned if cleaned else text

    def _persist_completion(self) -> None:
        """Write onboarding completion to homunculus.toml."""
        try:
            config_path = self._settings.config_path
            if not config_path:
                return
            text = config_path.read_text(encoding="utf-8")
            text = text.replace(
                "completed = false",
                "completed = true",
            )
            if self._user_name:
                # Add user_name if not present
                if "user_name" not in text:
                    text = text.replace(
                        "[onboarding]\ncompleted = true",
                        f"[onboarding]\ncompleted = true\nuser_name = \"{self._user_name}\"",
                    )
            config_path.write_text(text, encoding="utf-8")
        except Exception:
            logger.warning("Could not persist onboarding completion to config")
