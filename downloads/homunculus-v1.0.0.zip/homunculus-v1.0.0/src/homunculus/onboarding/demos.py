"""Onboarding demonstration functions."""

from __future__ import annotations

import logging
import platform
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)


async def demo_memory(agent: Agent, user_name: str) -> str:
    """Demonstrate memory by storing and recalling the user's name."""
    await agent.memory.remember(
        content=f"User's name is {user_name}",
        importance=0.95,
        metadata={"type": "user_profile", "key": "name"},
    )

    # Recall it immediately to prove memory works
    results = await agent.memory.recall(user_name, limit=1, include_graph=False)
    if results:
        return (
            f"방금 당신의 이름을 기억했어요: **{user_name}**\n"
            f"다음에 만나도 기억할 거예요!\n\n"
            f"이제 제가 뭘 할 수 있는지 보여드릴게요."
        )

    return (
        f"반갑습니다, **{user_name}**님!\n"
        f"이제 제가 뭘 할 수 있는지 보여드릴게요."
    )


async def demo_file_scan(agent: Agent) -> str:
    """Scan the user's Desktop to demonstrate file capabilities."""
    desktop = _find_desktop()
    if not desktop or not desktop.exists():
        return (
            "바탕화면을 찾지 못했어요.\n"
            "대신 다른 것을 해볼까요?\n\n"
            "제가 잘하는 것들:\n"
            "- 질문에 대답 (기억하면서!)\n"
            "- 파일 정리 & 관리\n"
            "- 명령어 실행 (자동화)\n"
            "- 코드 작성 & 리뷰"
        )

    try:
        items = list(desktop.iterdir())[:50]  # Cap at 50 items
    except PermissionError:
        return "바탕화면에 접근 권한이 없어요. 다른 걸 해볼까요?"

    total = len(items)
    files = [i for i in items if i.is_file()]
    dirs = [i for i in items if i.is_dir()]

    # Categorize files
    docs = [f for f in files if f.suffix.lower() in (
        ".txt", ".pdf", ".doc", ".docx", ".xlsx", ".pptx", ".hwp", ".md"
    )]
    images = [f for f in files if f.suffix.lower() in (
        ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg"
    )]
    other_files = [f for f in files if f not in docs and f not in images]

    parts = [f"바탕화면에 **{total}개** 항목이 있네요!"]
    details = []
    if dirs:
        details.append(f"폴더 {len(dirs)}개")
    if docs:
        details.append(f"문서 {len(docs)}개")
    if images:
        details.append(f"이미지 {len(images)}개")
    if other_files:
        details.append(f"기타 파일 {len(other_files)}개")

    if details:
        parts.append(f"({', '.join(details)})")

    return "\n".join(parts)


async def demo_organize(agent: Agent, path: str) -> str:
    """Demonstrate file organization by suggesting folder structure.

    Flow:
        1. Scan target directory
        2. Suggest folder structure based on file types
        3. Return a preview (does NOT actually move files without approval)
    """
    target = Path(path)
    if not target.exists():
        return "해당 경로를 찾을 수 없어요."

    try:
        files = [f for f in target.iterdir() if f.is_file()]
    except PermissionError:
        return "접근 권한이 없어요."

    if not files:
        return "정리할 파일이 없어요!"

    categories: dict[str, list[str]] = {
        "문서": [],
        "이미지": [],
        "기타": [],
    }
    doc_exts = {".txt", ".pdf", ".doc", ".docx", ".xlsx", ".pptx", ".hwp", ".md"}
    img_exts = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg"}

    for f in files[:30]:
        ext = f.suffix.lower()
        name = f.name
        if ext in doc_exts:
            categories["문서"].append(name)
        elif ext in img_exts:
            categories["이미지"].append(name)
        else:
            categories["기타"].append(name)

    lines = ["파일 정리 제안:"]
    for cat, items in categories.items():
        if items:
            lines.append(f"\n**{cat}/** ({len(items)}개)")
            for name in items[:5]:
                lines.append(f"  - {name}")
            if len(items) > 5:
                lines.append(f"  - ... 외 {len(items) - 5}개")

    lines.append("\n실제로 정리하려면 '정리해줘'라고 말씀해주세요.")
    return "\n".join(lines)


def _find_desktop() -> Path | None:
    system = platform.system()
    if system == "Windows":
        candidates = [
            Path.home() / "Desktop",
            Path.home() / "OneDrive" / "Desktop",
            Path.home() / "\ubc14\ud0d5 \ud654\uba74",
        ]
    elif system == "Darwin":
        candidates = [Path.home() / "Desktop"]
    else:
        candidates = [Path.home() / "Desktop"]

    for p in candidates:
        if p.exists():
            return p
    return None
