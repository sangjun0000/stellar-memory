"""Homunculus - Autonomous AI Agent with Stellar Memory."""

__version__ = "1.0.0"

from homunculus.errors import (
    CodeAnalysisError,
    HomunculusError,
    MemoryError,
    ModelConnectionError,
    ModelError,
    ModelNotFoundError,
    ModelTimeoutError,
    RollbackError,
    SafetyBlockedError,
    SafetyError,
    SchedulerError,
    SchedulerTaskNotFoundError,
    ToolError,
    ToolExecutionError,
    ToolPermissionError,
    WatcherError,
    WatcherStartError,
    WebSearchError,
)

__all__ = [
    "HomunculusError",
    "ModelError",
    "ModelNotFoundError",
    "ModelConnectionError",
    "ModelTimeoutError",
    "MemoryError",
    "ToolError",
    "ToolExecutionError",
    "ToolPermissionError",
    "SafetyError",
    "SafetyBlockedError",
    "RollbackError",
    "WatcherError",
    "WatcherStartError",
    "SchedulerError",
    "SchedulerTaskNotFoundError",
    "WebSearchError",
    "CodeAnalysisError",
]
