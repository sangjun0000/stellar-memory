"""Unified model interface protocol for all AI providers."""

from __future__ import annotations

from typing import AsyncIterator, Protocol, runtime_checkable

from homunculus.core.types import ToolCallResult


@runtime_checkable
class ModelInterface(Protocol):
    """All AI providers must implement this interface."""

    async def chat(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str: ...

    async def chat_stream(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]: ...

    async def chat_with_tools(
        self,
        messages: list[dict[str, str]],
        tools: list[dict],
        system: str | None = None,
        temperature: float = 0.7,
    ) -> ToolCallResult: ...

    def supports_tools(self) -> bool: ...

    def embed(self, text: str) -> list[float]:
        """Return a vector embedding for *text*.

        Not all providers support embeddings.  Implementations that do not
        must raise ``NotImplementedError`` so callers can detect the gap and
        fall back gracefully.
        """
        raise NotImplementedError
