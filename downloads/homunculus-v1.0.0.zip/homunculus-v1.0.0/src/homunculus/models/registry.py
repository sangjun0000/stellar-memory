"""Built-in model registry."""

from __future__ import annotations

from homunculus.core.types import ModelInfo

# All models known to Homunculus out of the box
BUILT_IN_MODELS: list[ModelInfo] = [
    # ─── Ollama (Local) ───
    ModelInfo(
        provider="ollama", model_id="llama3.2:3b",
        display_name="Llama 3.2 3B",
        description="Fast and lightweight, great for most tasks",
        is_local=True, min_ram_gb=4, context_window=128_000,
        supports_tools=True, download_size_gb=2.0,
    ),
    ModelInfo(
        provider="ollama", model_id="llama3.2:8b",
        display_name="Llama 3.2 8B",
        description="Higher quality reasoning, needs more RAM",
        is_local=True, min_ram_gb=8, context_window=128_000,
        supports_tools=True, download_size_gb=4.7,
    ),
    ModelInfo(
        provider="ollama", model_id="mistral:7b",
        display_name="Mistral 7B",
        description="Strong general-purpose model",
        is_local=True, min_ram_gb=8, context_window=32_000,
        supports_tools=True, download_size_gb=4.1,
    ),
    ModelInfo(
        provider="ollama", model_id="qwen2.5:7b",
        display_name="Qwen 2.5 7B",
        description="Excellent multilingual and coding abilities",
        is_local=True, min_ram_gb=8, context_window=128_000,
        supports_tools=True, download_size_gb=4.4,
    ),
    ModelInfo(
        provider="ollama", model_id="gemma2:9b",
        display_name="Gemma 2 9B",
        description="Google's efficient model",
        is_local=True, min_ram_gb=10, context_window=8_000,
        supports_tools=False, download_size_gb=5.4,
    ),
    ModelInfo(
        provider="ollama", model_id="deepseek-r1:8b",
        display_name="DeepSeek R1 8B",
        description="Strong reasoning with chain-of-thought",
        is_local=True, min_ram_gb=8, context_window=128_000,
        supports_tools=False, download_size_gb=4.9,
    ),
    # ─── OpenAI (API) ───
    ModelInfo(
        provider="openai", model_id="gpt-4o",
        display_name="GPT-4o",
        description="OpenAI's flagship multimodal model",
        requires_api_key=True, context_window=128_000, supports_tools=True,
    ),
    ModelInfo(
        provider="openai", model_id="gpt-4o-mini",
        display_name="GPT-4o Mini",
        description="Fast and affordable",
        requires_api_key=True, context_window=128_000, supports_tools=True,
    ),
    ModelInfo(
        provider="openai", model_id="o3-mini",
        display_name="o3 Mini",
        description="Reasoning-optimized model",
        requires_api_key=True, context_window=200_000, supports_tools=True,
    ),
    # ─── Anthropic (API) ───
    ModelInfo(
        provider="anthropic", model_id="claude-sonnet-4-6",
        display_name="Claude Sonnet 4.6",
        description="Anthropic's balanced model",
        requires_api_key=True, context_window=200_000, supports_tools=True,
    ),
    ModelInfo(
        provider="anthropic", model_id="claude-haiku-4-5",
        display_name="Claude Haiku 4.5",
        description="Fast and efficient",
        requires_api_key=True, context_window=200_000, supports_tools=True,
    ),
    # ─── DeepSeek (API) ───
    ModelInfo(
        provider="deepseek", model_id="deepseek-chat",
        display_name="DeepSeek Chat",
        description="Affordable high-quality model",
        requires_api_key=True, context_window=64_000, supports_tools=True,
    ),
    ModelInfo(
        provider="deepseek", model_id="deepseek-reasoner",
        display_name="DeepSeek Reasoner",
        description="Reasoning-optimized model with chain-of-thought",
        requires_api_key=True, context_window=64_000, supports_tools=False,
    ),
    # ─── Google (API) ───
    ModelInfo(
        provider="google", model_id="gemini-2.0-flash",
        display_name="Gemini 2.0 Flash",
        description="Google's fast model with 1M context",
        requires_api_key=True, context_window=1_000_000, supports_tools=True,
    ),
]


class ModelRegistry:
    """Registry of available AI models."""

    def __init__(self) -> None:
        self._models: dict[str, ModelInfo] = {}
        for m in BUILT_IN_MODELS:
            key = f"{m.provider}/{m.model_id}"
            self._models[key] = m

    def list_providers(self) -> list[str]:
        return sorted({m.provider for m in self._models.values()})

    def list_models(self, provider: str | None = None) -> list[ModelInfo]:
        models = list(self._models.values())
        if provider:
            models = [m for m in models if m.provider == provider]
        return models

    def get_model(self, provider: str, model_id: str) -> ModelInfo | None:
        return self._models.get(f"{provider}/{model_id}")

    def get_recommended(self, local_only: bool = False) -> list[ModelInfo]:
        models = self.list_models()
        if local_only:
            models = [m for m in models if m.is_local]
        # Prefer models with tool support, then by context window size
        return sorted(
            models,
            key=lambda m: (m.supports_tools, m.context_window),
            reverse=True,
        )

    def register(self, model: ModelInfo) -> None:
        key = f"{model.provider}/{model.model_id}"
        self._models[key] = model

    def check_availability(self, provider: str, model_id: str) -> bool:
        """Return True when *provider*/*model_id* is present in the registry.

        This is a purely in-memory check; it does not probe the provider's
        API or verify that the model is currently reachable.
        """
        return f"{provider}/{model_id}" in self._models
