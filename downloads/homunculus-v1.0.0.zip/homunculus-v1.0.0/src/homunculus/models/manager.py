"""AI Model Manager - orchestrates model selection, setup, and switching."""

from __future__ import annotations

import logging
import os
from typing import Any

from homunculus.config.settings import Settings
from homunculus.core.types import ModelInfo

from .interface import ModelInterface
from .providers.anthropic_provider import AnthropicProvider
from .providers.deepseek import DeepSeekProvider
from .providers.google import GoogleProvider
from .providers.ollama import OllamaProvider
from .providers.openai_provider import OpenAIProvider
from .registry import ModelRegistry

logger = logging.getLogger(__name__)

PROVIDER_CLASSES: dict[str, type] = {
    "ollama": OllamaProvider,
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "deepseek": DeepSeekProvider,
    "google": GoogleProvider,
}

API_KEY_ENV: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "google": "GOOGLE_API_KEY",
}


class ModelManager:
    """Manages AI model lifecycle: selection, setup, switching."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._registry = ModelRegistry()
        self._active_provider: ModelInterface | None = None
        self._active_model: ModelInfo | None = None
        self._router: Any = None  # Optional ModelRouter

    @property
    def registry(self) -> ModelRegistry:
        return self._registry

    @property
    def active_model(self) -> ModelInfo | None:
        return self._active_model

    @property
    def provider(self) -> ModelInterface | None:
        return self._active_provider

    def create_provider(
        self,
        provider_name: str,
        model_id: str,
        api_key: str = "",
        **kwargs: Any,
    ) -> ModelInterface:
        cls = PROVIDER_CLASSES.get(provider_name)
        if not cls:
            raise ValueError(f"Unknown provider: {provider_name}")

        init_kwargs: dict[str, Any] = {"model_id": model_id}

        if provider_name == "ollama":
            host = kwargs.get("host") or self._settings.get(
                "model", "ollama_host", "http://localhost:11434"
            )
            init_kwargs["host"] = host
        else:
            key = api_key or os.environ.get(API_KEY_ENV.get(provider_name, ""), "")
            init_kwargs["api_key"] = key

        return cls(**init_kwargs)

    async def setup(
        self,
        provider_name: str | None = None,
        model_id: str | None = None,
        api_key: str = "",
    ) -> bool:
        prov = provider_name or self._settings.model_provider
        mid = model_id or self._settings.model_id

        logger.info("Setting up %s/%s", prov, mid)

        instance = self.create_provider(prov, mid, api_key)

        if hasattr(instance, "setup"):
            ok = await instance.setup(mid)
            if not ok:
                logger.error("Setup failed for %s/%s", prov, mid)
                return False

        self._active_provider = instance
        self._active_model = self._registry.get_model(prov, mid)
        if self._active_model is None:
            self._active_model = ModelInfo(
                provider=prov,
                model_id=mid,
                display_name=f"{prov}/{mid}",
            )

        logger.info("Model ready: %s", self._active_model.display_name)
        return True

    async def switch(
        self,
        provider_name: str,
        model_id: str,
        api_key: str = "",
    ) -> bool:
        if self._active_provider and hasattr(self._active_provider, "close"):
            await self._active_provider.close()
        return await self.setup(provider_name, model_id, api_key)

    @property
    def router(self) -> Any:
        return self._router

    def enable_routing(self) -> None:
        """Initialize the model router."""
        from .router import ModelRouter
        self._router = ModelRouter(self, self._settings)

    async def get_provider_for(
        self, message: str, has_tools: bool = False,
    ) -> ModelInterface:
        """Get the best provider for a given message.

        If routing is enabled, analyzes complexity and may switch providers.
        If routing is disabled, returns the active provider.
        """
        if self._router and self._router.is_enabled():
            decision = self._router.route(message, has_tools)
            if (self._active_model
                    and (decision.provider != self._active_model.provider
                         or decision.model_id != self._active_model.model_id)):
                return self.create_provider(decision.provider, decision.model_id)
        return self._active_provider

    def get_api_key_for(self, provider_name: str) -> str:
        env_var = API_KEY_ENV.get(provider_name, "")
        return os.environ.get(env_var, "") if env_var else ""

    async def close(self) -> None:
        if self._active_provider and hasattr(self._active_provider, "close"):
            await self._active_provider.close()
        self._active_provider = None
        self._active_model = None
