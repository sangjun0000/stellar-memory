"""Smart model routing — routes queries to local or cloud models."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from homunculus.config.settings import Settings
    from homunculus.models.manager import ModelManager

logger = logging.getLogger(__name__)


class QueryComplexity(Enum):
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    TOOL_USE = "tool_use"


@dataclass
class RoutingDecision:
    provider: str
    model_id: str
    reason: str
    complexity: QueryComplexity


# Keywords that indicate complex queries
_COMPLEX_KEYWORDS = re.compile(
    r"\b(analyze|analyse|compare|explain\s+why|debug|refactor|architect|"
    r"implement|algorithm|optimize|performance|security|vulnerability|"
    r"분석|비교|설명|디버그|리팩토링|구현|최적화|성능|보안)\b",
    re.IGNORECASE,
)

_CODE_KEYWORDS = re.compile(
    r"\b(def |class |function |import |const |let |var |"
    r"```|error|traceback|exception|bug|fix|TypeError|ValueError|"
    r"코드|함수|클래스|에러|버그)\b",
    re.IGNORECASE,
)

_SIMPLE_PATTERNS = re.compile(
    r"^(hi|hello|hey|thanks|thank you|ok|yes|no|bye|"
    r"안녕|감사|고마워|응|아니|네|괜찮|ㅇㅇ|ㄴㄴ|ㅎㅎ|ㅋㅋ)[!?.~]*$",
    re.IGNORECASE,
)


class ModelRouter:
    """Routes queries to the best model based on complexity and config.

    Strategy:
        SIMPLE   -> Local model (fast, free)
        MODERATE -> Local model (acceptable quality)
        COMPLEX  -> Cloud model (if API key available), else local
        TOOL_USE -> Prefer model with tool calling support
    """

    def __init__(self, model_manager: ModelManager, settings: Settings) -> None:
        self._manager = model_manager
        self._settings = settings
        self._enabled: bool = settings.get("routing", "enabled", False)
        self._privacy_mode: bool = settings.get("routing", "privacy_mode", False)
        self._cloud_provider: str = settings.get("routing", "cloud_provider", "")
        self._cloud_model: str = settings.get("routing", "cloud_model", "")
        self._local_provider: str = settings.get("routing", "local_provider", "ollama")
        self._local_model: str = settings.get("routing", "local_model", "llama3.2:3b")

    def is_enabled(self) -> bool:
        return self._enabled

    def analyze_complexity(
        self, message: str, has_tool_request: bool = False,
    ) -> QueryComplexity:
        if has_tool_request:
            return QueryComplexity.TOOL_USE

        stripped = message.strip()

        # Simple: short greetings, yes/no
        if len(stripped) < 20 and _SIMPLE_PATTERNS.match(stripped):
            return QueryComplexity.SIMPLE

        # Complex: code or analysis keywords
        if _CODE_KEYWORDS.search(stripped):
            return QueryComplexity.COMPLEX

        if _COMPLEX_KEYWORDS.search(stripped):
            return QueryComplexity.COMPLEX

        # Complex: long messages (>200 chars) likely need deeper reasoning
        if len(stripped) > 200:
            return QueryComplexity.COMPLEX

        return QueryComplexity.MODERATE

    def route(
        self, message: str, has_tool_request: bool = False,
    ) -> RoutingDecision:
        if not self._enabled:
            active = self._manager.active_model
            return RoutingDecision(
                provider=active.provider if active else "ollama",
                model_id=active.model_id if active else "llama3.2:3b",
                reason="routing_disabled",
                complexity=QueryComplexity.SIMPLE,
            )

        complexity = self.analyze_complexity(message, has_tool_request)

        # Privacy mode: always local
        if self._privacy_mode:
            return RoutingDecision(
                provider=self._local_provider,
                model_id=self._local_model,
                reason="privacy_mode",
                complexity=complexity,
            )

        # Complex or tool_use: try cloud
        if complexity in (QueryComplexity.COMPLEX, QueryComplexity.TOOL_USE):
            if self._has_cloud_api():
                return RoutingDecision(
                    provider=self._cloud_provider,
                    model_id=self._cloud_model,
                    reason="complex_query_routed_to_cloud",
                    complexity=complexity,
                )

        # Default: local
        return RoutingDecision(
            provider=self._local_provider,
            model_id=self._local_model,
            reason="local_sufficient",
            complexity=complexity,
        )

    def _has_cloud_api(self) -> bool:
        if not self._cloud_provider:
            return False
        return bool(self._manager.get_api_key_for(self._cloud_provider))
