"""Google Gemini API provider."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, AsyncIterator

import httpx

from homunculus.core.types import ToolCallRequest, ToolCallResult

logger = logging.getLogger(__name__)


class GoogleProvider:
    """Provider for Google Gemini models."""

    def __init__(
        self,
        model_id: str = "gemini-2.0-flash",
        api_key: str | None = None,
        timeout: float = 120,
    ) -> None:
        self._model_id = model_id
        self._api_key = api_key or os.environ.get("GOOGLE_API_KEY", "")
        self._base_url = "https://generativelanguage.googleapis.com/v1beta"
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(timeout))

    async def chat(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        payload = self._build_payload(messages, system, temperature, max_tokens)
        url = f"{self._base_url}/models/{self._model_id}:generateContent?key={self._api_key}"
        resp = await self._client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            return "".join(p.get("text", "") for p in parts)
        return ""

    async def chat_stream(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        payload = self._build_payload(messages, system, temperature, max_tokens)
        url = f"{self._base_url}/models/{self._model_id}:streamGenerateContent?key={self._api_key}&alt=sse"
        async with self._client.stream("POST", url, json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    data = json.loads(line[6:])
                    candidates = data.get("candidates", [])
                    if candidates:
                        parts = candidates[0].get("content", {}).get("parts", [])
                        for p in parts:
                            text = p.get("text", "")
                            if text:
                                yield text

    async def chat_with_tools(
        self,
        messages: list[dict[str, str]],
        tools: list[dict],
        system: str | None = None,
        temperature: float = 0.7,
    ) -> ToolCallResult:
        payload = self._build_payload(messages, system, temperature, 4096)
        payload["tools"] = [{
            "function_declarations": [
                {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                }
                for t in tools
            ]
        }]
        url = f"{self._base_url}/models/{self._model_id}:generateContent?key={self._api_key}"
        resp = await self._client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()

        content_text = ""
        tool_calls = []
        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            for p in parts:
                if "text" in p:
                    content_text += p["text"]
                elif "functionCall" in p:
                    fc = p["functionCall"]
                    tool_calls.append(ToolCallRequest(
                        tool_name=fc.get("name", ""),
                        arguments=fc.get("args", {}),
                    ))

        return ToolCallResult(
            content=content_text,
            tool_calls=tool_calls,
        )

    def supports_tools(self) -> bool:
        return True

    async def setup(self, model_id: str | None = None) -> bool:
        try:
            url = f"{self._base_url}/models?key={self._api_key}"
            resp = await self._client.get(url)
            return resp.status_code == 200
        except Exception:
            logger.error("Failed to connect to Google Gemini API")
            return False

    def _build_payload(
        self,
        messages: list[dict[str, str]],
        system: str | None,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        contents = []
        for msg in messages:
            role = "model" if msg["role"] == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": msg["content"]}]})

        payload: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        return payload

    async def close(self) -> None:
        await self._client.aclose()
