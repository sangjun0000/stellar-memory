"""Anthropic Claude API provider."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, AsyncIterator

import httpx

from homunculus.core.types import ToolCallRequest, ToolCallResult

logger = logging.getLogger(__name__)


class AnthropicProvider:
    """Provider for Anthropic Claude models."""

    def __init__(
        self,
        model_id: str = "claude-sonnet-4-6",
        api_key: str | None = None,
        timeout: float = 120,
    ) -> None:
        self._model_id = model_id
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self._client = httpx.AsyncClient(
            base_url="https://api.anthropic.com",
            headers={
                "x-api-key": self._api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            timeout=httpx.Timeout(timeout),
        )

    async def chat(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        payload = self._build_payload(messages, system, temperature, max_tokens)
        resp = await self._client.post("/v1/messages", json=payload)
        resp.raise_for_status()
        data = resp.json()
        for block in data.get("content", []):
            if block.get("type") == "text":
                return block.get("text", "")
        return ""

    async def chat_stream(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        payload = self._build_payload(messages, system, temperature, max_tokens)
        payload["stream"] = True
        async with self._client.stream(
            "POST", "/v1/messages", json=payload
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    data = json.loads(line[6:])
                    if data.get("type") == "content_block_delta":
                        delta = data.get("delta", {})
                        text = delta.get("text", "")
                        if text:
                            yield text

    async def chat_with_tools(
        self,
        messages: list[dict[str, str]],
        tools: list[dict],
        system: str | None = None,
        temperature: float = 0.7,
    ) -> ToolCallResult:
        payload = self._build_payload(messages, system, temperature, 4096)
        payload["tools"] = [
            {
                "name": t["name"],
                "description": t.get("description", ""),
                "input_schema": t.get("parameters", {}),
            }
            for t in tools
        ]
        resp = await self._client.post("/v1/messages", json=payload)
        resp.raise_for_status()
        data = resp.json()

        content_text = ""
        tool_calls = []
        for block in data.get("content", []):
            if block.get("type") == "text":
                content_text += block.get("text", "")
            elif block.get("type") == "tool_use":
                tool_calls.append(ToolCallRequest(
                    tool_name=block.get("name", ""),
                    arguments=block.get("input", {}),
                    call_id=block.get("id", ""),
                ))

        return ToolCallResult(
            content=content_text,
            tool_calls=tool_calls,
            finish_reason=data.get("stop_reason", ""),
        )

    def supports_tools(self) -> bool:
        return True

    async def setup(self, model_id: str | None = None) -> bool:
        try:
            resp = await self._client.post("/v1/messages", json={
                "model": self._model_id,
                "max_tokens": 10,
                "messages": [{"role": "user", "content": "ping"}],
            })
            return resp.status_code == 200
        except Exception:
            logger.error("Failed to connect to Anthropic API")
            return False

    def _build_payload(
        self,
        messages: list[dict[str, str]],
        system: str | None,
        temperature: float,
        max_tokens: int,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self._model_id,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if system:
            payload["system"] = system
        return payload

    async def close(self) -> None:
        await self._client.aclose()
