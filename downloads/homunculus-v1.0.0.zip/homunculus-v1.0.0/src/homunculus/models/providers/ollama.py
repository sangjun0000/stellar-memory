"""Ollama local model provider."""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
from typing import Any, AsyncIterator

import httpx

from homunculus.core.types import ToolCallRequest, ToolCallResult

logger = logging.getLogger(__name__)


class OllamaProvider:
    """Provider for Ollama local models."""

    def __init__(
        self,
        model_id: str = "llama3.2:3b",
        host: str = "http://localhost:11434",
        timeout: float = 120,
    ) -> None:
        self._model_id = model_id
        self._host = host.rstrip("/")
        self._timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=self._host,
            timeout=httpx.Timeout(timeout),
        )

    async def chat(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        payload: dict[str, Any] = {
            "model": self._model_id,
            "messages": self._build_messages(messages, system),
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        resp = await self._client.post("/api/chat", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "")

    async def chat_stream(
        self,
        messages: list[dict[str, str]],
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        payload: dict[str, Any] = {
            "model": self._model_id,
            "messages": self._build_messages(messages, system),
            "stream": True,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        async with self._client.stream("POST", "/api/chat", json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.strip():
                    data = json.loads(line)
                    content = data.get("message", {}).get("content", "")
                    if content:
                        yield content

    async def chat_with_tools(
        self,
        messages: list[dict[str, str]],
        tools: list[dict],
        system: str | None = None,
        temperature: float = 0.7,
    ) -> ToolCallResult:
        payload: dict[str, Any] = {
            "model": self._model_id,
            "messages": self._build_messages(messages, system),
            "stream": False,
            "tools": tools,
            "options": {"temperature": temperature},
        }
        resp = await self._client.post("/api/chat", json=payload)
        resp.raise_for_status()
        data = resp.json()

        msg = data.get("message", {})
        tool_calls = []
        for tc in msg.get("tool_calls", []):
            fn = tc.get("function", {})
            tool_calls.append(ToolCallRequest(
                tool_name=fn.get("name", ""),
                arguments=fn.get("arguments", {}),
            ))

        return ToolCallResult(
            content=msg.get("content", ""),
            tool_calls=tool_calls,
            finish_reason=data.get("done_reason", ""),
        )

    def supports_tools(self) -> bool:
        return True

    # ─── Setup & Management ───

    async def auto_start(self, timeout: float = 10.0, poll_interval: float = 0.5) -> bool:
        """Ensure the Ollama server is running, starting it if necessary.

        If the server is already reachable, this method returns ``True``
        immediately without spawning a new process.  Otherwise it launches
        ``ollama serve`` as a background process and polls until the server
        becomes available or *timeout* seconds elapse.

        Parameters
        ----------
        timeout:
            Maximum number of seconds to wait for the server to become ready
            after launching it.
        poll_interval:
            Seconds between availability probes.

        Returns
        -------
        bool
            ``True`` when the server is (or became) available, ``False`` when
            it could not be started within the timeout.
        """
        if await self.is_running():
            logger.debug("auto_start: Ollama already running at %s.", self._host)
            return True

        logger.info("auto_start: Ollama not detected — launching 'ollama serve'.")
        try:
            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                # Detach from the current process group so it keeps running
                # even if the parent process exits.
                start_new_session=True,
            )
        except FileNotFoundError:
            logger.error("auto_start: 'ollama' executable not found in PATH.")
            return False
        except OSError as exc:
            logger.error("auto_start: failed to launch 'ollama serve': %s", exc)
            return False

        elapsed = 0.0
        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval
            if await self.is_running():
                logger.info(
                    "auto_start: Ollama became available after %.1f s.", elapsed
                )
                return True

        logger.error(
            "auto_start: Ollama did not become available within %.1f s.", timeout
        )
        return False

    async def is_running(self) -> bool:
        try:
            resp = await self._client.get("/api/tags")
            return resp.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    async def list_local_models(self) -> list[str]:
        try:
            resp = await self._client.get("/api/tags")
            resp.raise_for_status()
            data = resp.json()
            return [m["name"] for m in data.get("models", [])]
        except Exception:
            return []

    async def pull_model(self, model_id: str | None = None) -> AsyncIterator[dict]:
        target = model_id or self._model_id
        payload = {"name": target, "stream": True}
        async with self._client.stream("POST", "/api/pull", json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.strip():
                    yield json.loads(line)

    async def setup(self, model_id: str | None = None) -> bool:
        target = model_id or self._model_id
        if not await self.is_running():
            logger.error("Ollama is not running at %s", self._host)
            return False

        local_models = await self.list_local_models()
        if target in local_models:
            logger.info("Model %s already available", target)
            return True

        logger.info("Pulling model %s...", target)
        async for status in self.pull_model(target):
            if status.get("status") == "success":
                return True
        return False

    def _build_messages(
        self,
        messages: list[dict[str, str]],
        system: str | None,
    ) -> list[dict[str, str]]:
        result = []
        if system:
            result.append({"role": "system", "content": system})
        result.extend(messages)
        return result

    async def close(self) -> None:
        await self._client.aclose()
