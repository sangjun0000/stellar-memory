"""Allow running with `python -m homunculus`."""

from homunculus.main import main

main()
