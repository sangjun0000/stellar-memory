"""Actor - executes an ActionPlan by dispatching each step to the tool layer."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Awaitable, Callable

from homunculus.core.event_bus import EventBus
from homunculus.core.types import ActionPlan, ActionResult, ActionStep
from homunculus.errors import ToolError, ToolExecutionError

logger = logging.getLogger(__name__)

# Callable type: receives an ActionStep, returns an ActionResult coroutine
ToolExecutor = Callable[[ActionStep], Awaitable[ActionResult]]


class Actor:
    """Executes an ActionPlan step-by-step and emits lifecycle events.

    Parallel Execution
    ------------------
    When :meth:`_can_parallelize` returns True for a plan, all steps are
    dispatched concurrently via :meth:`_execute_parallel` using
    ``asyncio.gather``.  Otherwise :meth:`_execute_sequential` runs steps
    one at a time in declaration order.

    Parallelism heuristic: steps are considered independent when every step
    uses a *different* tool name.  This is intentionally conservative —
    steps that share a tool are assumed to share mutable state.

    Events emitted (all pass an ``ActionResult`` as payload):
      - ``actor.step.started``   — before each step executes
      - ``actor.step.succeeded`` — after a successful step
      - ``actor.step.failed``    — after a failed step
      - ``actor.plan.completed`` — after all steps finish
    """

    def __init__(self, tool_executor: ToolExecutor, event_bus: EventBus) -> None:
        self._execute_tool = tool_executor
        self._bus = event_bus

    async def execute(self, plan: ActionPlan) -> list[ActionResult]:
        """Execute all steps in the plan, sequentially or in parallel.

        The decision is made by :meth:`_can_parallelize`.  Regardless of
        execution mode, results are returned in the original step order and
        execution continues even when individual steps fail.
        """
        if self._can_parallelize(plan):
            logger.debug(
                "Actor: executing plan in parallel (%d steps).", len(plan.steps)
            )
            return await self._execute_parallel(plan)
        return await self._execute_sequential(plan)

    # ------------------------------------------------------------------
    # Execution modes
    # ------------------------------------------------------------------

    async def _execute_sequential(self, plan: ActionPlan) -> list[ActionResult]:
        """Execute all steps in the plan sequentially.

        Execution continues even when a step fails so that the Observer can see
        the full picture.  Each failure is recorded in ActionResult.error and
        logged at WARNING level.
        """
        results: list[ActionResult] = []

        for index, step in enumerate(plan.steps):
            logger.debug(
                "Actor executing step %d/%d: %s.%s",
                index + 1,
                len(plan.steps),
                step.tool_name,
                step.action,
            )

            # Notify that the step is about to run
            placeholder = ActionResult(step=step)
            await self._bus.emit_async("actor.step.started", placeholder)

            result = await self._run_step(step)
            results.append(result)

            if result.success:
                await self._bus.emit_async("actor.step.succeeded", result)
            else:
                logger.warning(
                    "Step failed — tool=%s action=%s error=%s",
                    step.tool_name,
                    step.action,
                    result.error,
                )
                await self._bus.emit_async("actor.step.failed", result)

        await self._bus.emit_async("actor.plan.completed", results)
        return results

    async def _execute_parallel(self, plan: ActionPlan) -> list[ActionResult]:
        """Dispatch all steps concurrently and collect results in original order.

        Each step emits its own lifecycle events.  Partial failures are
        tolerated: a step that raises is captured as a failed ActionResult
        rather than aborting the remaining coroutines.
        """
        async def _run_and_emit(index: int, step: ActionStep) -> ActionResult:
            logger.debug(
                "Actor executing step %d/%d (parallel): %s.%s",
                index + 1,
                len(plan.steps),
                step.tool_name,
                step.action,
            )
            placeholder = ActionResult(step=step)
            await self._bus.emit_async("actor.step.started", placeholder)

            result = await self._run_step(step)

            if result.success:
                await self._bus.emit_async("actor.step.succeeded", result)
            else:
                logger.warning(
                    "Parallel step failed — tool=%s action=%s error=%s",
                    step.tool_name,
                    step.action,
                    result.error,
                )
                await self._bus.emit_async("actor.step.failed", result)

            return result

        # asyncio.gather preserves the order of returned values.
        results: list[ActionResult] = await asyncio.gather(
            *(_run_and_emit(i, step) for i, step in enumerate(plan.steps))
        )
        await self._bus.emit_async("actor.plan.completed", results)
        return list(results)

    # ------------------------------------------------------------------
    # Parallelism decision
    # ------------------------------------------------------------------

    def _can_parallelize(self, plan: ActionPlan) -> bool:
        """Return True if all steps in the plan can safely run in parallel.

        Current heuristic: steps are independent when every step uses a
        *different* tool_name.  Steps that share a tool name are assumed to
        share mutable state and must run sequentially.

        Plans with fewer than two steps always return False — there is
        nothing to parallelize.
        """
        if len(plan.steps) < 2:
            return False
        tool_names = [step.tool_name for step in plan.steps]
        return len(tool_names) == len(set(tool_names))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _run_step(self, step: ActionStep) -> ActionResult:
        """Delegate to the tool executor, capturing timing and exceptions."""
        start = time.monotonic()
        try:
            result = await self._execute_tool(step)
            result.duration_ms = (time.monotonic() - start) * 1000
            return result
        except (ToolError, ToolExecutionError) as exc:
            duration_ms = (time.monotonic() - start) * 1000
            logger.warning(
                "Tool error in %s.%s: %s",
                step.tool_name,
                step.action,
                exc,
            )
            return ActionResult(
                step=step,
                success=False,
                error=f"{type(exc).__name__}: {exc}",
                duration_ms=duration_ms,
            )
        except Exception as exc:
            duration_ms = (time.monotonic() - start) * 1000
            logger.exception(
                "Unhandled exception in tool executor for %s.%s",
                step.tool_name,
                step.action,
            )
            return ActionResult(
                step=step,
                success=False,
                error=f"{type(exc).__name__}: {exc}",
                duration_ms=duration_ms,
            )
