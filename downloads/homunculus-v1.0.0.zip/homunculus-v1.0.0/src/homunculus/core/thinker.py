"""Thinker - the cognitive core that interprets perceptions via an AI model."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import Perception, Thought
from homunculus.errors import ModelConnectionError, ModelError, ModelTimeoutError, WebSearchError
from homunculus.memory.recall import RecallStrategy

if TYPE_CHECKING:
    from homunculus.core.web_search import WebSearchProvider
    from homunculus.memory.bridge import MemoryBridge
    from homunculus.models.interface import ModelInterface

logger = logging.getLogger(__name__)

# Keywords that indicate the perception is an information request.
# When any of these appear in the lowercased content, web search is triggered.
_SEARCH_TRIGGERS: frozenset[str] = frozenset(
    {"?", "what", "how", "why", "when", "where", "search", "find"}
)

# ---------------------------------------------------------------------------
# Prompt constants
# ---------------------------------------------------------------------------

_THINKER_SYSTEM = """\
You are the cognitive core of an autonomous AI agent called Homunculus.
Your job is to THINK — not to respond to the user directly.

Given a perception (what just happened or was said) and relevant memories,
produce a structured internal monologue that decides what the agent should do.

Chain-of-thought reasoning instructions:
1. First, restate the situation in your own words to confirm understanding.
2. Break the problem into sub-questions and address each one sequentially.
3. Weigh the evidence from memories and any web search results provided.
4. If confidence would be below 0.4, add a self-reflection step: identify
   what information is missing and whether acting without it is safe.
5. Only then form your final decision.

Respond ONLY with this JSON structure — no markdown fences, no extra text:
{
  "reasoning": "<your step-by-step reasoning>",
  "should_act": <true if tools/actions are needed, false otherwise>,
  "should_respond": <true if a reply to the user is needed, false otherwise>,
  "confidence": <float 0.0-1.0 how certain you are>
}

Rules:
- should_act = true only when a concrete task needs tools (file ops, searches,
  shell commands, API calls, etc.)
- should_respond = true when the user or system expects a reply
- Both can be true simultaneously (act, then report back)
- confidence reflects how clear the situation is to you
"""

_CONTEXT_TEMPLATE = """\
=== CURRENT SITUATION ===
Source: {source}
Type: {input_type}
Content: {content}

{memory_section}\
{web_search_section}\
{introspection_section}\
"""

_MEMORY_TEMPLATE = """\
=== RELEVANT MEMORIES ({count}) ===
{entries}

"""

_WEB_SEARCH_TEMPLATE = """\
=== WEB SEARCH RESULTS ({count}) ===
{entries}

"""

_INTROSPECTION_TEMPLATE = """\
=== SELF-KNOWLEDGE ===
Confidence: {confidence:.0%}
Coverage gaps: {gaps}

"""


class Thinker:
    """Processes a Perception into a Thought using an AI model and memories."""

    def __init__(
        self,
        model: ModelInterface,
        memory: MemoryBridge,
        personality_prompt: str = "",
        web_search: WebSearchProvider | None = None,
    ) -> None:
        self._model = model
        self._memory = memory
        self._recall = RecallStrategy()
        self._personality_prompt = personality_prompt
        self._web_search = web_search

    async def think(self, perception: Perception) -> Thought:
        """Analyse a perception and return a structured Thought."""
        # 1. Recall relevant memories in parallel with introspection
        memories = await self._recall.for_thinking(self._memory, perception)
        introspection = await self._memory.introspect(perception.content[:200])

        # 2. Optionally enrich context with live web search results
        web_results: list[dict[str, str]] = []
        if self._web_search and self._is_information_request(perception.content):
            web_results = await self._fetch_web_results(perception.content)

        # 3. Build the context block for the model
        context = self._build_context(perception, memories, introspection, web_results)

        # 4. Compose the system prompt (personality + thinker instructions)
        system = (
            f"{self._personality_prompt}\n\n{_THINKER_SYSTEM}"
            if self._personality_prompt
            else _THINKER_SYSTEM
        )

        # 5. Ask the model to think
        messages = [{"role": "user", "content": context}]
        try:
            raw = await self._model.chat(
                messages=messages,
                system=system,
                temperature=0.3,  # low temp for consistent structured output
                max_tokens=1024,
            )
            parsed = self._parse_response(raw)
        except (ModelError, ModelConnectionError, ModelTimeoutError):
            logger.exception("Thinker model call failed; using safe defaults")
            parsed = {
                "reasoning": "Model call failed; defaulting to respond-only mode.",
                "should_act": False,
                "should_respond": True,
                "confidence": 0.0,
            }
        except Exception:
            logger.exception("Unexpected error in Thinker model call; using safe defaults")
            parsed = {
                "reasoning": "Unexpected error; defaulting to respond-only mode.",
                "should_act": False,
                "should_respond": True,
                "confidence": 0.0,
            }

        thought = Thought(
            perception=perception,
            recalled_memories=memories,
            reasoning=parsed.get("reasoning", ""),
            confidence=float(parsed.get("confidence", 0.0)),
            should_act=bool(parsed.get("should_act", False)),
            should_respond=bool(parsed.get("should_respond", True)),
        )

        logger.debug(
            "Thought: should_act=%s should_respond=%s confidence=%.2f",
            thought.should_act,
            thought.should_respond,
            thought.confidence,
        )
        return thought

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _is_information_request(self, content: str) -> bool:
        """Return True when *content* looks like an information-seeking query."""
        lowered = content.lower()
        return any(trigger in lowered for trigger in _SEARCH_TRIGGERS)

    async def _fetch_web_results(self, content: str) -> list[dict[str, str]]:
        """Run a web search for *content* and return results.

        Returns an empty list on failure so that a search outage never blocks
        the thinking pipeline.
        """
        assert self._web_search is not None  # guarded by caller
        try:
            results = await self._web_search.search(content, max_results=5)
            logger.debug(
                "Web search via %s returned %d results for query: %r",
                self._web_search.name,
                len(results),
                content[:80],
            )
            return results
        except WebSearchError:
            logger.warning(
                "Web search failed for query %r; continuing without results",
                content[:80],
                exc_info=True,
            )
            return []

    def _build_context(
        self,
        perception: Perception,
        memories: list,
        introspection: dict,
        web_results: list[dict[str, str]],
    ) -> str:
        memory_section = ""
        if memories:
            entries = "\n".join(
                f"[zone={m.zone} score={m.score:.2f}] {m.content}"
                for m in memories
            )
            memory_section = _MEMORY_TEMPLATE.format(
                count=len(memories), entries=entries
            )

        web_search_section = ""
        if web_results:
            entries = "\n".join(
                f"[{i + 1}] {r.get('title', '')} — {r.get('url', '')}\n    {r.get('snippet', '')}"
                for i, r in enumerate(web_results)
            )
            web_search_section = _WEB_SEARCH_TEMPLATE.format(
                count=len(web_results), entries=entries
            )

        introspection_section = ""
        if introspection.get("confidence", 0) > 0 or introspection.get("gaps"):
            gaps = ", ".join(introspection.get("gaps", [])) or "none identified"
            introspection_section = _INTROSPECTION_TEMPLATE.format(
                confidence=introspection.get("confidence", 0.0),
                gaps=gaps,
            )

        return _CONTEXT_TEMPLATE.format(
            source=perception.source or "unknown",
            input_type=perception.input_type.value,
            content=perception.content,
            memory_section=memory_section,
            web_search_section=web_search_section,
            introspection_section=introspection_section,
        )

    def _parse_response(self, raw: str) -> dict:
        """Parse JSON from the model response, tolerating minor formatting."""
        import json
        import re

        # Strip markdown fences if the model added them despite instructions
        cleaned = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("`").strip()

        # Find the first complete JSON object in the response
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            raise ValueError(f"No JSON object found in model response: {raw[:200]}")

        return json.loads(match.group())
