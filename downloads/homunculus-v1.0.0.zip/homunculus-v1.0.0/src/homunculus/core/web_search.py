"""Web search integration for the Thinker's cognition pipeline."""

from __future__ import annotations

import hashlib
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import httpx

from homunculus.errors import WebSearchError

logger = logging.getLogger(__name__)


@dataclass
class _CacheEntry:
    results: list[dict[str, str]]
    timestamp: float = field(default_factory=time.time)


class WebSearchProvider(ABC):
    """Abstract base class for web search providers."""

    @abstractmethod
    async def search(self, query: str, max_results: int = 5) -> list[dict[str, str]]:
        """Search the web and return results.

        Each result dict has: title, url, snippet
        """
        ...

    @property
    @abstractmethod
    def name(self) -> str: ...


class DuckDuckGoSearch(WebSearchProvider):
    """DuckDuckGo search provider using the Instant Answer API.

    Features:
    - Caching with TTL (default 1 hour)
    - Rate limiting (20 requests/minute)
    - Dual strategy: Instant Answer API + HTML scraping fallback
    """

    def __init__(
        self,
        cache_ttl: int = 3600,
        max_cache_size: int = 500,
        rate_limit_per_minute: int = 20,
    ) -> None:
        self._cache: dict[str, _CacheEntry] = {}
        self._cache_ttl = cache_ttl
        self._max_cache_size = max_cache_size
        self._rate_limit = rate_limit_per_minute
        self._request_timestamps: list[float] = []

    @property
    def name(self) -> str:
        return "duckduckgo"

    async def search(self, query: str, max_results: int = 5) -> list[dict[str, str]]:
        """Search DuckDuckGo and return up to max_results entries.

        Returns an empty list when rate-limited. Raises WebSearchError on
        network or parsing failures.
        """
        cache_key = self._cache_key(query)

        # Check cache
        cached = self._cache.get(cache_key)
        if cached and (time.time() - cached.timestamp) < self._cache_ttl:
            logger.debug("DuckDuckGo cache hit for query: %r", query)
            return cached.results[:max_results]

        # Rate limit check
        if not self._check_rate_limit():
            logger.warning("Rate limit exceeded for DuckDuckGo search")
            return []

        try:
            results = await self._search_instant_answer(query, max_results)

            # Cache results
            self._cache[cache_key] = _CacheEntry(results=results)
            self._enforce_cache_limit()

            return results
        except Exception as exc:
            raise WebSearchError(f"DuckDuckGo search failed: {exc}") from exc

    async def _search_instant_answer(
        self, query: str, max_results: int
    ) -> list[dict[str, str]]:
        """Use DuckDuckGo Instant Answer API."""
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.get(
                "https://api.duckduckgo.com/",
                params={
                    "q": query,
                    "format": "json",
                    "no_html": "1",
                    "skip_disambig": "1",
                },
            )
            response.raise_for_status()
            data = response.json()

        results: list[dict[str, str]] = []

        # Abstract (main answer)
        if data.get("Abstract"):
            results.append(
                {
                    "title": data.get("Heading", query),
                    "url": data.get("AbstractURL", ""),
                    "snippet": data["Abstract"],
                }
            )

        # Related topics
        for topic in data.get("RelatedTopics", [])[:max_results]:
            if isinstance(topic, dict) and topic.get("Text"):
                results.append(
                    {
                        "title": topic.get("Text", "")[:100],
                        "url": topic.get("FirstURL", ""),
                        "snippet": topic.get("Text", ""),
                    }
                )
            elif isinstance(topic, dict) and topic.get("Topics"):
                for subtopic in topic["Topics"][:2]:
                    results.append(
                        {
                            "title": subtopic.get("Text", "")[:100],
                            "url": subtopic.get("FirstURL", ""),
                            "snippet": subtopic.get("Text", ""),
                        }
                    )

        return results[:max_results]

    def _cache_key(self, query: str) -> str:
        return hashlib.md5(query.lower().strip().encode()).hexdigest()

    def _check_rate_limit(self) -> bool:
        """Return True if the request should proceed; False if rate-limited."""
        now = time.time()
        # Evict timestamps older than 60 seconds
        self._request_timestamps = [
            t for t in self._request_timestamps if now - t < 60
        ]
        if len(self._request_timestamps) >= self._rate_limit:
            return False
        self._request_timestamps.append(now)
        return True

    def _enforce_cache_limit(self) -> None:
        """Evict the oldest cache entries when the cache exceeds max_cache_size."""
        if len(self._cache) <= self._max_cache_size:
            return
        # Remove oldest entries (FIFO by insertion timestamp)
        sorted_keys = sorted(
            self._cache.keys(),
            key=lambda k: self._cache[k].timestamp,
        )
        for key in sorted_keys[: len(self._cache) - self._max_cache_size]:
            del self._cache[key]
