"""Perceiver - receives and queues incoming perceptions for the agent."""

from __future__ import annotations

import asyncio
import logging

from homunculus.core.types import Perception

logger = logging.getLogger(__name__)


class Perceiver:
    """Receives stimuli from the environment and queues them for the agent.

    Uses a priority queue so that high-priority perceptions (lower priority
    number, following asyncio.PriorityQueue convention) are processed first.
    Perception.priority 1 = highest urgency, 10 = lowest.

    Watcher Integration
    -------------------
    Zero or more :class:`~homunculus.core.watchers.base.BaseWatcher` objects
    can be registered via :meth:`add_watcher`.  Each watcher pushes
    :class:`~homunculus.core.types.Perception` objects directly into this
    queue by invoking :meth:`push`.  Call :meth:`start_watchers` once the
    asyncio event loop is running; call :meth:`stop_watchers` during
    shutdown.

    The import of BaseWatcher is deferred to method bodies to avoid a
    circular-import risk and to keep the perceiver importable even when the
    watchers sub-package has not been fully initialised.
    """

    def __init__(self) -> None:
        # PriorityQueue entries are (priority, sequence, perception) tuples.
        # The sequence counter breaks ties and preserves insertion order among
        # equal-priority items, making the sort stable.
        self._queue: asyncio.PriorityQueue[tuple[int, int, Perception]] = (
            asyncio.PriorityQueue()
        )
        self._sequence: int = 0
        # Watchers are stored in a list so insertion order is preserved.
        # We type-hint as list[Any] here to avoid importing the BaseWatcher
        # Protocol at module level; runtime behaviour is correct regardless.
        self._watchers: list = []

    # ------------------------------------------------------------------
    # Core queue API (unchanged from v0)
    # ------------------------------------------------------------------

    def push(self, perception: Perception) -> None:
        """Enqueue a perception.  Thread-safe from any coroutine context."""
        self._sequence += 1
        self._queue.put_nowait((perception.priority, self._sequence, perception))
        logger.debug(
            "Perceiver queued %s (priority=%d, qsize=%d)",
            perception.input_type.value,
            perception.priority,
            self._queue.qsize(),
        )

    async def next(self) -> Perception | None:
        """Return the highest-priority pending Perception, or None if empty.

        Non-blocking: returns immediately rather than waiting for input.
        """
        try:
            _, _, perception = self._queue.get_nowait()
            self._queue.task_done()
            return perception
        except asyncio.QueueEmpty:
            return None

    @property
    def pending(self) -> int:
        """Number of perceptions waiting to be processed."""
        return self._queue.qsize()

    # ------------------------------------------------------------------
    # Watcher management API
    # ------------------------------------------------------------------

    def add_watcher(self, watcher) -> None:
        """Register a watcher with this Perceiver.

        The watcher's ``on_event`` callback is wired to :meth:`push` so that
        any Perception produced by the watcher is automatically enqueued.

        Parameters
        ----------
        watcher:
            Any object satisfying the
            :class:`~homunculus.core.watchers.base.BaseWatcher` protocol.

        Raises
        ------
        ValueError
            If a watcher with the same name is already registered.
        """
        existing_names = {w.name for w in self._watchers}
        if watcher.name in existing_names:
            raise ValueError(
                f"A watcher named '{watcher.name}' is already registered."
            )
        watcher.on_event(self.push)
        self._watchers.append(watcher)
        logger.info("Perceiver: registered watcher '%s'.", watcher.name)

    def remove_watcher(self, name: str) -> None:
        """Unregister a watcher by name.

        If the watcher is currently running, it is **not** automatically
        stopped — call :meth:`stop_watchers` (or stop it individually)
        before removing if clean shutdown is required.

        Parameters
        ----------
        name:
            The ``watcher.name`` that was used when registering.

        Raises
        ------
        KeyError
            If no watcher with that name is registered.
        """
        for index, watcher in enumerate(self._watchers):
            if watcher.name == name:
                del self._watchers[index]
                logger.info("Perceiver: removed watcher '%s'.", name)
                return
        raise KeyError(f"No watcher named '{name}' is registered.")

    async def start_watchers(self) -> None:
        """Start all registered watchers concurrently.

        This must be called from within a running asyncio event loop.
        Individual watcher failures are logged and do not abort the others.
        """
        if not self._watchers:
            logger.debug("Perceiver: no watchers to start.")
            return

        async def _safe_start(watcher) -> None:
            try:
                await watcher.start()
            except Exception:
                logger.exception(
                    "Perceiver: failed to start watcher '%s'.", watcher.name
                )

        await asyncio.gather(*(_safe_start(w) for w in self._watchers))
        logger.info(
            "Perceiver: started %d watcher(s).", len(self._watchers)
        )

    async def stop_watchers(self) -> None:
        """Stop all registered watchers concurrently.

        Individual watcher stop failures are logged and do not abort the
        others, so all watchers receive a stop signal regardless.
        """
        if not self._watchers:
            logger.debug("Perceiver: no watchers to stop.")
            return

        async def _safe_stop(watcher) -> None:
            try:
                await watcher.stop()
            except Exception:
                logger.exception(
                    "Perceiver: failed to stop watcher '%s'.", watcher.name
                )

        await asyncio.gather(*(_safe_stop(w) for w in self._watchers))
        logger.info(
            "Perceiver: stopped %d watcher(s).", len(self._watchers)
        )
