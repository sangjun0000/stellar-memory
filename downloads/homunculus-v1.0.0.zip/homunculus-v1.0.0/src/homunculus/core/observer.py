"""Observer - synthesises ActionResults into a structured Observation."""

from __future__ import annotations

import logging

from homunculus.core.types import ActionPlan, ActionResult, ActionRisk, Observation

logger = logging.getLogger(__name__)

# Side-effect keywords that flag unexpected behaviour in tool output
_UNEXPECTED_KEYWORDS: tuple[str, ...] = (
    "deleted",
    "removed",
    "overwritten",
    "truncated",
    "dropped",
    "terminated",
    "killed",
    "crashed",
    "exception",
    "critical",
    "fatal",
    "permission denied",
    "access denied",
    "unauthorized",
)


class Observer:
    """Examines the results of an ActionPlan and produces an Observation.

    Responsibilities:
    - Determine overall success (all required steps succeeded)
    - Write a human-readable summary
    - Detect unexpected side-effects by scanning output text
    """

    def observe(
        self, plan: ActionPlan, results: list[ActionResult]
    ) -> Observation:
        """Build an Observation from the completed plan and its results."""
        overall_success = self._evaluate_success(results)
        summary = self._build_summary(plan, results, overall_success)
        unexpected = self._detect_unexpected_effects(results)

        if unexpected:
            logger.warning(
                "Observer detected %d unexpected effect(s): %s",
                len(unexpected),
                unexpected,
            )

        observation = Observation(
            plan=plan,
            results=results,
            overall_success=overall_success,
            summary=summary,
            unexpected_effects=unexpected,
        )

        logger.debug(
            "Observation: success=%s steps=%d unexpected=%d",
            overall_success,
            len(results),
            len(unexpected),
        )
        return observation

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _evaluate_success(self, results: list[ActionResult]) -> bool:
        """A plan succeeds when every step that ran reports success."""
        if not results:
            return True  # Nothing to execute == nothing failed
        return all(r.success for r in results)

    def _build_summary(
        self,
        plan: ActionPlan,
        results: list[ActionResult],
        overall_success: bool,
    ) -> str:
        succeeded = sum(1 for r in results if r.success)
        failed = len(results) - succeeded

        status_word = "completed" if overall_success else "partially failed"
        lines = [
            f"Goal '{plan.goal}' {status_word}. "
            f"{succeeded}/{len(results)} step(s) succeeded"
            + (f", {failed} failed." if failed else "."),
        ]

        for i, result in enumerate(results, 1):
            step = result.step
            if result.success:
                output_excerpt = (result.output[:120] + "…") if len(result.output) > 120 else result.output
                lines.append(
                    f"  Step {i} ({step.tool_name}.{step.action}): OK"
                    + (f" — {output_excerpt}" if output_excerpt else "")
                )
            else:
                lines.append(
                    f"  Step {i} ({step.tool_name}.{step.action}): FAILED — {result.error}"
                )

        return "\n".join(lines)

    def _detect_unexpected_effects(
        self, results: list[ActionResult]
    ) -> list[str]:
        """Scan tool output for keywords that suggest unintended side-effects."""
        unexpected: list[str] = []

        for result in results:
            combined_text = (result.output + " " + result.error).lower()

            # Collect explicit side-effects reported by the tool
            for effect in result.side_effects:
                unexpected.append(effect)

            # High-risk steps that also failed deserve special mention
            if (
                not result.success
                and result.step.risk_level
                in (ActionRisk.HIGH, ActionRisk.CRITICAL)
            ):
                unexpected.append(
                    f"High-risk step failed: {result.step.tool_name}.{result.step.action}"
                )

            # Keyword scan for destructive or access-denial signals
            for keyword in _UNEXPECTED_KEYWORDS:
                if keyword in combined_text:
                    note = (
                        f"Keyword '{keyword}' detected in output of "
                        f"{result.step.tool_name}.{result.step.action}"
                    )
                    if note not in unexpected:
                        unexpected.append(note)

        return unexpected
