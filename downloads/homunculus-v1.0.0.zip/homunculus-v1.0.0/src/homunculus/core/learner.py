"""Learner - converts Observations into persistent memories."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import LearningRecord, Observation
from homunculus.memory.recall import RecallStrategy

if TYPE_CHECKING:
    from homunculus.memory.bridge import MemoryBridge
    from homunculus.memory.experience import ExperienceConverter

logger = logging.getLogger(__name__)


class Learner:
    """Translates an Observation into stored memories and graph relationships.

    Learning strategy:
    1. Store an observation-level memory summarising the whole cycle.
    2. Store one action-level memory per step (so individual tool interactions
       are retrievable).
    3. If the plan failed, derive a lesson and store it with high importance.
    4. Link all stored memories to each other so the graph can traverse the
       full episode.
    5. Check for contradictions before finalising (logged, not blocking).
    """

    def __init__(
        self,
        memory: MemoryBridge,
        experience: ExperienceConverter,
    ) -> None:
        self._memory = memory
        self._experience = experience
        self._recall = RecallStrategy()

    async def learn(self, observation: Observation) -> LearningRecord:
        """Store memories from the observation and return a LearningRecord."""
        memory_ids: list[str] = []
        edges_added = 0

        # 1. Observation-level memory
        obs_content, obs_importance, obs_meta = self._experience.from_observation(
            observation
        )
        obs_id = await self._memory.remember(
            content=obs_content,
            importance=obs_importance,
            metadata=obs_meta,
        )
        if obs_id:
            memory_ids.append(obs_id)

        # 2. Per-step action memories
        for result in observation.results:
            step_content, step_importance, step_meta = self._experience.from_action(
                result.step, result
            )
            step_id = await self._memory.remember(
                content=step_content,
                importance=step_importance,
                metadata=step_meta,
            )
            if step_id:
                memory_ids.append(step_id)
                # Link each step back to the observation memory
                if obs_id:
                    await self._memory.link_memories(
                        obs_id, step_id, edge_type="contains_step"
                    )
                    edges_added += 1

        # 3. Derive and store a lesson if the plan failed or had unexpected effects
        lesson = self._derive_lesson(observation)
        if lesson:
            context = obs_content[:300]
            lesson_content, lesson_importance, lesson_meta = (
                self._experience.from_lesson(lesson, context)
            )
            lesson_id = await self._memory.remember(
                content=lesson_content,
                importance=lesson_importance,
                metadata=lesson_meta,
            )
            if lesson_id:
                memory_ids.append(lesson_id)
                if obs_id:
                    await self._memory.link_memories(
                        obs_id, lesson_id, edge_type="generated_lesson"
                    )
                    edges_added += 1

        # 4. Link step memories to each other (sequential chain)
        step_ids = memory_ids[1 : len(observation.results) + 1]  # skip obs_id
        for prev_id, next_id in zip(step_ids, step_ids[1:]):
            await self._memory.link_memories(prev_id, next_id, edge_type="followed_by")
            edges_added += 1

        # 5. Detect contradictions (informational, non-blocking)
        contradictions = await self._recall.for_learning(self._memory, observation)
        if contradictions:
            logger.warning(
                "Learner detected %d memory contradiction(s) after storing new memories.",
                len(contradictions),
            )

        # Compute a simple emotion hint for the record
        emotion = self._compute_emotion(observation)

        record = LearningRecord(
            observation=observation,
            memory_ids=memory_ids,
            importance=obs_importance,
            emotion=emotion,
            lesson=lesson,
            graph_edges_added=edges_added,
        )

        logger.debug(
            "Learner stored %d memories, %d graph edges, lesson=%r",
            len(memory_ids),
            edges_added,
            lesson[:60] if lesson else "",
        )
        return record

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _derive_lesson(self, observation: Observation) -> str:
        """Produce a lesson string when something went wrong or unexpectedly."""
        if not observation.overall_success:
            failed_steps = [
                f"{r.step.tool_name}.{r.step.action}: {r.error}"
                for r in observation.results
                if not r.success
            ]
            if failed_steps:
                return (
                    f"Goal '{observation.plan.goal}' failed. "
                    f"Failed steps: {'; '.join(failed_steps)}. "
                    "Review parameters and preconditions before retrying."
                )

        if observation.unexpected_effects:
            return (
                f"Unexpected effects encountered while pursuing "
                f"'{observation.plan.goal}': "
                f"{', '.join(observation.unexpected_effects[:3])}."
            )

        return ""

    def _compute_emotion(self, observation: Observation) -> dict[str, float]:
        """Map observation outcome to a simple emotion vector."""
        if observation.overall_success and not observation.unexpected_effects:
            return {"joy": 0.6, "surprise": 0.0}
        if not observation.overall_success:
            return {"frustration": 0.5, "surprise": 0.2}
        # Succeeded but with unexpected effects
        return {"surprise": 0.5, "caution": 0.3}
