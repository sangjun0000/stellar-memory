"""ProactiveSuggester — analyzes watcher events and generates proactive suggestions.

The suggester listens for WatcherEvent-bearing Perception objects, applies
a set of rules, and — when a rule fires and the cooldown has elapsed —
returns a new Perception of type SELF_INITIATED that the Perceiver can
enqueue for the agent's attention.

Rules
-----
- FILE_CREATED / FILE_MODIFIED / FILE_DELETED / FILE_MOVED in watched paths
  → suggest reviewing the changes.
- Repeated step failures detected via the EventBus (actor.step.failed)
  → suggest trying an alternative approach.
- PROCESS_HIGH_CPU or PROCESS_HIGH_MEMORY
  → suggest investigating the resource-hungry process.

Cooldown
--------
Each suggestion *type* string has an independent cooldown timer.  A
suggestion of that type will not be generated again until at least
``cooldown`` seconds have elapsed since the last one.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from typing import Any

from homunculus.core.event_bus import EventBus
from homunculus.core.types import (
    InputType,
    Perception,
    WatcherEvent,
    WatcherEventType,
)

logger = logging.getLogger(__name__)

# Suggestion type string constants — also used as EventBus event names.
_SUGGEST_FILE_CHANGE = "suggest.file_change"
_SUGGEST_REPEATED_FAILURE = "suggest.repeated_failure"
_SUGGEST_RESOURCE_ALERT = "suggest.resource_alert"

# How many consecutive failures before raising a suggestion.
_FAILURE_THRESHOLD = 3


class ProactiveSuggester:
    """Analyzes watcher events and generates proactive suggestions.

    Parameters
    ----------
    event_bus:
        The shared EventBus instance.  The suggester subscribes to
        ``actor.step.failed`` to track tool failures.
    cooldown:
        Minimum seconds between suggestions of the same type.
        Defaults to 60 seconds.

    Usage
    -----
    Create the instance, then call :meth:`process_event` for every
    :class:`~homunculus.core.types.Perception` that originates from a
    watcher.  If the method returns a Perception, push it into the
    :class:`~homunculus.core.perceiver.Perceiver` queue.

    Example::

        suggester = ProactiveSuggester(bus)
        def handle(perception: Perception) -> None:
            suggestion = suggester.process_event(perception)
            if suggestion:
                perceiver.push(suggestion)

        file_watcher.on_event(handle)
    """

    def __init__(self, event_bus: EventBus, cooldown: int = 60) -> None:
        self._bus = event_bus
        self._cooldown = cooldown
        # Maps suggestion_type → timestamp of last suggestion
        self._last_suggestion: dict[str, float] = {}
        # Sliding buffer of raw WatcherEvent objects (capped at _max_buffer)
        self._event_buffer: list[WatcherEvent] = []
        self._max_buffer = 100
        # Track consecutive failures per tool name
        self._failure_counts: dict[str, int] = defaultdict(int)
        self._alerted_tools: set[str] = set()

        # Subscribe to actor failure events so we can detect repeated failures
        # without requiring callers to wire this explicitly.
        self._bus.on("actor.step.failed", self._on_step_failed)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process_event(self, event: WatcherEvent) -> Perception | None:
        """Process a watcher event and return a suggestion Perception if appropriate.

        Parameters
        ----------
        event:
            A :class:`~homunculus.core.types.WatcherEvent` to evaluate.

        Returns
        -------
        Perception | None
            A new proactive Perception if a rule fires and the cooldown has
            not been hit; ``None`` otherwise.
        """
        self._buffer_event(event)

        suggestion: Perception | None = None

        if event.event_type in (
            WatcherEventType.FILE_CREATED,
            WatcherEventType.FILE_MODIFIED,
            WatcherEventType.FILE_DELETED,
            WatcherEventType.FILE_MOVED,
        ):
            suggestion = self._suggest_file_change(event)

        elif event.event_type in (
            WatcherEventType.PROCESS_HIGH_CPU,
            WatcherEventType.PROCESS_HIGH_MEMORY,
        ):
            suggestion = self._suggest_resource_alert(event)

        if suggestion:
            logger.info(
                "ProactiveSuggester: emitting suggestion '%s'.",
                suggestion.content[:80],
            )
            self._bus.emit(_SUGGEST_FILE_CHANGE, suggestion)

        return suggestion

    def _should_suggest(self, suggestion_type: str) -> bool:
        """Return True if the cooldown for *suggestion_type* has elapsed."""
        last = self._last_suggestion.get(suggestion_type, 0.0)
        return (time.time() - last) >= self._cooldown

    # ------------------------------------------------------------------
    # Rule implementations
    # ------------------------------------------------------------------

    def _suggest_file_change(self, event: WatcherEvent) -> Perception | None:
        """Rule: file system change → suggest review."""
        if not self._should_suggest(_SUGGEST_FILE_CHANGE):
            return None
        self._last_suggestion[_SUGGEST_FILE_CHANGE] = time.time()

        verb = {
            WatcherEventType.FILE_CREATED: "created",
            WatcherEventType.FILE_MODIFIED: "modified",
            WatcherEventType.FILE_DELETED: "deleted",
            WatcherEventType.FILE_MOVED: "moved",
        }.get(event.event_type, "changed")

        path = event.data.get("path", event.source)
        content = (
            f"[Proactive] File {verb}: {path}.  "
            "Consider reviewing the changes to ensure nothing unexpected occurred."
        )
        return Perception(
            input_type=InputType.SELF_INITIATED,
            content=content,
            source="proactive_suggester",
            priority=6,
            metadata={
                "suggestion_type": _SUGGEST_FILE_CHANGE,
                "trigger_event": event,
                "recent_events": list(self._event_buffer[-5:]),
            },
        )

    def _suggest_resource_alert(self, event: WatcherEvent) -> Perception | None:
        """Rule: high CPU or memory → suggest investigation."""
        if not self._should_suggest(_SUGGEST_RESOURCE_ALERT):
            return None
        self._last_suggestion[_SUGGEST_RESOURCE_ALERT] = time.time()

        if event.event_type == WatcherEventType.PROCESS_HIGH_CPU:
            metric = "CPU"
            value = event.data.get("cpu_percent", "?")
            unit = "%"
        else:
            metric = "memory"
            value = event.data.get("mem_percent", "?")
            unit = "%"

        proc_name = event.data.get("name", event.source)
        threshold = event.data.get("threshold", "?")
        content = (
            f"[Proactive] Process '{proc_name}' is using {value}{unit} {metric} "
            f"(threshold: {threshold}{unit}).  "
            "Consider investigating to prevent system degradation."
        )
        return Perception(
            input_type=InputType.SELF_INITIATED,
            content=content,
            source="proactive_suggester",
            priority=3,
            metadata={
                "suggestion_type": _SUGGEST_RESOURCE_ALERT,
                "trigger_event": event,
            },
        )

    def _suggest_repeated_failure(self, tool_name: str) -> Perception | None:
        """Rule: repeated tool failures → suggest alternative approach."""
        if not self._should_suggest(_SUGGEST_REPEATED_FAILURE):
            return None
        self._last_suggestion[_SUGGEST_REPEATED_FAILURE] = time.time()
        count = self._failure_counts[tool_name]
        content = (
            f"[Proactive] Tool '{tool_name}' has failed {count} consecutive times.  "
            "Consider trying an alternative approach or inspecting the tool's configuration."
        )
        return Perception(
            input_type=InputType.SELF_INITIATED,
            content=content,
            source="proactive_suggester",
            priority=4,
            metadata={
                "suggestion_type": _SUGGEST_REPEATED_FAILURE,
                "tool_name": tool_name,
                "failure_count": count,
            },
        )

    # ------------------------------------------------------------------
    # EventBus subscriber
    # ------------------------------------------------------------------

    def _on_step_failed(self, result: Any) -> None:
        """Sync listener for 'actor.step.failed' events.

        Accumulates consecutive failures per tool and emits a proactive
        suggestion once the threshold is crossed.
        """
        tool_name: str = ""
        try:
            # result is an ActionResult
            tool_name = result.step.tool_name
        except AttributeError:
            return

        self._failure_counts[tool_name] += 1
        # Reset other tools' consecutive counts on success is handled
        # by a separate subscription the caller may add; here we only
        # track failures so the suggester stays focused.

        count = self._failure_counts[tool_name]
        if count >= _FAILURE_THRESHOLD and tool_name not in self._alerted_tools:
            self._alerted_tools.add(tool_name)
            suggestion = self._suggest_repeated_failure(tool_name)
            if suggestion:
                logger.info(
                    "ProactiveSuggester: repeated failure suggestion for tool '%s'.",
                    tool_name,
                )
                self._bus.emit(_SUGGEST_REPEATED_FAILURE, suggestion)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _buffer_event(self, event: WatcherEvent) -> None:
        """Add event to the rolling buffer, evicting the oldest if full."""
        if len(self._event_buffer) >= self._max_buffer:
            self._event_buffer.pop(0)
        self._event_buffer.append(event)

    def reset_failure_count(self, tool_name: str) -> None:
        """Reset the consecutive failure counter for a tool.

        Call this when a tool succeeds to prevent stale alerts.
        """
        self._failure_counts[tool_name] = 0
        self._alerted_tools.discard(tool_name)
