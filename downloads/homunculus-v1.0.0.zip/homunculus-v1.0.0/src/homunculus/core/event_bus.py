"""Event bus for inter-component async communication."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable

logger = logging.getLogger(__name__)


class EventBus:
    """Simple async event bus for Homunculus components."""

    def __init__(self) -> None:
        self._listeners: dict[str, list[Callable]] = defaultdict(list)
        self._async_listeners: dict[str, list[Callable]] = defaultdict(list)

    def on(self, event: str, callback: Callable) -> None:
        if asyncio.iscoroutinefunction(callback):
            self._async_listeners[event].append(callback)
        else:
            self._listeners[event].append(callback)

    def off(self, event: str, callback: Callable) -> None:
        if asyncio.iscoroutinefunction(callback):
            listeners = self._async_listeners.get(event, [])
            if callback in listeners:
                listeners.remove(callback)
        else:
            listeners = self._listeners.get(event, [])
            if callback in listeners:
                listeners.remove(callback)

    def emit(self, event: str, data: Any = None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                logger.exception("Error in sync listener for event '%s'", event)

        # Schedule async listeners if event loop is running
        for cb in self._async_listeners.get(event, []):
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._safe_async_call(cb, event, data))
            except RuntimeError:
                pass

    async def emit_async(self, event: str, data: Any = None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                logger.exception("Error in sync listener for event '%s'", event)

        for cb in self._async_listeners.get(event, []):
            await self._safe_async_call(cb, event, data)

    async def _safe_async_call(
        self, cb: Callable, event: str, data: Any
    ) -> None:
        try:
            await cb(data)
        except Exception:
            logger.exception("Error in async listener for event '%s'", event)

    def clear(self) -> None:
        self._listeners.clear()
        self._async_listeners.clear()
