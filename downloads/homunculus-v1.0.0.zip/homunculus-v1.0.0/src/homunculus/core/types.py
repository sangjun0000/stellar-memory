"""Core data models for Homunculus agent."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ─── Agent State ───

class AgentState(Enum):
    IDLE = "idle"
    PERCEIVING = "perceiving"
    THINKING = "thinking"
    PLANNING = "planning"
    ACTING = "acting"
    OBSERVING = "observing"
    LEARNING = "learning"
    SLEEPING = "sleeping"


class ActionRisk(Enum):
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class InputType(Enum):
    USER_MESSAGE = "user_message"
    SYSTEM_EVENT = "system_event"
    SCHEDULED = "scheduled"
    SELF_INITIATED = "self_initiated"


# ─── Perception ───

@dataclass
class Perception:
    input_type: InputType
    content: str
    source: str = ""
    priority: int = 5
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


# ─── Thought ───

@dataclass
class Thought:
    perception: Perception
    recalled_memories: list[Any] = field(default_factory=list)
    emotion_context: dict[str, float] = field(default_factory=dict)
    reasoning: str = ""
    confidence: float = 0.0
    should_act: bool = False
    should_respond: bool = True


# ─── Action Plan ───

@dataclass
class ActionStep:
    tool_name: str
    action: str
    parameters: dict[str, Any] = field(default_factory=dict)
    risk_level: ActionRisk = ActionRisk.SAFE
    description: str = ""
    rollback_action: dict[str, Any] | None = None


@dataclass
class ActionPlan:
    thought: Thought
    goal: str = ""
    steps: list[ActionStep] = field(default_factory=list)
    requires_approval: bool = False
    estimated_risk: ActionRisk = ActionRisk.SAFE


# ─── Action Result ───

@dataclass
class ActionResult:
    step: ActionStep
    success: bool = False
    output: str = ""
    error: str = ""
    duration_ms: float = 0.0
    side_effects: list[str] = field(default_factory=list)


# ─── Observation ───

@dataclass
class Observation:
    plan: ActionPlan
    results: list[ActionResult] = field(default_factory=list)
    overall_success: bool = False
    summary: str = ""
    unexpected_effects: list[str] = field(default_factory=list)


# ─── Learning Record ───

@dataclass
class LearningRecord:
    observation: Observation
    memory_ids: list[str] = field(default_factory=list)
    importance: float = 0.5
    emotion: dict[str, float] = field(default_factory=dict)
    lesson: str = ""
    graph_edges_added: int = 0


# ─── Agent Cycle ───

@dataclass
class AgentCycle:
    cycle_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    perception: Perception | None = None
    thought: Thought | None = None
    plan: ActionPlan | None = None
    results: list[ActionResult] = field(default_factory=list)
    observation: Observation | None = None
    learning: LearningRecord | None = None
    state: AgentState = AgentState.IDLE
    started_at: float = field(default_factory=time.time)
    completed_at: float = 0.0


# ─── Model Configuration ───

@dataclass
class ModelInfo:
    provider: str
    model_id: str
    display_name: str
    description: str = ""
    is_local: bool = False
    requires_api_key: bool = False
    min_ram_gb: float = 0.0
    context_window: int = 4096
    supports_tools: bool = False
    supports_streaming: bool = True
    download_size_gb: float = 0.0


@dataclass
class ProviderConfig:
    provider: str
    api_key: str = ""
    base_url: str = ""
    default_model: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


# ─── Tool Definition ───

@dataclass
class ToolDefinition:
    name: str
    display_name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    risk_level: ActionRisk = ActionRisk.LOW
    enabled: bool = True
    version: str = "1.0.0"
    author: str = ""


@dataclass
class ToolResult:
    success: bool
    output: str = ""
    error: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    rollback_id: str = ""


# ─── Tool Call Result from AI Model ───

@dataclass
class ToolCallRequest:
    tool_name: str
    arguments: dict[str, Any] = field(default_factory=dict)
    call_id: str = ""


@dataclass
class ToolCallResult:
    content: str = ""
    tool_calls: list[ToolCallRequest] = field(default_factory=list)
    finish_reason: str = ""


# ─── Personality Profile ───

@dataclass
class PersonalityProfile:
    name: str
    system_prompt: str
    greeting: str = ""
    tone: str = "professional"
    language: str = "auto"
    emoji_usage: bool = False
    verbosity: str = "normal"


# ─── Safety Log ───

@dataclass
class ActionLogEntry:
    action_id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])
    timestamp: float = field(default_factory=time.time)
    tool_name: str = ""
    action: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    risk_level: ActionRisk = ActionRisk.SAFE
    success: bool = False
    output_summary: str = ""
    rollback_available: bool = False


# ─── Watcher Event ───

class WatcherEventType(Enum):
    FILE_CREATED = "file_created"
    FILE_MODIFIED = "file_modified"
    FILE_DELETED = "file_deleted"
    FILE_MOVED = "file_moved"
    SCHEDULE_TRIGGERED = "schedule_triggered"
    PROCESS_STARTED = "process_started"
    PROCESS_STOPPED = "process_stopped"
    PROCESS_HIGH_CPU = "process_high_cpu"
    PROCESS_HIGH_MEMORY = "process_high_memory"


@dataclass
class WatcherEvent:
    event_type: WatcherEventType
    source: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    priority: int = 5


class ScheduleState(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"


@dataclass
class ScheduledTask:
    task_id: str
    name: str
    cron_expression: str = ""
    interval_seconds: float = 0.0
    action: ActionStep | None = None
    callback_event: str = ""
    state: ScheduleState = ScheduleState.PENDING
    next_run: float = 0.0
    last_run: float = 0.0
    run_count: int = 0
    max_runs: int = 0
    created_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WebSearchResult:
    title: str
    url: str
    snippet: str
    source: str = ""
    relevance_score: float = 0.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class CodeAnalysis:
    file_path: str
    language: str = "python"
    functions: list[dict[str, Any]] = field(default_factory=list)
    classes: list[dict[str, Any]] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    line_count: int = 0
    complexity: float = 0.0
    dependencies: list[str] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)


@dataclass
class RollbackTransaction:
    transaction_id: str
    action_id: str
    tool_name: str
    action: str
    undo_type: str
    undo_data: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    executed: bool = False
    success: bool = False
