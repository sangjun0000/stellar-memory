"""ProcessWatcher — monitors running processes via psutil.

Requires the optional ``psutil`` package.  If it is not installed the
watcher still constructs and registers successfully, but ``start()``
raises ``RuntimeError`` with a clear installation message.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Callable

from homunculus.core.types import InputType, Perception, WatcherEvent, WatcherEventType

try:
    import psutil

    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

logger = logging.getLogger(__name__)

# Default thresholds
_DEFAULT_CPU_THRESHOLD = 90.0    # percent
_DEFAULT_MEM_THRESHOLD = 90.0    # percent of process RSS vs total RAM


@dataclass
class _ProcessSpec:
    """What to watch and at what thresholds."""

    # Either a PID or a name pattern must be provided.
    pid: int | None = None
    name_pattern: str = ""
    cpu_threshold: float = _DEFAULT_CPU_THRESHOLD
    mem_threshold: float = _DEFAULT_MEM_THRESHOLD

    # Runtime state: tracks whether the process was alive on the last check
    last_seen_alive: bool = False
    # Timestamp of last threshold alert to avoid alert storms
    last_cpu_alert: float = 0.0
    last_mem_alert: float = 0.0
    # Minimum seconds between repeated threshold alerts for the same spec
    alert_cooldown: float = 60.0


class ProcessWatcher:
    """Polls running processes for start/stop events and resource thresholds.

    Parameters
    ----------
    poll_interval:
        How often (in seconds) to poll the process list.  Defaults to 5.0.
    watcher_name:
        Unique identifier used by the Perceiver.  Defaults to
        ``"process_watcher"``.
    alert_cooldown:
        Default minimum seconds between repeated CPU/memory alerts for the
        same process spec.  Defaults to 60.0.
    """

    def __init__(
        self,
        poll_interval: float = 5.0,
        watcher_name: str = "process_watcher",
        alert_cooldown: float = 60.0,
    ) -> None:
        self._name = watcher_name
        self._poll_interval = poll_interval
        self._alert_cooldown = alert_cooldown
        self._running = False
        self._callbacks: list[Callable[[Perception], None]] = []
        self._specs: list[_ProcessSpec] = []
        self._task: asyncio.Task | None = None

    # ------------------------------------------------------------------
    # BaseWatcher protocol
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def is_running(self) -> bool:
        return self._running

    async def start(self) -> None:
        """Start polling.

        Raises
        ------
        RuntimeError
            If ``psutil`` is not installed.
        """
        if not HAS_PSUTIL:
            raise RuntimeError(
                "ProcessWatcher requires the 'psutil' package.  "
                "Install it with: pip install psutil"
            )
        if self._running:
            logger.warning("ProcessWatcher '%s' is already running.", self._name)
            return
        self._running = True
        self._task = asyncio.create_task(
            self._poll_loop(), name=f"process_watcher:{self._name}"
        )
        logger.info(
            "ProcessWatcher '%s' started (poll_interval=%.1fs, %d spec(s)).",
            self._name,
            self._poll_interval,
            len(self._specs),
        )

    async def stop(self) -> None:
        """Stop polling and cancel the background task."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        logger.info("ProcessWatcher '%s' stopped.", self._name)

    def on_event(self, callback: Callable[[Perception], None]) -> None:
        """Register a callback to receive Perception objects on process events."""
        self._callbacks.append(callback)

    # ------------------------------------------------------------------
    # Spec management API
    # ------------------------------------------------------------------

    def watch_pid(
        self,
        pid: int,
        cpu_threshold: float = _DEFAULT_CPU_THRESHOLD,
        mem_threshold: float = _DEFAULT_MEM_THRESHOLD,
        alert_cooldown: float | None = None,
    ) -> None:
        """Watch a specific process by PID."""
        self._specs.append(
            _ProcessSpec(
                pid=pid,
                cpu_threshold=cpu_threshold,
                mem_threshold=mem_threshold,
                alert_cooldown=alert_cooldown if alert_cooldown is not None else self._alert_cooldown,
            )
        )
        logger.debug("ProcessWatcher '%s': watching PID %d.", self._name, pid)

    def watch_name(
        self,
        name_pattern: str,
        cpu_threshold: float = _DEFAULT_CPU_THRESHOLD,
        mem_threshold: float = _DEFAULT_MEM_THRESHOLD,
        alert_cooldown: float | None = None,
    ) -> None:
        """Watch processes whose name contains *name_pattern* (case-insensitive)."""
        self._specs.append(
            _ProcessSpec(
                name_pattern=name_pattern.lower(),
                cpu_threshold=cpu_threshold,
                mem_threshold=mem_threshold,
                alert_cooldown=alert_cooldown if alert_cooldown is not None else self._alert_cooldown,
            )
        )
        logger.debug(
            "ProcessWatcher '%s': watching name pattern '%s'.",
            self._name,
            name_pattern,
        )

    # ------------------------------------------------------------------
    # Polling loop
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        while self._running:
            try:
                await self._check_all()
            except Exception:
                logger.exception("ProcessWatcher '%s': error during poll.", self._name)
            await asyncio.sleep(self._poll_interval)

    async def _check_all(self) -> None:
        """Run one polling cycle for all registered specs."""
        # Offload the blocking psutil calls to a thread-pool executor
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._check_all_sync)

    def _check_all_sync(self) -> None:
        """Synchronous poll — called from executor thread."""
        total_ram = psutil.virtual_memory().total  # type: ignore[union-attr]
        running_procs = {p.pid: p for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"])}  # type: ignore[union-attr]

        for spec in self._specs:
            matched = self._match_procs(spec, running_procs)
            is_alive = len(matched) > 0

            if is_alive and not spec.last_seen_alive:
                # Process started (or first seen)
                for proc in matched:
                    self._dispatch(
                        WatcherEvent(
                            event_type=WatcherEventType.PROCESS_STARTED,
                            source=self._name,
                            data=self._proc_data(proc),
                            priority=4,
                        )
                    )

            elif not is_alive and spec.last_seen_alive:
                # Process stopped
                identifier = spec.pid if spec.pid is not None else spec.name_pattern
                self._dispatch(
                    WatcherEvent(
                        event_type=WatcherEventType.PROCESS_STOPPED,
                        source=self._name,
                        data={"identifier": identifier},
                        priority=4,
                    )
                )

            spec.last_seen_alive = is_alive

            # Resource threshold checks
            now = time.monotonic()
            for proc in matched:
                self._check_cpu(spec, proc, now)
                self._check_memory(spec, proc, now, total_ram)

    # ------------------------------------------------------------------
    # Matching helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _match_procs(
        spec: _ProcessSpec,
        running: dict[int, psutil.Process],  # type: ignore[name-defined]
    ) -> list[psutil.Process]:  # type: ignore[name-defined]
        """Return processes that match this spec."""
        if spec.pid is not None:
            proc = running.get(spec.pid)
            return [proc] if proc is not None else []
        # Name-based matching
        results = []
        for proc in running.values():
            try:
                if spec.name_pattern in (proc.name() or "").lower():
                    results.append(proc)
            except (psutil.NoSuchProcess, psutil.AccessDenied):  # type: ignore[union-attr]
                pass
        return results

    # ------------------------------------------------------------------
    # Threshold checks
    # ------------------------------------------------------------------

    def _check_cpu(
        self,
        spec: _ProcessSpec,
        proc: psutil.Process,  # type: ignore[name-defined]
        now: float,
    ) -> None:
        try:
            cpu = proc.cpu_percent(interval=None)
        except (psutil.NoSuchProcess, psutil.AccessDenied):  # type: ignore[union-attr]
            return
        if cpu >= spec.cpu_threshold and (now - spec.last_cpu_alert) >= spec.alert_cooldown:
            spec.last_cpu_alert = now
            self._dispatch(
                WatcherEvent(
                    event_type=WatcherEventType.PROCESS_HIGH_CPU,
                    source=self._name,
                    data={**self._proc_data(proc), "cpu_percent": cpu, "threshold": spec.cpu_threshold},
                    priority=3,
                )
            )

    def _check_memory(
        self,
        spec: _ProcessSpec,
        proc: psutil.Process,  # type: ignore[name-defined]
        now: float,
        total_ram: int,
    ) -> None:
        try:
            mem_info = proc.memory_info()
        except (psutil.NoSuchProcess, psutil.AccessDenied):  # type: ignore[union-attr]
            return
        if total_ram == 0:
            return
        mem_pct = (mem_info.rss / total_ram) * 100.0
        if mem_pct >= spec.mem_threshold and (now - spec.last_mem_alert) >= spec.alert_cooldown:
            spec.last_mem_alert = now
            self._dispatch(
                WatcherEvent(
                    event_type=WatcherEventType.PROCESS_HIGH_MEMORY,
                    source=self._name,
                    data={
                        **self._proc_data(proc),
                        "rss_bytes": mem_info.rss,
                        "mem_percent": round(mem_pct, 2),
                        "threshold": spec.mem_threshold,
                    },
                    priority=3,
                )
            )

    # ------------------------------------------------------------------
    # Dispatch helper
    # ------------------------------------------------------------------

    @staticmethod
    def _proc_data(proc: psutil.Process) -> dict:  # type: ignore[name-defined]
        """Extract safe metadata from a psutil Process."""
        try:
            return {"pid": proc.pid, "name": proc.name()}
        except (psutil.NoSuchProcess, psutil.AccessDenied):  # type: ignore[union-attr]
            return {"pid": proc.pid, "name": "unknown"}

    def _dispatch(self, event: WatcherEvent) -> None:
        """Convert a WatcherEvent to a Perception and call all callbacks."""
        perception = Perception(
            input_type=InputType.SYSTEM_EVENT,
            content=f"Process event: {event.event_type.value} — {event.source}",
            source=self._name,
            priority=event.priority,
            metadata={"watcher_event": event},
        )
        for callback in self._callbacks:
            try:
                callback(perception)
            except Exception:
                logger.exception(
                    "Error in ProcessWatcher '%s' callback.", self._name
                )
