"""BaseWatcher Protocol — the contract every watcher must satisfy."""

from __future__ import annotations

from typing import Callable, Protocol, runtime_checkable

from homunculus.core.types import Perception


@runtime_checkable
class BaseWatcher(Protocol):
    """Structural protocol for perception watchers.

    Watchers monitor external events (file changes, schedules, processes)
    and push Perception objects when events are detected.

    All concrete implementations must satisfy this protocol. Because this is
    a ``@runtime_checkable`` Protocol, ``isinstance(obj, BaseWatcher)``
    works correctly without the concrete class inheriting from BaseWatcher.
    """

    @property
    def name(self) -> str:
        """Unique identifier for this watcher."""
        ...

    @property
    def is_running(self) -> bool:
        """Whether the watcher is currently active."""
        ...

    async def start(self) -> None:
        """Start watching for events."""
        ...

    async def stop(self) -> None:
        """Stop watching and clean up resources."""
        ...

    def on_event(self, callback: Callable[[Perception], None]) -> None:
        """Register a callback to receive Perception objects.

        Multiple callbacks may be registered; all are invoked on each event.
        """
        ...
