"""Watcher sub-package — reactive perception sources for Homunculus.

Exports the BaseWatcher protocol and all concrete watcher implementations.
Each concrete watcher satisfies the BaseWatcher protocol via structural
subtyping (no explicit inheritance required).
"""

from __future__ import annotations

from homunculus.core.watchers.base import BaseWatcher
from homunculus.core.watchers.file_watcher import FileWatcher
from homunculus.core.watchers.process_watcher import ProcessWatcher
from homunculus.core.watchers.schedule_watcher import ScheduleWatcher

__all__ = [
    "BaseWatcher",
    "FileWatcher",
    "ProcessWatcher",
    "ScheduleWatcher",
]
