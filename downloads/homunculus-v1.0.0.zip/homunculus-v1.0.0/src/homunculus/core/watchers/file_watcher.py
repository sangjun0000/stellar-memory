"""FileWatcher — monitors directories for file-system changes.

Requires the optional ``watchdog`` package.  If it is not installed the
watcher still constructs and registers successfully, but ``start()`` raises
``RuntimeError`` with a clear message rather than failing with an
``ImportError`` at import time.
"""

from __future__ import annotations

import asyncio
import fnmatch
import logging
import time
from typing import Callable

from homunculus.core.types import InputType, Perception, WatcherEvent, WatcherEventType

try:
    from watchdog.events import (
        DirCreatedEvent,
        DirDeletedEvent,
        DirModifiedEvent,
        DirMovedEvent,
        FileCreatedEvent,
        FileDeletedEvent,
        FileModifiedEvent,
        FileMovedEvent,
        FileSystemEvent,
        FileSystemEventHandler,
    )
    from watchdog.observers import Observer

    HAS_WATCHDOG = True
except ImportError:
    HAS_WATCHDOG = False

logger = logging.getLogger(__name__)

# Map watchdog event types to WatcherEventType values.
_WATCHDOG_TYPE_MAP: dict[str, WatcherEventType] = {
    "created": WatcherEventType.FILE_CREATED,
    "modified": WatcherEventType.FILE_MODIFIED,
    "deleted": WatcherEventType.FILE_DELETED,
    "moved": WatcherEventType.FILE_MOVED,
}


class _DebounceHandler:
    """Watchdog event handler that debounces rapid events and forwards them."""

    def __init__(
        self,
        include_patterns: list[str],
        exclude_patterns: list[str],
        debounce_seconds: float,
        loop: asyncio.AbstractEventLoop,
        forward: Callable[[WatcherEvent], None],
    ) -> None:
        self._include = include_patterns
        self._exclude = exclude_patterns
        self._debounce = debounce_seconds
        self._loop = loop
        self._forward = forward
        # path → (timestamp, event) of the last seen event for that path
        self._pending: dict[str, tuple[float, WatcherEvent]] = {}

    # watchdog calls this from a background thread
    def dispatch(self, event: FileSystemEvent) -> None:  # type: ignore[override]
        src_path: str = getattr(event, "src_path", "")
        if not self._matches(src_path):
            return

        event_type_str: str = event.event_type  # "created", "modified", …
        watcher_type = _WATCHDOG_TYPE_MAP.get(event_type_str)
        if watcher_type is None:
            return

        data: dict = {"path": src_path, "is_directory": event.is_directory}
        dest = getattr(event, "dest_path", None)
        if dest:
            data["dest_path"] = dest

        watcher_event = WatcherEvent(
            event_type=watcher_type,
            source=src_path,
            data=data,
            priority=5,
        )

        now = time.monotonic()
        self._pending[src_path] = (now, watcher_event)
        # Schedule a debounce flush on the event loop (thread-safe)
        self._loop.call_soon_threadsafe(
            self._loop.call_later,
            self._debounce,
            self._flush,
            src_path,
            now,
        )

    def _flush(self, path: str, scheduled_at: float) -> None:
        """Emit only if no newer event arrived for this path."""
        entry = self._pending.get(path)
        if entry is None:
            return
        stored_at, watcher_event = entry
        if stored_at == scheduled_at:
            del self._pending[path]
            self._forward(watcher_event)

    def _matches(self, path: str) -> bool:
        """Return True if path passes include/exclude filters."""
        filename = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
        if self._include:
            if not any(fnmatch.fnmatch(filename, p) for p in self._include):
                return False
        if self._exclude:
            if any(fnmatch.fnmatch(filename, p) for p in self._exclude):
                return False
        return True


class FileWatcher:
    """Monitors one or more directories for file-system changes.

    Parameters
    ----------
    directories:
        Paths to watch (must exist when ``start()`` is called).
    include_patterns:
        Glob patterns for file names to include (e.g. ``["*.py", "*.txt"]``).
        An empty list means *all* files are included.
    exclude_patterns:
        Glob patterns for file names to exclude (e.g. ``["*.pyc", ".git"]``).
    debounce_seconds:
        Events for the same path within this window are collapsed into one.
        Defaults to 1.0 second.
    recursive:
        Whether to watch subdirectories recursively.  Defaults to True.
    watcher_name:
        Unique identifier used by the Perceiver.  Defaults to
        ``"file_watcher"``.
    """

    def __init__(
        self,
        directories: list[str],
        include_patterns: list[str] | None = None,
        exclude_patterns: list[str] | None = None,
        debounce_seconds: float = 1.0,
        recursive: bool = True,
        watcher_name: str = "file_watcher",
    ) -> None:
        self._name = watcher_name
        self._directories = directories
        self._include_patterns = include_patterns or []
        self._exclude_patterns = exclude_patterns or []
        self._debounce_seconds = debounce_seconds
        self._recursive = recursive
        self._running = False
        self._callbacks: list[Callable[[Perception], None]] = []
        self._observer: object | None = None  # watchdog Observer

    # ------------------------------------------------------------------
    # BaseWatcher protocol
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def is_running(self) -> bool:
        return self._running

    async def start(self) -> None:
        """Start the watchdog observer thread.

        Raises
        ------
        RuntimeError
            If ``watchdog`` is not installed.
        """
        if not HAS_WATCHDOG:
            raise RuntimeError(
                "FileWatcher requires the 'watchdog' package.  "
                "Install it with: pip install watchdog"
            )
        if self._running:
            logger.warning("FileWatcher '%s' is already running.", self._name)
            return

        loop = asyncio.get_running_loop()
        handler = _DebounceHandler(
            include_patterns=self._include_patterns,
            exclude_patterns=self._exclude_patterns,
            debounce_seconds=self._debounce_seconds,
            loop=loop,
            forward=self._on_watcher_event,
        )
        observer = Observer()  # type: ignore[misc]
        for directory in self._directories:
            observer.schedule(handler, directory, recursive=self._recursive)

        observer.start()
        self._observer = observer
        self._running = True
        logger.info(
            "FileWatcher '%s' started watching %s (recursive=%s).",
            self._name,
            self._directories,
            self._recursive,
        )

    async def stop(self) -> None:
        """Stop the watchdog observer thread."""
        if not self._running:
            return
        observer = self._observer
        if observer is not None:
            observer.stop()  # type: ignore[union-attr]
            # Join in a thread pool so we don't block the event loop
            await asyncio.get_running_loop().run_in_executor(
                None, observer.join  # type: ignore[union-attr]
            )
        self._observer = None
        self._running = False
        logger.info("FileWatcher '%s' stopped.", self._name)

    def on_event(self, callback: Callable[[Perception], None]) -> None:
        """Register a callback to be called with a Perception on each event."""
        self._callbacks.append(callback)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _on_watcher_event(self, event: WatcherEvent) -> None:
        """Convert a WatcherEvent to a Perception and dispatch to callbacks."""
        perception = Perception(
            input_type=InputType.SYSTEM_EVENT,
            content=f"File {event.event_type.value}: {event.source}",
            source=self._name,
            priority=event.priority,
            metadata={"watcher_event": event},
        )
        logger.debug(
            "FileWatcher '%s' dispatching perception: %s",
            self._name,
            perception.content,
        )
        for callback in self._callbacks:
            try:
                callback(perception)
            except Exception:
                logger.exception(
                    "Error in FileWatcher '%s' callback.", self._name
                )
