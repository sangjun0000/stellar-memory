"""ScheduleWatcher — time-based event generation using asyncio tasks.

Supports two schedule formats:
- ``interval_seconds``: fire every N seconds.
- ``cron_expression``: simple cron-like string supporting ``*``, ``*/N``,
  and specific integer values for minute, hour, day-of-month, month,
  day-of-week fields (standard 5-field cron order).

All I/O is async; no external dependencies are required.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Callable

from homunculus.core.types import InputType, Perception, WatcherEventType

logger = logging.getLogger(__name__)


@dataclass
class _Schedule:
    """Internal record for one registered schedule."""

    schedule_id: str
    interval_seconds: float = 0.0
    cron_expression: str = ""
    paused: bool = False
    run_count: int = 0
    max_runs: int = 0  # 0 = unlimited
    task: asyncio.Task | None = field(default=None, repr=False)


def _parse_cron_field(field_str: str, value: int) -> bool:
    """Return True if *value* satisfies a single cron field string.

    Supported field syntax:
    - ``*``      — always matches
    - ``*/N``    — matches when value is divisible by N
    - ``N``      — matches when value equals N
    """
    field_str = field_str.strip()
    if field_str == "*":
        return True
    if field_str.startswith("*/"):
        try:
            divisor = int(field_str[2:])
            return divisor > 0 and value % divisor == 0
        except ValueError:
            return False
    try:
        return int(field_str) == value
    except ValueError:
        return False


def _cron_matches(expression: str) -> bool:
    """Return True if the current local time matches the cron expression.

    Expected format: ``minute hour dom month dow`` (5 fields, space-separated).
    """
    parts = expression.strip().split()
    if len(parts) != 5:
        logger.warning("Invalid cron expression (need 5 fields): %r", expression)
        return False
    t = time.localtime()
    minute, hour, dom, month, dow = parts
    return (
        _parse_cron_field(minute, t.tm_min)
        and _parse_cron_field(hour, t.tm_hour)
        and _parse_cron_field(dom, t.tm_mday)
        and _parse_cron_field(month, t.tm_mon)
        and _parse_cron_field(dow, t.tm_wday)
    )


class ScheduleWatcher:
    """Generates Perception objects when named schedules trigger.

    Parameters
    ----------
    watcher_name:
        Unique identifier used by the Perceiver.  Defaults to
        ``"schedule_watcher"``.
    cron_check_interval:
        How often (in seconds) to poll cron expressions.  Defaults to 60 s.
    """

    def __init__(
        self,
        watcher_name: str = "schedule_watcher",
        cron_check_interval: float = 60.0,
    ) -> None:
        self._name = watcher_name
        self._cron_check_interval = cron_check_interval
        self._running = False
        self._callbacks: list[Callable[[Perception], None]] = []
        self._schedules: dict[str, _Schedule] = {}

    # ------------------------------------------------------------------
    # BaseWatcher protocol
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def is_running(self) -> bool:
        return self._running

    async def start(self) -> None:
        """Activate all registered schedules."""
        if self._running:
            logger.warning("ScheduleWatcher '%s' is already running.", self._name)
            return
        self._running = True
        for schedule_id, schedule in self._schedules.items():
            self._launch_task(schedule)
        logger.info(
            "ScheduleWatcher '%s' started with %d schedule(s).",
            self._name,
            len(self._schedules),
        )

    async def stop(self) -> None:
        """Cancel all running schedule tasks."""
        self._running = False
        for schedule in self._schedules.values():
            if schedule.task and not schedule.task.done():
                schedule.task.cancel()
                try:
                    await schedule.task
                except asyncio.CancelledError:
                    pass
            schedule.task = None
        logger.info("ScheduleWatcher '%s' stopped.", self._name)

    def on_event(self, callback: Callable[[Perception], None]) -> None:
        """Register a callback to receive Perception objects on schedule triggers."""
        self._callbacks.append(callback)

    # ------------------------------------------------------------------
    # Schedule management API
    # ------------------------------------------------------------------

    def add_interval(
        self,
        schedule_id: str,
        interval_seconds: float,
        max_runs: int = 0,
    ) -> None:
        """Register a new interval-based schedule.

        Parameters
        ----------
        schedule_id:
            Unique name for this schedule.
        interval_seconds:
            Fire every this many seconds.
        max_runs:
            Stop after this many triggers (0 = unlimited).
        """
        if schedule_id in self._schedules:
            raise ValueError(f"Schedule '{schedule_id}' already registered.")
        schedule = _Schedule(
            schedule_id=schedule_id,
            interval_seconds=interval_seconds,
            max_runs=max_runs,
        )
        self._schedules[schedule_id] = schedule
        if self._running:
            self._launch_task(schedule)
        logger.debug(
            "ScheduleWatcher '%s': added interval schedule '%s' (%ss).",
            self._name,
            schedule_id,
            interval_seconds,
        )

    def add_cron(
        self,
        schedule_id: str,
        cron_expression: str,
        max_runs: int = 0,
    ) -> None:
        """Register a new cron-based schedule.

        Parameters
        ----------
        schedule_id:
            Unique name for this schedule.
        cron_expression:
            5-field cron string (minute hour dom month dow).
        max_runs:
            Stop after this many triggers (0 = unlimited).
        """
        if schedule_id in self._schedules:
            raise ValueError(f"Schedule '{schedule_id}' already registered.")
        schedule = _Schedule(
            schedule_id=schedule_id,
            cron_expression=cron_expression,
            max_runs=max_runs,
        )
        self._schedules[schedule_id] = schedule
        if self._running:
            self._launch_task(schedule)
        logger.debug(
            "ScheduleWatcher '%s': added cron schedule '%s' (%r).",
            self._name,
            schedule_id,
            cron_expression,
        )

    def pause(self, schedule_id: str) -> None:
        """Suspend a schedule — events are silently dropped while paused."""
        schedule = self._schedules.get(schedule_id)
        if schedule is None:
            raise KeyError(f"Unknown schedule: '{schedule_id}'")
        schedule.paused = True
        logger.debug(
            "ScheduleWatcher '%s': paused schedule '%s'.", self._name, schedule_id
        )

    def resume(self, schedule_id: str) -> None:
        """Resume a previously paused schedule."""
        schedule = self._schedules.get(schedule_id)
        if schedule is None:
            raise KeyError(f"Unknown schedule: '{schedule_id}'")
        schedule.paused = False
        logger.debug(
            "ScheduleWatcher '%s': resumed schedule '%s'.", self._name, schedule_id
        )

    def cancel(self, schedule_id: str) -> None:
        """Permanently remove a schedule and cancel its task."""
        schedule = self._schedules.pop(schedule_id, None)
        if schedule is None:
            raise KeyError(f"Unknown schedule: '{schedule_id}'")
        if schedule.task and not schedule.task.done():
            schedule.task.cancel()
        logger.debug(
            "ScheduleWatcher '%s': cancelled schedule '%s'.", self._name, schedule_id
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _launch_task(self, schedule: _Schedule) -> None:
        """Create an asyncio.Task for the given schedule."""
        if schedule.interval_seconds > 0:
            coro = self._run_interval(schedule)
        else:
            coro = self._run_cron(schedule)
        schedule.task = asyncio.create_task(
            coro, name=f"schedule:{self._name}:{schedule.schedule_id}"
        )

    async def _run_interval(self, schedule: _Schedule) -> None:
        """Loop that fires on a fixed interval."""
        while self._running:
            await asyncio.sleep(schedule.interval_seconds)
            if not self._running:
                break
            if schedule.paused:
                continue
            self._fire(schedule)
            if schedule.max_runs > 0 and schedule.run_count >= schedule.max_runs:
                logger.debug(
                    "ScheduleWatcher '%s': schedule '%s' reached max_runs=%d.",
                    self._name,
                    schedule.schedule_id,
                    schedule.max_runs,
                )
                break

    async def _run_cron(self, schedule: _Schedule) -> None:
        """Loop that checks the cron expression every minute."""
        # Track the last minute we fired so we don't double-fire within a minute.
        last_fired_minute: int = -1
        while self._running:
            await asyncio.sleep(self._cron_check_interval)
            if not self._running:
                break
            if schedule.paused:
                continue
            current_minute = int(time.time() // 60)
            if current_minute == last_fired_minute:
                continue
            if _cron_matches(schedule.cron_expression):
                last_fired_minute = current_minute
                self._fire(schedule)
                if schedule.max_runs > 0 and schedule.run_count >= schedule.max_runs:
                    logger.debug(
                        "ScheduleWatcher '%s': schedule '%s' reached max_runs=%d.",
                        self._name,
                        schedule.schedule_id,
                        schedule.max_runs,
                    )
                    break

    def _fire(self, schedule: _Schedule) -> None:
        """Increment counter, build a Perception, and invoke callbacks."""
        schedule.run_count += 1
        perception = Perception(
            input_type=InputType.SCHEDULED,
            content=f"Schedule triggered: {schedule.schedule_id}",
            source=self._name,
            priority=5,
            metadata={
                "watcher_event": {
                    "event_type": WatcherEventType.SCHEDULE_TRIGGERED.value,
                    "schedule_id": schedule.schedule_id,
                    "run_count": schedule.run_count,
                }
            },
        )
        logger.debug(
            "ScheduleWatcher '%s': firing schedule '%s' (run #%d).",
            self._name,
            schedule.schedule_id,
            schedule.run_count,
        )
        for callback in self._callbacks:
            try:
                callback(perception)
            except Exception:
                logger.exception(
                    "Error in ScheduleWatcher '%s' callback for schedule '%s'.",
                    self._name,
                    schedule.schedule_id,
                )
