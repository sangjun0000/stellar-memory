"""Stellar Memory version detection and compatibility checking."""

from __future__ import annotations

import json
import logging
import urllib.request
from typing import Any

from homunculus import __version__

logger = logging.getLogger(__name__)

MINIMUM_VERSION = "3.0.0"
RECOMMENDED_VERSION = "3.0.0"


def get_installed_version() -> str | None:
    """Return installed stellar-memory version, or None if not installed."""
    try:
        from importlib.metadata import version

        return version("stellar-memory")
    except Exception:
        return None


def parse_version(version_str: str) -> tuple[int, int, int]:
    """Parse 'X.Y.Z' into (major, minor, patch) tuple."""
    parts = version_str.split(".")
    return (int(parts[0]), int(parts[1]), int(parts[2]) if len(parts) > 2 else 0)


def check_compatibility(installed: str) -> dict[str, Any]:
    """Check if installed version meets minimum requirements.

    Returns dict with keys:
    - compatible: bool
    - installed: str
    - minimum: str
    - needs_upgrade: bool
    - is_major_behind: bool
    - message: str
    """
    inst = parse_version(installed)
    mini = parse_version(MINIMUM_VERSION)

    compatible = inst >= mini
    is_major_behind = inst[0] < mini[0]
    needs_upgrade = not compatible

    if compatible:
        message = f"Stellar Memory {installed} — compatible"
    elif is_major_behind:
        message = (
            f"Stellar Memory {installed} is a major version behind "
            f"(minimum: {MINIMUM_VERSION}). Run: pip install --upgrade stellar-memory"
        )
    else:
        message = (
            f"Stellar Memory {installed} needs upgrade to {MINIMUM_VERSION}+. "
            f"Run: pip install --upgrade stellar-memory"
        )

    return {
        "compatible": compatible,
        "installed": installed,
        "minimum": MINIMUM_VERSION,
        "needs_upgrade": needs_upgrade,
        "is_major_behind": is_major_behind,
        "message": message,
    }


def get_latest_pypi_version(timeout: int = 5) -> str | None:
    """Query PyPI for the latest stellar-memory version. Returns None on failure."""
    try:
        url = "https://pypi.org/pypi/stellar-memory/json"
        req = urllib.request.Request(url, headers={"User-Agent": f"Homunculus/{__version__}"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("info", {}).get("version")
    except Exception:
        return None


def check_for_update(timeout: int = 5) -> dict[str, Any]:
    """Check if a newer version is available on PyPI.

    Returns dict with keys:
    - installed: str | None
    - latest: str | None
    - update_available: bool
    - is_major_update: bool
    - message: str
    """
    installed = get_installed_version()
    if not installed:
        return {
            "installed": None,
            "latest": None,
            "update_available": False,
            "is_major_update": False,
            "message": "stellar-memory not installed",
        }

    latest = get_latest_pypi_version(timeout=timeout)
    if not latest:
        return {
            "installed": installed,
            "latest": None,
            "update_available": False,
            "is_major_update": False,
            "message": f"Stellar Memory {installed} (PyPI check failed)",
        }

    inst = parse_version(installed)
    lat = parse_version(latest)
    update_available = lat > inst
    is_major_update = lat[0] > inst[0]

    if not update_available:
        message = f"Stellar Memory {installed} — up to date"
    elif is_major_update:
        message = (
            f"Stellar Memory {installed} → {latest} (major update available). "
            f"Review changelog before upgrading."
        )
    else:
        message = f"Stellar Memory {installed} → {latest} (update available)"

    return {
        "installed": installed,
        "latest": latest,
        "update_available": update_available,
        "is_major_update": is_major_update,
        "message": message,
    }
