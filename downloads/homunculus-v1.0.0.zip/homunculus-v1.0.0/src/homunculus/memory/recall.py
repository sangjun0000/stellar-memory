"""Recall strategies for different agent phases."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from homunculus.core.types import Observation, Perception
    from homunculus.memory.bridge import MemoryBridge, RecalledMemory

# Memory metadata type tags that represent failed or problematic outcomes.
_FAILURE_TYPES: frozenset[str] = frozenset({"failure", "error", "failed_attempt", "lesson"})


class RecallStrategy:
    """Strategies for recalling memories in different agent phases."""

    async def for_thinking(
        self, bridge: MemoryBridge, perception: Perception
    ) -> list[RecalledMemory]:
        """THINK phase: recall context-relevant memories plus related failures.

        The recall pipeline runs in two stages:

        1. Standard semantic recall with confidence estimation.
        2. Failure-awareness: if primary confidence is low, also search for
           memories tagged as failures or errors so the agent can avoid
           repeating known mistakes.
        """
        memories, confidence = await bridge.recall_with_confidence(
            perception.content, limit=7
        )

        # If confidence is low, try broader keyword search
        if confidence < 0.3 and len(perception.content.split()) > 3:
            words = perception.content.split()[:5]
            for keyword in words:
                if len(keyword) > 3:
                    extra = await bridge.recall(keyword, limit=2, include_graph=False)
                    existing_ids = {m.memory_id for m in memories}
                    for m in extra:
                        if m.memory_id not in existing_ids:
                            memories.append(m)
                    break

        # Failure-awareness: surface relevant past failures so the thinker
        # can factor them into its reasoning even when overall confidence is
        # moderate.  We cap at 3 extra entries to avoid flooding the context.
        failure_memories = await self._recall_failures(bridge, perception.content)
        existing_ids = {m.memory_id for m in memories}
        for m in failure_memories:
            if m.memory_id not in existing_ids:
                memories.append(m)

        return memories

    async def for_planning(
        self, bridge: MemoryBridge, goal: str
    ) -> list[RecalledMemory]:
        """PLAN phase: recall similar past actions, outcomes, and failed attempts.

        Failed attempts are surfaced first so the planner can avoid strategies
        that have previously been tried and known to fail.  Successful
        action/observation memories follow so the planner can reuse working
        patterns.
        """
        # Retrieve broad action-related memories
        memories = await bridge.recall(
            f"action goal: {goal}", limit=8, include_graph=False
        )

        # Partition: failures first, then other action memories
        failures = [
            m for m in memories
            if m.metadata.get("type") in _FAILURE_TYPES
        ]
        others = [
            m for m in memories
            if m.metadata.get("type") in ("action", "observation")
            and m.memory_id not in {f.memory_id for f in failures}
        ]

        # Additionally query explicitly for failure memories related to the goal
        extra_failures = await self._recall_failures(bridge, goal)
        existing_ids = {m.memory_id for m in failures + others}
        for m in extra_failures:
            if m.memory_id not in existing_ids:
                failures.append(m)

        # Failures first so they appear prominently in the planner's context
        return failures + others

    async def for_learning(
        self, bridge: MemoryBridge, observation: Observation
    ) -> list[dict]:
        """LEARN phase: detect contradictions before storing new memories."""
        contradictions = await bridge.detect_contradictions()
        return contradictions

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _recall_failures(
        self, bridge: MemoryBridge, query: str, limit: int = 3
    ) -> list[RecalledMemory]:
        """Search for failure/error memories related to *query*.

        Uses targeted semantic queries to surface memories explicitly tagged
        with failure-related types.  Returns at most *limit* entries.
        """
        failure_query = f"failed error mistake problem: {query}"
        candidates = await bridge.recall(
            failure_query, limit=limit * 2, include_graph=False
        )
        # Keep only those explicitly flagged as failures/lessons
        filtered = [
            m for m in candidates
            if m.metadata.get("type") in _FAILURE_TYPES
        ]
        return filtered[:limit]
