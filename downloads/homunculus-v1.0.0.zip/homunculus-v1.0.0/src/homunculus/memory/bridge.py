"""Stellar Memory Bridge - connects stellar-memory as Homunculus's brain."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Stellar Memory imports (optional - graceful degradation)
HAS_STELLAR = False
HAS_BUILDER = False

try:
    from stellar_memory import StellarMemory
    from stellar_memory.models import EmotionVector, MemoryItem

    HAS_STELLAR = True

    # v3.0 Builder pattern (preferred)
    try:
        from stellar_memory import StellarBuilder, Preset

        HAS_BUILDER = True
    except ImportError:
        # Fallback: v2.x config-based initialization
        from stellar_memory.config import (
            DecayConfig,
            EmotionConfig,
            GraphConfig,
            MemoryFunctionConfig,
            MetacognitionConfig,
            ReasoningConfig,
            SelfLearningConfig,
            StellarConfig,
        )
except ImportError:
    StellarMemory = None  # type: ignore[assignment, misc]


class RecalledMemory:
    """Wrapper for recalled memory items."""

    def __init__(
        self,
        memory_id: str,
        content: str,
        zone: int,
        score: float,
        emotion: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.memory_id = memory_id
        self.content = content
        self.zone = zone
        self.score = score
        self.emotion = emotion or {}
        self.metadata = metadata or {}

    def __repr__(self) -> str:
        return f"RecalledMemory(id={self.memory_id[:8]}, zone={self.zone}, score={self.score:.2f})"


class MemoryBridge:
    """Bridges stellar-memory to serve as Homunculus's brain."""

    def __init__(self, db_path: str = "data/homunculus_brain.db", **kwargs: Any) -> None:
        self._db_path = db_path
        self._memory: Any = None
        self._enabled = HAS_STELLAR

        if not HAS_STELLAR:
            logger.warning(
                "stellar-memory not installed. Memory features disabled. "
                "Install with: pip install stellar-memory>=3.0.0"
            )
            return

        if HAS_BUILDER:
            self._memory = self._build_memory(db_path, **kwargs)
        else:
            config = self._build_config_legacy(db_path, **kwargs)
            self._memory = StellarMemory(config=config)
            self._memory.start()

        logger.info("Stellar Memory brain initialized at %s", db_path)

    def _build_memory(self, db_path: str, **kwargs: Any) -> Any:
        """Build StellarMemory using v3.0 Builder pattern with AGENT preset."""
        builder = StellarBuilder(Preset.AGENT)
        builder = builder.with_sqlite(db_path)

        threshold = kwargs.get("graph_auto_link_threshold", 0.65)
        builder = builder.with_graph(auto_link=True, threshold=threshold)

        if kwargs.get("self_learning_enabled", True):
            learning_rate = kwargs.get("learning_rate", 0.03)
            builder = builder.with_self_learning(learning_rate=learning_rate)

        if kwargs.get("decay_enabled", True):
            builder = builder.with_decay(
                rate=kwargs.get("decay_rate", 0.0001),
                decay_days=kwargs.get("decay_days", 30),
            )

        memory = builder.build()
        memory.start()
        return memory

    def _build_config_legacy(self, db_path: str, **kwargs: Any) -> Any:
        """Fallback: build StellarConfig for v2.x compatibility."""
        return StellarConfig(
            db_path=db_path,
            memory_function=MemoryFunctionConfig(
                w_recall=kwargs.get("w_recall", 0.25),
                w_freshness=kwargs.get("w_freshness", 0.25),
                w_arbitrary=kwargs.get("w_arbitrary", 0.20),
                w_context=kwargs.get("w_context", 0.15),
                w_emotion=kwargs.get("w_emotion", 0.15),
            ),
            emotion=EmotionConfig(
                enabled=kwargs.get("emotion_enabled", True),
                use_llm=False,
            ),
            graph=GraphConfig(
                enabled=kwargs.get("graph_enabled", True),
                auto_link=True,
                auto_link_threshold=kwargs.get("graph_auto_link_threshold", 0.65),
            ),
            decay=DecayConfig(enabled=True),
            metacognition=MetacognitionConfig(
                enabled=kwargs.get("metacognition_enabled", True),
            ),
            self_learning=SelfLearningConfig(
                enabled=kwargs.get("self_learning_enabled", True),
                auto_optimize=True,
            ),
            reasoning=ReasoningConfig(
                enabled=kwargs.get("reasoning_enabled", True),
            ),
            reorbit_interval=kwargs.get("reorbit_interval", 300),
        )

    @property
    def enabled(self) -> bool:
        return self._enabled and self._memory is not None

    # ─── Core Operations ───

    async def get_memory(self, memory_id: str) -> RecalledMemory | None:
        """Fetch a single memory by ID. Returns None if not found."""
        if not self.enabled:
            return None
        item = self._memory.get(memory_id)
        if item is None:
            return None
        return self._to_recalled(item)

    async def remember(
        self,
        content: str,
        importance: float = 0.5,
        emotion: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
        content_type: str = "text",
    ) -> str:
        if not self.enabled:
            return ""

        kwargs: dict[str, Any] = {
            "content": content,
            "importance": importance,
            "auto_evaluate": True,
            "content_type": content_type,
        }
        if metadata:
            kwargs["metadata"] = metadata
        if emotion and HAS_STELLAR:
            kwargs["emotion"] = EmotionVector(**emotion)

        item = self._memory.store(**kwargs)
        return item.id

    async def recall(
        self,
        query: str,
        limit: int = 5,
        offset: int = 0,
        include_graph: bool = True,
    ) -> list[RecalledMemory]:
        if not self.enabled:
            return []

        fetch_count = limit + offset
        items = self._memory.recall(query, limit=fetch_count)
        results = [self._to_recalled(item) for item in items]
        results = results[offset:]

        if include_graph and results:
            graph_ids: set[str] = set()
            for r in results[:3]:
                try:
                    related = self._memory.related(r.memory_id, depth=1)
                except AttributeError:
                    related = self._memory.recall_graph(r.memory_id, depth=1)
                for rel in related:
                    if rel.id not in {r.memory_id for r in results}:
                        graph_ids.add(rel.id)

            for gid in list(graph_ids)[:3]:
                item = self._memory.get(gid)
                if item:
                    results.append(self._to_recalled(item))

        return results

    async def recall_with_confidence(
        self, query: str, limit: int = 5
    ) -> tuple[list[RecalledMemory], float]:
        if not self.enabled:
            return [], 0.0

        try:
            result = self._memory._recall_with_confidence(query, top_k=limit)
        except AttributeError:
            result = self._memory.recall_with_confidence(query, top_k=limit)
        memories = [self._to_recalled(item) for item in result.memories]
        return memories, result.confidence

    # ─── Advanced Operations ───

    async def reason(self, query: str) -> dict[str, Any]:
        if not self.enabled:
            return {"insights": [], "confidence": 0.0}

        result = self._memory.reason(query)
        return {
            "insights": result.insights,
            "contradictions": result.contradictions,
            "confidence": result.confidence,
            "reasoning_chain": result.reasoning_chain,
        }

    async def introspect(self, topic: str) -> dict[str, Any]:
        if not self.enabled:
            return {"confidence": 0.0, "gaps": []}

        result = self._memory.introspect(topic)
        return {
            "topic": result.topic,
            "confidence": result.confidence,
            "coverage": result.coverage,
            "gaps": result.gaps,
            "memory_count": result.memory_count,
        }

    async def detect_contradictions(self) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        try:
            items = self._memory._detect_contradictions()
        except AttributeError:
            items = self._memory.detect_contradictions()
        return [
            {
                "memory_a_id": c.memory_a_id,
                "memory_b_id": c.memory_b_id,
                "description": c.description,
                "severity": c.severity,
            }
            for c in items
        ]

    async def narrate(self, topic: str) -> str:
        if not self.enabled:
            return ""
        try:
            return self._memory._narrate(topic)
        except AttributeError:
            return self._memory.narrate(topic)

    async def timeline(
        self,
        start: float | None = None,
        end: float | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        try:
            entries = self._memory._timeline(start=start, end=end, limit=limit)
        except AttributeError:
            entries = self._memory.timeline(start=start, end=end, limit=limit)
        return [
            {
                "timestamp": e.timestamp,
                "memory_id": e.memory_id,
                "content": e.content,
                "zone": e.zone,
                "importance": e.importance,
            }
            for e in entries
        ]

    # ─── Graph Operations ───

    async def link_memories(
        self, source_id: str, target_id: str, edge_type: str = "related_to"
    ) -> None:
        if not self.enabled:
            return
        try:
            self._memory.link(source_id, target_id, relation=edge_type)
        except AttributeError:
            self._memory.graph.add_edge(source_id, target_id, edge_type=edge_type)

    async def find_related(self, memory_id: str, depth: int = 2) -> list[RecalledMemory]:
        """Return memories that are graph-adjacent to *memory_id*.

        Traverses the stellar-memory graph up to *depth* hops from the given
        memory and returns the discovered neighbours as ``RecalledMemory``
        objects, ordered by their total score (descending).
        """
        if not self.enabled:
            return []

        try:
            try:
                related_items = self._memory.related(memory_id, depth=depth)
            except AttributeError:
                related_items = self._memory.recall_graph(memory_id, depth=depth)
            results = [
                self._to_recalled(item)
                for item in related_items
                if item.id != memory_id
            ]
            return sorted(results, key=lambda r: r.score, reverse=True)
        except Exception as exc:
            logger.warning("find_related('%s', depth=%d) failed: %s", memory_id, depth, exc)
            return []

    async def find_hub_memories(self, top_k: int = 10) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        try:
            results = self._memory._graph_centrality(top_k=top_k)
        except AttributeError:
            results = self._memory.graph_centrality(top_k=top_k)

        # v3.0 returns dict[str, float], v2.0 returns list of objects
        if isinstance(results, dict):
            return [
                {"item_id": item_id, "degree": score, "score": score}
                for item_id, score in sorted(results.items(), key=lambda x: -x[1])[:top_k]
            ]
        return [
            {"item_id": r.item_id, "degree": r.degree, "score": r.score}
            for r in results
        ]

    async def find_memory_clusters(self) -> list[list[str]]:
        if not self.enabled:
            return []
        try:
            return self._memory._graph_communities()
        except AttributeError:
            return self._memory.graph_communities()

    # ─── Maintenance ───

    async def health_check(self) -> dict[str, Any]:
        if not self.enabled:
            return {"healthy": False, "reason": "stellar-memory not available"}

        try:
            h = self._memory._health()
        except AttributeError:
            h = self._memory.health()
        return {
            "healthy": h.healthy,
            "total_memories": h.total_memories,
            "graph_edges": h.graph_edges,
            "zone_usage": h.zone_usage,
            "warnings": h.warnings,
        }

    async def optimize(self) -> dict[str, Any]:
        if not self.enabled:
            return {}

        try:
            result = self._memory._optimize()
        except AttributeError:
            result = self._memory.optimize()
        if result is None:
            return {"status": "not enough data"}
        return {
            "before": result.before_weights,
            "after": result.after_weights,
            "improvement": result.improvement,
        }

    async def stats(self) -> dict[str, Any]:
        if not self.enabled:
            return {}

        s = self._memory.stats()
        return {
            "total": s.total_memories,
            "zones": s.zone_counts,
            "capacities": s.zone_capacities,
        }

    async def provide_feedback(self, query: str, used_ids: list[str]) -> None:
        if not self.enabled:
            return
        try:
            self._memory._provide_feedback(query, used_ids)
        except AttributeError:
            self._memory.provide_feedback(query, used_ids)

    def shutdown(self) -> None:
        if self._memory:
            self._memory.stop()
            logger.info("Stellar Memory brain shut down")

    # ─── Internal ───

    def _to_recalled(self, item: Any) -> RecalledMemory:
        emotion_dict = {}
        if hasattr(item, "emotion") and item.emotion is not None:
            emotion_dict = item.emotion.to_dict()
        return RecalledMemory(
            memory_id=item.id,
            content=item.content,
            zone=item.zone,
            score=item.total_score,
            emotion=emotion_dict,
            metadata=item.metadata if hasattr(item, "metadata") else {},
        )
