"""Homunculus - Autonomous AI Agent with Stellar Memory."""

__version__ = "0.1.0"

from homunculus.errors import (
    HomunculusError,
    MemoryError,
    ModelConnectionError,
    ModelError,
    ModelNotFoundError,
    ModelTimeoutError,
    SafetyBlockedError,
    SafetyError,
    ToolError,
    ToolExecutionError,
    ToolPermissionError,
)

__all__ = [
    "HomunculusError",
    "ModelError",
    "ModelNotFoundError",
    "ModelConnectionError",
    "ModelTimeoutError",
    "MemoryError",
    "ToolError",
    "ToolExecutionError",
    "ToolPermissionError",
    "SafetyError",
    "SafetyBlockedError",
]
