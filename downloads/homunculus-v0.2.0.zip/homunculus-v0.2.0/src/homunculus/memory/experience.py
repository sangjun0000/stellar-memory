"""Experience converter - transforms agent experiences into memories."""

from __future__ import annotations

from typing import Any

from homunculus.core.types import ActionResult, ActionStep, Observation


class ExperienceConverter:
    """Converts agent experiences into storable memory format."""

    def from_conversation(
        self, user_msg: str, agent_response: str
    ) -> tuple[str, float, dict[str, Any]]:
        content = f"User said: {user_msg}\nI responded: {agent_response}"
        importance = self._evaluate_conversation_importance(user_msg)
        metadata = {
            "type": "conversation",
            "user_message": user_msg[:500],
        }
        return content, importance, metadata

    def from_action(
        self, action: ActionStep, result: ActionResult
    ) -> tuple[str, float, dict[str, Any]]:
        status = "successfully" if result.success else "failed to"
        content = (
            f"I {status} execute {action.tool_name}.{action.action}: "
            f"{action.description or str(action.parameters)}"
        )
        if result.output:
            content += f"\nResult: {result.output[:300]}"
        if result.error:
            content += f"\nError: {result.error[:200]}"

        importance = 0.7 if not result.success else 0.5
        metadata = {
            "type": "action",
            "tool": action.tool_name,
            "action": action.action,
            "success": result.success,
            "risk_level": action.risk_level.value,
        }
        return content, importance, metadata

    def from_observation(
        self, observation: Observation
    ) -> tuple[str, float, dict[str, Any]]:
        content = f"Goal: {observation.plan.goal}\n"
        content += f"Outcome: {observation.summary}"
        if observation.unexpected_effects:
            content += f"\nUnexpected: {', '.join(observation.unexpected_effects)}"

        importance = 0.6 if observation.overall_success else 0.75
        metadata = {
            "type": "observation",
            "goal": observation.plan.goal,
            "success": observation.overall_success,
            "steps_count": len(observation.results),
        }
        return content, importance, metadata

    def from_lesson(
        self, lesson: str, context: str
    ) -> tuple[str, float, dict[str, Any]]:
        content = f"Lesson learned: {lesson}\nContext: {context}"
        importance = 0.8
        metadata = {"type": "lesson"}
        return content, importance, metadata

    def _evaluate_conversation_importance(self, user_msg: str) -> float:
        msg_lower = user_msg.lower()
        # Direct instructions are important
        if any(kw in msg_lower for kw in [
            "remember", "always", "never", "important", "기억", "항상", "절대",
        ]):
            return 0.85
        # Questions about past context
        if any(kw in msg_lower for kw in [
            "last time", "before", "remember when", "이전에", "저번에",
        ]):
            return 0.6
        # Short casual messages
        if len(user_msg) < 20:
            return 0.2
        return 0.4
