"""Stellar Memory Bridge - connects stellar-memory as Homunculus's brain."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Stellar Memory imports (optional - graceful degradation)
try:
    from stellar_memory import StellarMemory
    from stellar_memory.config import (
        DecayConfig,
        EmotionConfig,
        GraphConfig,
        MemoryFunctionConfig,
        MetacognitionConfig,
        ReasoningConfig,
        SelfLearningConfig,
        StellarConfig,
    )
    from stellar_memory.models import EmotionVector, MemoryItem

    HAS_STELLAR = True
except ImportError:
    HAS_STELLAR = False
    StellarMemory = None  # type: ignore[assignment, misc]


class RecalledMemory:
    """Wrapper for recalled memory items."""

    def __init__(
        self,
        memory_id: str,
        content: str,
        zone: int,
        score: float,
        emotion: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.memory_id = memory_id
        self.content = content
        self.zone = zone
        self.score = score
        self.emotion = emotion or {}
        self.metadata = metadata or {}

    def __repr__(self) -> str:
        return f"RecalledMemory(id={self.memory_id[:8]}, zone={self.zone}, score={self.score:.2f})"


class MemoryBridge:
    """Bridges stellar-memory to serve as Homunculus's brain."""

    def __init__(self, db_path: str = "data/homunculus_brain.db", **kwargs: Any) -> None:
        self._db_path = db_path
        self._memory: Any = None
        self._enabled = HAS_STELLAR

        if not HAS_STELLAR:
            logger.warning(
                "stellar-memory not installed. Memory features disabled. "
                "Install with: pip install stellar-memory"
            )
            return

        config = self._build_config(db_path, **kwargs)
        self._memory = StellarMemory(config=config)
        self._memory.start()
        logger.info("Stellar Memory brain initialized at %s", db_path)

    def _build_config(self, db_path: str, **kwargs: Any) -> Any:
        return StellarConfig(
            db_path=db_path,
            memory_function=MemoryFunctionConfig(
                w_recall=kwargs.get("w_recall", 0.25),
                w_freshness=kwargs.get("w_freshness", 0.25),
                w_arbitrary=kwargs.get("w_arbitrary", 0.20),
                w_context=kwargs.get("w_context", 0.15),
                w_emotion=kwargs.get("w_emotion", 0.15),
            ),
            emotion=EmotionConfig(
                enabled=kwargs.get("emotion_enabled", True),
                use_llm=False,
            ),
            graph=GraphConfig(
                enabled=kwargs.get("graph_enabled", True),
                auto_link=True,
                auto_link_threshold=kwargs.get("graph_auto_link_threshold", 0.65),
            ),
            decay=DecayConfig(enabled=True),
            metacognition=MetacognitionConfig(
                enabled=kwargs.get("metacognition_enabled", True),
            ),
            self_learning=SelfLearningConfig(
                enabled=kwargs.get("self_learning_enabled", True),
                auto_optimize=True,
            ),
            reasoning=ReasoningConfig(
                enabled=kwargs.get("reasoning_enabled", True),
            ),
            reorbit_interval=kwargs.get("reorbit_interval", 300),
        )

    @property
    def enabled(self) -> bool:
        return self._enabled and self._memory is not None

    # ─── Core Operations ───

    async def remember(
        self,
        content: str,
        importance: float = 0.5,
        emotion: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
        content_type: str = "text",
    ) -> str:
        if not self.enabled:
            return ""

        kwargs: dict[str, Any] = {
            "content": content,
            "importance": importance,
            "auto_evaluate": True,
            "content_type": content_type,
        }
        if metadata:
            kwargs["metadata"] = metadata
        if emotion and HAS_STELLAR:
            kwargs["emotion"] = EmotionVector(**emotion)

        item = self._memory.store(**kwargs)
        return item.id

    async def recall(
        self,
        query: str,
        limit: int = 5,
        include_graph: bool = True,
    ) -> list[RecalledMemory]:
        if not self.enabled:
            return []

        items = self._memory.recall(query, limit=limit)
        results = [self._to_recalled(item) for item in items]

        if include_graph and results:
            graph_ids: set[str] = set()
            for r in results[:3]:
                related = self._memory.recall_graph(r.memory_id, depth=1)
                for rel in related:
                    if rel.id not in {r.memory_id for r in results}:
                        graph_ids.add(rel.id)

            for gid in list(graph_ids)[:3]:
                item = self._memory.get(gid)
                if item:
                    results.append(self._to_recalled(item))

        return results

    async def recall_with_confidence(
        self, query: str, limit: int = 5
    ) -> tuple[list[RecalledMemory], float]:
        if not self.enabled:
            return [], 0.0

        result = self._memory.recall_with_confidence(query, top_k=limit)
        memories = [self._to_recalled(item) for item in result.memories]
        return memories, result.confidence

    # ─── Advanced Operations ───

    async def reason(self, query: str) -> dict[str, Any]:
        if not self.enabled:
            return {"insights": [], "confidence": 0.0}

        result = self._memory.reason(query)
        return {
            "insights": result.insights,
            "contradictions": result.contradictions,
            "confidence": result.confidence,
            "reasoning_chain": result.reasoning_chain,
        }

    async def introspect(self, topic: str) -> dict[str, Any]:
        if not self.enabled:
            return {"confidence": 0.0, "gaps": []}

        result = self._memory.introspect(topic)
        return {
            "topic": result.topic,
            "confidence": result.confidence,
            "coverage": result.coverage,
            "gaps": result.gaps,
            "memory_count": result.memory_count,
        }

    async def detect_contradictions(self) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        items = self._memory.detect_contradictions()
        return [
            {
                "memory_a_id": c.memory_a_id,
                "memory_b_id": c.memory_b_id,
                "description": c.description,
                "severity": c.severity,
            }
            for c in items
        ]

    async def narrate(self, topic: str) -> str:
        if not self.enabled:
            return ""
        return self._memory.narrate(topic)

    async def timeline(
        self,
        start: float | None = None,
        end: float | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        entries = self._memory.timeline(start=start, end=end, limit=limit)
        return [
            {
                "timestamp": e.timestamp,
                "memory_id": e.memory_id,
                "content": e.content,
                "zone": e.zone,
                "importance": e.importance,
            }
            for e in entries
        ]

    # ─── Graph Operations ───

    async def link_memories(
        self, source_id: str, target_id: str, edge_type: str = "related_to"
    ) -> None:
        if not self.enabled:
            return
        self._memory.graph.add_edge(source_id, target_id, edge_type=edge_type)

    async def find_related(self, memory_id: str, depth: int = 2) -> list[RecalledMemory]:
        """Return memories that are graph-adjacent to *memory_id*.

        Traverses the stellar-memory graph up to *depth* hops from the given
        memory and returns the discovered neighbours as ``RecalledMemory``
        objects, ordered by their total score (descending).

        If stellar-memory is not available, or if *memory_id* is not found,
        an empty list is returned so callers can degrade gracefully.

        Parameters
        ----------
        memory_id:
            The identifier of the seed memory.
        depth:
            How many graph hops to traverse outward from the seed.
        """
        if not self.enabled:
            return []

        try:
            related_items = self._memory.recall_graph(memory_id, depth=depth)
            results = [
                self._to_recalled(item)
                for item in related_items
                if item.id != memory_id
            ]
            return sorted(results, key=lambda r: r.score, reverse=True)
        except Exception as exc:
            logger.warning("find_related('%s', depth=%d) failed: %s", memory_id, depth, exc)
            return []

    async def find_hub_memories(self, top_k: int = 10) -> list[dict[str, Any]]:
        if not self.enabled:
            return []

        results = self._memory.graph_centrality(top_k=top_k)
        return [
            {"item_id": r.item_id, "degree": r.degree, "score": r.score}
            for r in results
        ]

    async def find_memory_clusters(self) -> list[list[str]]:
        if not self.enabled:
            return []
        return self._memory.graph_communities()

    # ─── Maintenance ───

    async def health_check(self) -> dict[str, Any]:
        if not self.enabled:
            return {"healthy": False, "reason": "stellar-memory not available"}

        h = self._memory.health()
        return {
            "healthy": h.healthy,
            "total_memories": h.total_memories,
            "graph_edges": h.graph_edges,
            "zone_usage": h.zone_usage,
            "warnings": h.warnings,
        }

    async def optimize(self) -> dict[str, Any]:
        if not self.enabled:
            return {}

        result = self._memory.optimize()
        if result is None:
            return {"status": "not enough data"}
        return {
            "before": result.before_weights,
            "after": result.after_weights,
            "improvement": result.improvement,
        }

    async def stats(self) -> dict[str, Any]:
        if not self.enabled:
            return {}

        s = self._memory.stats()
        return {
            "total": s.total_memories,
            "zones": s.zone_counts,
            "capacities": s.zone_capacities,
        }

    async def provide_feedback(self, query: str, used_ids: list[str]) -> None:
        if not self.enabled:
            return
        self._memory.provide_feedback(query, used_ids)

    def shutdown(self) -> None:
        if self._memory:
            self._memory.stop()
            logger.info("Stellar Memory brain shut down")

    # ─── Internal ───

    def _to_recalled(self, item: Any) -> RecalledMemory:
        emotion_dict = {}
        if hasattr(item, "emotion") and item.emotion is not None:
            emotion_dict = item.emotion.to_dict()
        return RecalledMemory(
            memory_id=item.id,
            content=item.content,
            zone=item.zone,
            score=item.total_score,
            emotion=emotion_dict,
            metadata=item.metadata if hasattr(item, "metadata") else {},
        )
