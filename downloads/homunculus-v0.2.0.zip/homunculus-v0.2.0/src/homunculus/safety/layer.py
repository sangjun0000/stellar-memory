"""SafetyLayer — the unified safety facade consumed by the Agent Core.

Composes PermissionGate (policy decisions) and ActionLogger (audit trail)
into a single injectable dependency.  The Agent Core should interact with
this class exclusively; it should never call PermissionGate or ActionLogger
directly.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import (
    ActionLogEntry,
    ActionResult,
    ActionRisk,
    ActionStep,
)

from .logger import ActionLogger
from .permission import PermissionGate

if TYPE_CHECKING:
    from homunculus.core.types import ActionPlan

logger = logging.getLogger(__name__)

# Ordinal list used to find the highest risk in a plan's steps.
_RISK_ORDER: list[ActionRisk] = [
    ActionRisk.SAFE,
    ActionRisk.LOW,
    ActionRisk.MEDIUM,
    ActionRisk.HIGH,
    ActionRisk.CRITICAL,
]


def _risk_index(risk: ActionRisk) -> int:
    try:
        return _RISK_ORDER.index(risk)
    except ValueError:
        return 0


class SafetyLayer:
    """Coordinates risk assessment, access control, and audit logging.

    Constructor parameters
    ----------------------
    safety_level:
        "strict" | "normal" | "permissive" — forwarded to PermissionGate.
    gate:
        Optional pre-constructed PermissionGate (useful for testing).
    action_logger:
        Optional pre-constructed ActionLogger (useful for testing).
    """

    def __init__(
        self,
        safety_level: str = "normal",
        gate: PermissionGate | None = None,
        action_logger: ActionLogger | None = None,
    ) -> None:
        self._gate = gate or PermissionGate(safety_level=safety_level)
        self._logger = action_logger or ActionLogger()
        logger.debug("SafetyLayer ready (level='%s').", self._gate.level)

    # ─── Risk Assessment ───

    def assess_risk(self, plan: ActionPlan) -> ActionRisk:
        """Return the highest ActionRisk found across all steps in the plan.

        If the plan has no steps, the plan's own ``estimated_risk`` field is
        returned as a fallback.
        """
        if not plan.steps:
            return plan.estimated_risk

        max_index = max(_risk_index(s.risk_level) for s in plan.steps)
        highest = _RISK_ORDER[max_index]
        logger.debug(
            "assess_risk: plan with %d steps → %s", len(plan.steps), highest.value
        )
        return highest

    # ─── Permission ───

    def requires_approval(self, plan: ActionPlan) -> bool:
        """Delegate to PermissionGate using the plan's assessed risk."""
        # Always re-assess so the plan's estimated_risk field doesn't need to
        # be pre-populated by the caller.
        assessed = self.assess_risk(plan)
        # Temporarily substitute so PermissionGate sees the fresh value.
        original = plan.estimated_risk
        plan.estimated_risk = assessed
        result = self._gate.requires_approval(plan)
        plan.estimated_risk = original
        return result

    def allow(self, step: ActionStep) -> bool:
        """Return True when the PermissionGate permits *step* to execute."""
        return self._gate.allow(step)

    # ─── Logging ───

    def log_action(self, step: ActionStep, result: ActionResult) -> ActionLogEntry:
        """Record the step/result pair in the audit log and return the entry."""
        return self._logger.log(step, result)

    def get_action_log(
        self,
        limit: int = 50,
        risk_filter: ActionRisk | None = None,
    ) -> list[ActionLogEntry]:
        """Retrieve recent log entries, newest first.

        Parameters
        ----------
        limit:
            Maximum number of entries to return.
        risk_filter:
            When provided, only entries at or above this risk level are returned.
        """
        return self._logger.get_log(limit=limit, risk_filter=risk_filter)

    # ─── Rollback ───

    async def rollback(self, action_id: str) -> bool:
        """Attempt to roll back a previously approved and executed action.

        Parameters
        ----------
        action_id:
            The identifier of the action to undo.  This typically corresponds
            to the ``id`` field on the ``ActionLogEntry`` that was returned by
            ``log_action``.

        Returns
        -------
        bool
            ``True`` when the rollback succeeded, ``False`` otherwise.

        This is a stub for future implementation.  When rollback support is
        added, this method should delegate to an ``ActionRollbacker`` component
        that knows how to reverse specific action types.
        """
        logger.warning(
            "rollback('%s') called but rollback is not yet implemented.", action_id
        )
        return False

    # ─── Accessors ───

    @property
    def safety_level(self) -> str:
        return self._gate.level
