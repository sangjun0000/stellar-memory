"""PermissionGate — decides whether an action or plan may proceed.

The three safety levels map to progressively wider allowances:

  strict     — MEDIUM or above requires human approval
  normal     — only HIGH or above requires approval (default)
  permissive — only CRITICAL requires approval
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import ActionRisk, ActionStep

if TYPE_CHECKING:
    from homunculus.core.types import ActionPlan

logger = logging.getLogger(__name__)

# Maps safety level → minimum ActionRisk that triggers an approval request.
_APPROVAL_THRESHOLDS: dict[str, ActionRisk] = {
    "strict": ActionRisk.MEDIUM,
    "normal": ActionRisk.HIGH,
    "permissive": ActionRisk.CRITICAL,
}

# Risk enum ordinal — lower index means safer.
_RISK_ORDER: list[ActionRisk] = [
    ActionRisk.SAFE,
    ActionRisk.LOW,
    ActionRisk.MEDIUM,
    ActionRisk.HIGH,
    ActionRisk.CRITICAL,
]


def _risk_index(risk: ActionRisk) -> int:
    try:
        return _RISK_ORDER.index(risk)
    except ValueError:
        return len(_RISK_ORDER)


class PermissionGate:
    """Evaluates action risk against the configured safety level.

    Extension point: subclass and override ``allow`` to plug in custom
    deny-lists, time-based windows, or user-role checks.
    """

    def __init__(self, safety_level: str = "normal") -> None:
        level = safety_level.lower()
        if level not in _APPROVAL_THRESHOLDS:
            logger.warning(
                "Unknown safety level '%s', falling back to 'normal'.", safety_level
            )
            level = "normal"
        self._level = level
        self._threshold = _APPROVAL_THRESHOLDS[level]
        logger.debug("PermissionGate initialised with level='%s'.", self._level)

    # ─── Public API ───

    def requires_approval(self, plan: ActionPlan) -> bool:
        """Return True when the plan's overall risk meets or exceeds the
        approval threshold for the current safety level."""
        exceeds = _risk_index(plan.estimated_risk) >= _risk_index(self._threshold)
        if exceeds:
            logger.info(
                "Plan requires approval: estimated_risk=%s, level=%s",
                plan.estimated_risk.value,
                self._level,
            )
        return exceeds

    def allow(self, step: ActionStep) -> bool:
        """Return True when *step* is permitted to execute.

        In the current implementation every step is allowed unless its risk
        level is CRITICAL and the safety level is strict or normal.  The
        SafetyLayer is responsible for calling ``requires_approval`` on the
        plan before individual steps reach this gate.
        """
        # CRITICAL actions are blocked outright in strict/normal modes if they
        # somehow arrive here without prior plan-level approval.
        if step.risk_level == ActionRisk.CRITICAL and self._level != "permissive":
            logger.warning(
                "PermissionGate.allow: CRITICAL step blocked (level=%s): %s",
                self._level,
                step.description or step.tool_name,
            )
            return False
        return True

    @property
    def level(self) -> str:
        return self._level
