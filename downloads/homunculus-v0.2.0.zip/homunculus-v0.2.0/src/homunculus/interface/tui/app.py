"""Homunculus TUI Application."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header

from homunculus.core.types import AgentState
from homunculus.interface.tui.widgets.agent_indicator import AgentIndicator
from homunculus.interface.tui.widgets.chat_panel import ChatPanel
from homunculus.interface.tui.widgets.input_area import InputArea
from homunculus.interface.tui.widgets.status_sidebar import StatusSidebar

if TYPE_CHECKING:
    from homunculus.core.agent import Agent

logger = logging.getLogger(__name__)


class HomuculusApp(App):
    """Homunculus TUI Application."""

    TITLE = "Homunculus"
    SUB_TITLE = "Autonomous AI Agent"
    CSS_PATH = "styles/theme.tcss"

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+t", "toggle_sidebar", "Toggle Sidebar"),
        Binding("ctrl+l", "clear_chat", "Clear Chat"),
    ]

    def __init__(self, agent: Agent) -> None:
        super().__init__()
        self._agent = agent
        self._agent_task: asyncio.Task | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main"):
            with Vertical(id="chat-area"):
                yield ChatPanel(id="chat")
                yield InputArea(id="input")
            yield StatusSidebar(id="sidebar")
        yield Footer()

    async def on_mount(self) -> None:
        # Subscribe to agent events
        self._agent.event_bus.on("agent.response", self._on_agent_response)
        self._agent.event_bus.on("agent.state.changed", self._on_state_change)

        # Start agent loop
        self._agent_task = asyncio.create_task(self._agent.start())

        # Show greeting
        greeting = self._agent.personality.greeting()
        chat = self.query_one("#chat", ChatPanel)
        chat.add_message("agent", greeting)

        # Update sidebar
        sidebar = self.query_one("#sidebar", StatusSidebar)
        await sidebar.refresh_stats(self._agent)

    # ── Event Bridge (EventBus → Textual) ──

    def _on_agent_response(self, data: str | None) -> None:
        if data:
            self.call_from_thread(self._handle_response, data)

    def _handle_response(self, text: str) -> None:
        chat = self.query_one("#chat", ChatPanel)
        chat.add_message("agent", text)

    def _on_state_change(self, state: AgentState | None) -> None:
        if state:
            self.call_from_thread(self._handle_state_change, state)

    def _handle_state_change(self, state: AgentState) -> None:
        try:
            indicator = self.query_one("#agent-state", AgentIndicator)
            indicator.update_state(state)
        except Exception:
            pass

    # ── Input Handling ──

    async def on_input_area_submitted(self, message: InputArea.Submitted) -> None:
        """Handle user message submission."""
        text = message.text
        chat = self.query_one("#chat", ChatPanel)

        # Handle slash commands
        if text.startswith("/"):
            from homunculus.interface.commands import handle_command

            result = await handle_command(self._agent, text)
            if result == "__QUIT__":
                self.exit()
                return
            if result:
                chat.add_message("system", result)
            return

        # Show user message
        chat.add_message("user", text)

        # Send to agent
        await self._agent.handle_message(text)

    # ── Actions ──

    def action_toggle_sidebar(self) -> None:
        sidebar = self.query_one("#sidebar")
        sidebar.toggle_class("hidden")

    def action_clear_chat(self) -> None:
        chat = self.query_one("#chat", ChatPanel)
        chat.clear_messages()

    async def action_quit(self) -> None:
        if self._agent_task:
            await self._agent.stop()
            self._agent_task.cancel()
            try:
                await self._agent_task
            except asyncio.CancelledError:
                pass
        self.exit()
