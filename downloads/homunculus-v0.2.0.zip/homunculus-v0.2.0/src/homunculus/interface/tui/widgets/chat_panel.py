"""Chat message display widget."""

from __future__ import annotations

from textual.containers import VerticalScroll
from textual.widgets import Static


class ChatPanel(VerticalScroll):
    """Scrollable chat message area."""

    def add_message(self, role: str, content: str) -> None:
        """Add a message bubble. role: 'user' | 'agent' | 'system'"""
        widget = ChatMessage(role=role, content=content)
        self.mount(widget)
        self.scroll_end(animate=False)

    def clear_messages(self) -> None:
        self.query(ChatMessage).remove()


class ChatMessage(Static):
    """Individual chat message with role-based styling."""

    def __init__(self, role: str, content: str) -> None:
        self.role = role
        super().__init__(self._render(role, content))
        self.add_class(f"msg-{role}")

    def _render(self, role: str, content: str) -> str:
        labels = {"user": "[You]", "agent": "[Homunculus]", "system": "[System]"}
        label = labels.get(role, "[?]")
        return f"{label}  {content}"
