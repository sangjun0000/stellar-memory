"""Status sidebar widget showing agent info."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Vertical
from textual.widgets import Static

from homunculus.interface.tui.widgets.agent_indicator import AgentIndicator

if TYPE_CHECKING:
    from homunculus.core.agent import Agent


class SectionHeader(Static):
    """Section label in the sidebar."""

    def __init__(self, text: str) -> None:
        super().__init__(f"  {text}")
        self.add_class("section-header")


class StatusSidebar(Vertical):
    """Right sidebar showing agent status, model, memory, tools."""

    async def refresh_stats(self, agent: Agent) -> None:
        """Rebuild sidebar content from agent state."""
        self.query("*").remove()

        # Agent Status
        self.mount(SectionHeader("STATUS"))
        indicator = AgentIndicator(id="agent-state")
        self.mount(indicator)

        # Model Info
        self.mount(SectionHeader("MODEL"))
        model = agent.model_manager.active_model
        if model:
            loc = "Local" if model.is_local else "API"
            self.mount(Static(f"  {model.display_name}"))
            self.mount(Static(f"  Provider: {model.provider}"))
            self.mount(Static(f"  Type: {loc}", classes="dim"))

        # Memory Stats
        self.mount(SectionHeader("MEMORY"))
        stats = await agent.memory.stats()
        if stats:
            total = stats.get("total", 0)
            self.mount(Static(f"  Memories: {total}"))
            zones = stats.get("zones", {})
            zone_names = {0: "Core", 1: "Inner", 2: "Outer", 3: "Belt", 4: "Cloud"}
            for z, count in sorted(zones.items()):
                self.mount(Static(f"  {zone_names.get(z, '?')}: {count}", classes="dim"))

        # Tools
        self.mount(SectionHeader("TOOLS"))
        for tool in agent.tool_registry.list_all():
            icon = "+" if tool.enabled else "-"
            self.mount(Static(f"  {icon} {tool.name}"))

        # Shortcuts
        self.mount(SectionHeader("KEYS"))
        self.mount(Static("  Ctrl+T  Sidebar", classes="dim"))
        self.mount(Static("  Ctrl+L  Clear", classes="dim"))
        self.mount(Static("  Ctrl+Q  Quit", classes="dim"))
