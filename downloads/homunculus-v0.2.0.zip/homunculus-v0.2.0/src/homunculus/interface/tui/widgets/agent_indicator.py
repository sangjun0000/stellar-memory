"""Agent state indicator widget."""

from __future__ import annotations

from textual.widgets import Static

from homunculus.core.types import AgentState

STATE_DISPLAY = {
    AgentState.IDLE: ("Idle", "dot-idle"),
    AgentState.PERCEIVING: ("Listening", "dot-active"),
    AgentState.THINKING: ("Thinking", "dot-thinking"),
    AgentState.PLANNING: ("Planning", "dot-thinking"),
    AgentState.ACTING: ("Acting", "dot-acting"),
    AgentState.OBSERVING: ("Observing", "dot-active"),
    AgentState.LEARNING: ("Learning", "dot-active"),
    AgentState.SLEEPING: ("Sleeping", "dot-idle"),
}


class AgentIndicator(Static):
    """Shows current agent state with colored dot."""

    def __init__(self, **kwargs) -> None:
        super().__init__("  * Idle", **kwargs)

    def update_state(self, state: AgentState) -> None:
        label, css_class = STATE_DISPLAY.get(state, ("Unknown", "dot-idle"))
        self.update(f"  * {label}")
        self.set_classes(css_class)
