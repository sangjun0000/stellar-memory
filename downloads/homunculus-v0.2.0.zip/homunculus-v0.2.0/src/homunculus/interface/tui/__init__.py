"""Textual TUI interface for Homunculus."""
