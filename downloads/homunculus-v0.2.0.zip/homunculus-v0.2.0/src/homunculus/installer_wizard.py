"""Setup wizard that runs inside the installed venv.
Called by installer.py after pip install completes.
Handles: AI model, API key, working scope, safety level.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _select(prompt: str, options: list[str]) -> int:
    print(f"\n  {prompt}")
    for i, opt in enumerate(options, 1):
        print(f"    {i}. {opt}")
    while True:
        try:
            choice = int(input("\n  Select (number): "))
            if 1 <= choice <= len(options):
                return choice - 1
        except (ValueError, EOFError):
            pass
        print("  Invalid selection, try again.")


def _input(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    val = input(f"  {prompt}{suffix}: ").strip()
    return val or default


def run_wizard(install_dir: Path) -> dict:
    config: dict = {"homunculus": {}, "model": {}, "tools": {}}

    # -- Step 2/5: AI Model --
    print("  [Step 2/5] AI Model")
    mode_idx = _select(
        "How would you like to run your AI?",
        [
            "Local (Ollama) - Free, private, offline",
            "Cloud API - Fast, powerful, requires API key",
            "Both - Smart routing (local + cloud)",
        ],
    )

    from homunculus.models.registry import ModelRegistry
    registry = ModelRegistry()

    if mode_idx in (0, 2):
        local_models = registry.list_models("ollama")
        options = [
            f"{m.display_name} ({m.download_size_gb}GB)"
            for m in local_models
        ]
        model_idx = _select("Select a local model:", options)
        selected = local_models[model_idx]
        config["model"]["provider"] = "ollama"
        config["model"]["model_id"] = selected.model_id
        print(f"\n  Selected: {selected.display_name}")
        print(f"  Note: Run 'ollama pull {selected.model_id}' if not downloaded.")

    # -- Step 3/5: API Key (Cloud) --
    if mode_idx in (1, 2):
        print()
        print("  [Step 3/5] Cloud API Setup")
        api_providers = [
            ("anthropic", "Anthropic Claude"),
            ("openai", "OpenAI GPT"),
            ("deepseek", "DeepSeek"),
            ("google", "Google Gemini"),
        ]
        prov_idx = _select("Select provider:", [n for _, n in api_providers])
        provider = api_providers[prov_idx][0]

        api_models = registry.list_models(provider)
        if api_models:
            options = [f"{m.display_name}" for m in api_models]
            model_idx = _select("Select a model:", options)
            selected = api_models[model_idx]
            if mode_idx == 1:
                config["model"]["provider"] = provider
                config["model"]["model_id"] = selected.model_id

        env_vars = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
            "google": "GOOGLE_API_KEY",
        }
        env_var = env_vars.get(provider, "")
        key = _input(f"Enter your {provider} API key (or press Enter to skip)")
        if key:
            # Save to .env file
            env_file = install_dir / ".env"
            lines = []
            if env_file.exists():
                lines = env_file.read_text().splitlines()
            lines = [l for l in lines if not l.startswith(f"{env_var}=")]
            lines.append(f"{env_var}={key}")
            env_file.write_text("\n".join(lines) + "\n")
            print(f"  -> Saved to .env ({env_var})")
    else:
        print()
        print("  [Step 3/5] Cloud API Setup")
        print("  -> Skipped (local mode)")

    # -- Step 4/5: Working Scope --
    print()
    print("  [Step 4/5] Working Scope")
    scope_idx = _select(
        "Where can Homunculus access files?",
        [
            "Home folder only (~/) - Safe default",
            "Specific folders - You choose",
            "Everywhere - Full access (advanced)",
        ],
    )

    if scope_idx == 0:
        config["tools"]["filesystem_allowed_dirs"] = [str(Path.home())]
    elif scope_idx == 1:
        dirs_input = _input("Enter folder paths (comma-separated)")
        dirs = [d.strip() for d in dirs_input.split(",") if d.strip()]
        config["tools"]["filesystem_allowed_dirs"] = dirs
    else:
        config["tools"]["filesystem_allowed_dirs"] = []

    shell_idx = _select(
        "Shell command access:",
        [
            "Allowed - Can run terminal commands (with safety checks)",
            "Restricted - Read-only commands only",
            "Disabled - No shell access",
        ],
    )

    if shell_idx == 0:
        config["tools"]["enabled"] = ["shell", "filesystem"]
    elif shell_idx == 1:
        config["tools"]["enabled"] = ["filesystem"]
        config["tools"]["shell_blocked_commands"] = ["*"]
    else:
        config["tools"]["enabled"] = ["filesystem"]

    # -- Step 5/5: Safety Level --
    print()
    print("  [Step 5/5] Safety Level")
    safety_idx = _select(
        "How cautious should Homunculus be?",
        [
            "Strict - Ask before every action",
            "Normal - Ask for risky actions only (Recommended)",
            "Permissive - Minimal confirmations",
        ],
    )
    config["homunculus"]["safety_level"] = ["strict", "normal", "permissive"][safety_idx]

    # -- Write config --
    config_path = install_dir / "homunculus.toml"
    _write_toml(config_path, config)
    print()
    print(f"  -> Config saved to {config_path}")

    # -- Patch launcher with .env loading --
    _patch_launcher_env(install_dir)

    return config


def _write_toml(path: Path, data: dict) -> None:
    lines = []
    for section, values in data.items():
        if not values:
            continue
        lines.append(f"[{section}]")
        for key, value in values.items():
            if isinstance(value, str):
                lines.append(f'{key} = "{value}"')
            elif isinstance(value, bool):
                lines.append(f"{key} = {'true' if value else 'false'}")
            elif isinstance(value, (int, float)):
                lines.append(f"{key} = {value}")
            elif isinstance(value, list):
                items = ", ".join(f'"{v}"' for v in value)
                lines.append(f"{key} = [{items}]")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def _patch_launcher_env(install_dir: Path) -> None:
    """Add .env loading to launcher scripts."""
    import platform
    system = platform.system()
    env_file = install_dir / ".env"
    if not env_file.exists():
        return

    if system == "Windows":
        launcher = install_dir / "launch.bat"
        if launcher.exists():
            content = launcher.read_text(encoding="utf-8")
            if ".env" not in content:
                content = content.replace(
                    "python -m homunculus",
                    'for /f "tokens=1,2 delims==" %%a in (.env) do set "%%a=%%b"\n'
                    "python -m homunculus",
                )
                launcher.write_text(content, encoding="utf-8")
    else:
        launcher = install_dir / "launch.sh"
        if launcher.exists():
            content = launcher.read_text(encoding="utf-8")
            if ".env" not in content:
                content = content.replace(
                    "python -m homunculus",
                    "set -a; source .env; set +a\n"
                    "python -m homunculus",
                )
                launcher.write_text(content, encoding="utf-8")


if __name__ == "__main__":
    install_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    run_wizard(install_dir)
