"""Agent - the main autonomous loop for Homunculus."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

from homunculus.core.actor import Actor
from homunculus.core.event_bus import EventBus
from homunculus.core.learner import Learner
from homunculus.core.observer import Observer
from homunculus.core.perceiver import Perceiver
from homunculus.core.planner import Planner
from homunculus.core.thinker import Thinker
from homunculus.core.types import (
    AgentCycle,
    AgentState,
    InputType,
    Perception,
)
from homunculus.memory.bridge import MemoryBridge
from homunculus.memory.experience import ExperienceConverter

if TYPE_CHECKING:
    from homunculus.config.settings import Settings
    from homunculus.models.manager import ModelManager
    from homunculus.personality.engine import PersonalityEngine
    from homunculus.safety.layer import SafetyLayer
    from homunculus.tools.registry import ToolRegistry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Events emitted by the Agent
# ---------------------------------------------------------------------------
#   agent.state.changed   → AgentState
#   agent.cycle.started   → AgentCycle
#   agent.cycle.completed → AgentCycle
#   agent.response        → str  (text the agent wants to send to the user)
#   agent.error           → Exception
# ---------------------------------------------------------------------------

# Polling interval when the perceiver has nothing queued
_IDLE_SLEEP_S = 0.05


class Agent:
    """Autonomous agent that runs the Perceive→Think→Plan→Act→Observe→Learn loop.

    Accepts the high-level component objects created by ``main.py`` and wires
    the internal sub-components (Thinker, Planner, Actor, …) from them.
    """

    def __init__(
        self,
        model_manager: ModelManager,
        memory: MemoryBridge,
        tool_registry: ToolRegistry,
        safety: SafetyLayer,
        personality: PersonalityEngine,
        event_bus: EventBus,
        settings: Settings,
    ) -> None:
        # Public-facing components (exposed via properties for CLI / commands)
        self._model_manager = model_manager
        self._memory = memory
        self._tool_registry = tool_registry
        self._safety = safety
        self._personality = personality
        self._bus = event_bus
        self._settings = settings
        self._show_thinking: bool = settings.get("interface", "show_thinking", False)

        # Derive internal wiring from the high-level objects
        model = model_manager.provider
        personality_prompt = personality.get_system_prompt()

        from homunculus.tools.executor import ToolExecutor

        tool_executor = ToolExecutor(tool_registry)
        tool_definitions = tool_registry.get_tool_definitions()

        # Sub-components
        self._perceiver = Perceiver()
        self._thinker = Thinker(model, memory, personality_prompt)
        self._planner = Planner(model)
        self._actor = Actor(tool_executor.execute, event_bus)
        self._observer = Observer()
        self._learner = Learner(memory, ExperienceConverter())
        self._tool_definitions = tool_definitions

        # Runtime state
        self._state = AgentState.IDLE
        self._running = False
        self._loop_task: asyncio.Task | None = None

    # ------------------------------------------------------------------
    # Public properties (used by CLI, commands, and external code)
    # ------------------------------------------------------------------

    @property
    def state(self) -> AgentState:
        return self._state

    @property
    def model_manager(self) -> ModelManager:
        return self._model_manager

    @property
    def memory(self) -> MemoryBridge:
        return self._memory

    @property
    def tool_registry(self) -> ToolRegistry:
        return self._tool_registry

    @property
    def safety(self) -> SafetyLayer:
        return self._safety

    @property
    def personality(self) -> PersonalityEngine:
        return self._personality

    @property
    def event_bus(self) -> EventBus:
        return self._bus

    @property
    def settings(self) -> Settings:
        return self._settings

    @property
    def show_thinking(self) -> bool:
        return self._show_thinking

    @show_thinking.setter
    def show_thinking(self, value: bool) -> None:
        self._show_thinking = value

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the agent's main loop as a background task."""
        if self._running:
            logger.warning("Agent.start() called but agent is already running")
            return

        self._running = True
        self._loop_task = asyncio.create_task(
            self._main_loop(), name="homunculus-agent-loop"
        )
        logger.info("Homunculus agent started")

    async def stop(self) -> None:
        """Signal the loop to stop and wait for the current cycle to finish."""
        self._running = False
        if self._loop_task and not self._loop_task.done():
            self._loop_task.cancel()
            try:
                await self._loop_task
            except asyncio.CancelledError:
                pass
        self._memory.shutdown()
        self._set_state(AgentState.IDLE)
        logger.info("Homunculus agent stopped")

    async def handle_message(self, content: str, source: str = "user") -> None:
        """Push a user message into the perception queue."""
        perception = Perception(
            input_type=InputType.USER_MESSAGE,
            content=content,
            source=source,
            priority=3,
        )
        self._perceiver.push(perception)
        logger.debug("handle_message: queued perception (qsize=%d)", self._perceiver.pending)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def _main_loop(self) -> None:
        """Continuously poll the perceiver and process each perception."""
        while self._running:
            try:
                perception = await self._perceiver.next()

                if perception is None:
                    self._set_state(AgentState.IDLE)
                    await asyncio.sleep(_IDLE_SLEEP_S)
                    continue

                await self._run_cycle(perception)

            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.exception("Unhandled error in agent main loop")
                await self._bus.emit_async("agent.error", exc)
                await asyncio.sleep(1)

    async def _run_cycle(self, perception: Perception) -> None:
        """Execute one full Perceive→Think→[Plan→Act→Observe→Learn] cycle."""
        cycle = AgentCycle(perception=perception)
        await self._bus.emit_async("agent.cycle.started", cycle)

        try:
            # ── THINK ──────────────────────────────────────────────────
            self._set_state(AgentState.THINKING)
            thought = await self._thinker.think(perception)
            cycle.thought = thought

            if thought.should_act and self._tool_definitions:
                # ── PLAN ───────────────────────────────────────────────
                self._set_state(AgentState.PLANNING)
                plan = await self._planner.plan(thought, self._tool_definitions)
                cycle.plan = plan

                # Safety pre-check
                plan.requires_approval = self._safety.requires_approval(plan)
                plan.estimated_risk = self._safety.assess_risk(plan)

                if plan.steps:
                    # Notify when approval is needed
                    if plan.requires_approval:
                        await self._bus.emit_async("approval_needed", plan)

                    # ── ACT ────────────────────────────────────────────
                    self._set_state(AgentState.ACTING)
                    results = await self._actor.execute(plan)
                    cycle.results = results

                    # Log each action to safety layer
                    for step, result in zip(plan.steps, results):
                        self._safety.log_action(step, result)

                    # ── OBSERVE ────────────────────────────────────────
                    self._set_state(AgentState.OBSERVING)
                    observation = self._observer.observe(plan, results)
                    cycle.observation = observation

                    # ── LEARN ──────────────────────────────────────────
                    self._set_state(AgentState.LEARNING)
                    learning = await self._learner.learn(observation)
                    cycle.learning = learning

                    # Emit memory_stored for each persisted memory
                    for mid in learning.memory_ids:
                        self._bus.emit("memory_stored", mid)

                    if thought.should_respond:
                        reply = await self._generate_action_reply(thought, observation)
                        await self._bus.emit_async("agent.response", reply)
                else:
                    if thought.should_respond:
                        reply = await self._generate_reply(thought)
                        await self._bus.emit_async("agent.response", reply)

            elif thought.should_respond:
                # ── RESPOND ONLY (no tools needed) ─────────────────────
                reply = await self._generate_reply(thought)
                await self._bus.emit_async("agent.response", reply)

                await self._store_conversation_memory(perception.content, reply)

        except Exception as exc:
            logger.exception("Error during agent cycle")
            await self._bus.emit_async("agent.error", exc)
        finally:
            cycle.completed_at = time.time()
            cycle.state = self._state
            await self._bus.emit_async("agent.cycle.completed", cycle)
            self._set_state(AgentState.IDLE)

    # ------------------------------------------------------------------
    # Response generation
    # ------------------------------------------------------------------

    async def _generate_reply(self, thought) -> str:
        """Ask the model to produce a user-facing reply based on thinking."""
        messages = [
            {"role": "user", "content": thought.perception.content}
        ]
        if thought.recalled_memories:
            memory_context = "\n".join(
                f"- {m.content}" for m in thought.recalled_memories[:5]
            )
            messages.insert(
                0,
                {
                    "role": "user",
                    "content": f"[Relevant memories for context]\n{memory_context}",
                },
            )
            messages.insert(1, {"role": "assistant", "content": "Understood."})

        personality_prompt = self._personality.get_system_prompt()
        try:
            return await self._model_manager.provider.chat(
                messages=messages,
                system=personality_prompt or None,
                temperature=0.7,
                max_tokens=2048,
            )
        except Exception:
            logger.exception("Failed to generate reply")
            return "I encountered an error while formulating a response."

    async def _generate_action_reply(self, thought, observation) -> str:
        """Summarise completed actions into a concise user-facing reply."""
        summary = observation.summary
        unexpected = observation.unexpected_effects

        prompt_parts = [
            f"You just completed the following actions:\n{summary}",
        ]
        if unexpected:
            prompt_parts.append(
                f"Unexpected effects observed: {', '.join(unexpected[:3])}"
            )
        prompt_parts.append(
            "Write a concise, friendly reply to the user describing what you did "
            "and what happened.  Do not re-list every step verbatim; synthesise."
        )

        messages = [{"role": "user", "content": "\n\n".join(prompt_parts)}]
        personality_prompt = self._personality.get_system_prompt()
        try:
            return await self._model_manager.provider.chat(
                messages=messages,
                system=personality_prompt or None,
                temperature=0.5,
                max_tokens=1024,
            )
        except Exception:
            logger.exception("Failed to generate action reply")
            return summary

    # ------------------------------------------------------------------
    # Memory helpers
    # ------------------------------------------------------------------

    async def _store_conversation_memory(
        self, user_content: str, agent_reply: str
    ) -> None:
        """Persist a conversational exchange as a memory."""
        converter = ExperienceConverter()
        content, importance, metadata = converter.from_conversation(
            user_content, agent_reply
        )
        await self._memory.remember(
            content=content,
            importance=importance,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Internal state management
    # ------------------------------------------------------------------

    def _set_state(self, new_state: AgentState) -> None:
        if self._state != new_state:
            self._state = new_state
            self._bus.emit("agent.state.changed", new_state)
            logger.debug("Agent state → %s", new_state.value)
