"""Planner - converts a Thought into a concrete, tool-backed ActionPlan."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import (
    ActionPlan,
    ActionRisk,
    ActionStep,
    Thought,
    ToolCallRequest,
    ToolCallResult,
)

if TYPE_CHECKING:
    from homunculus.models.interface import ModelInterface

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompt constants
# ---------------------------------------------------------------------------

_PLANNER_SYSTEM = """\
You are the planning module of an autonomous AI agent.

Given the agent's current reasoning and a set of available tools, select the
minimal sequence of tool calls that will accomplish the goal described in the
reasoning.  Prefer fewer, well-targeted calls over many speculative ones.

Use the tool-calling interface provided — do NOT invent tool names.
If no tools are needed, call nothing and return an empty tool list.
"""


class Planner:
    """Converts a Thought into an ActionPlan by choosing tools via the AI."""

    def __init__(self, model: ModelInterface) -> None:
        self._model = model

    async def plan(
        self,
        thought: Thought,
        tool_definitions: list[dict],
    ) -> ActionPlan:
        """Ask the AI to select tools and build a sequenced ActionPlan."""
        if not tool_definitions:
            logger.debug("Planner: no tools available, returning empty plan")
            return ActionPlan(
                thought=thought,
                goal=self._extract_goal(thought),
                steps=[],
            )

        goal = self._extract_goal(thought)
        messages = [
            {
                "role": "user",
                "content": (
                    f"Goal: {goal}\n\n"
                    f"Reasoning:\n{thought.reasoning}\n\n"
                    "Select the tools needed to accomplish this goal."
                ),
            }
        ]

        try:
            tool_result: ToolCallResult = await self._model.chat_with_tools(
                messages=messages,
                tools=tool_definitions,
                system=_PLANNER_SYSTEM,
                temperature=0.2,
            )
        except Exception:
            logger.exception("Planner model call failed; returning empty plan")
            return ActionPlan(thought=thought, goal=goal, steps=[])

        steps = self._build_steps(tool_result.tool_calls, tool_definitions)
        overall_risk = self._aggregate_risk(steps)

        plan = ActionPlan(
            thought=thought,
            goal=goal,
            steps=steps,
            requires_approval=overall_risk in (ActionRisk.HIGH, ActionRisk.CRITICAL),
            estimated_risk=overall_risk,
        )

        logger.debug(
            "Plan: goal=%r steps=%d risk=%s requires_approval=%s",
            goal[:60],
            len(steps),
            overall_risk.value,
            plan.requires_approval,
        )
        return plan

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _extract_goal(self, thought: Thought) -> str:
        """Derive a one-line goal from the reasoning text."""
        reasoning = thought.reasoning.strip()
        # Use the first non-empty sentence as the goal summary
        for sentence in reasoning.split("."):
            sentence = sentence.strip()
            if len(sentence) > 10:
                return sentence[:200]
        return reasoning[:200] or thought.perception.content[:200]

    def _build_steps(
        self,
        tool_calls: list[ToolCallRequest],
        definitions: list[dict],
    ) -> list[ActionStep]:
        """Map ToolCallRequests to ActionSteps, enriching with definition metadata."""
        # Build a lookup from tool name to its definition
        def_map: dict[str, dict] = {d.get("name", ""): d for d in definitions}
        steps: list[ActionStep] = []

        for call in tool_calls:
            definition = def_map.get(call.tool_name, {})
            risk = self._resolve_risk(definition.get("risk_level", "safe"))
            description = definition.get("description", "")

            # Separate tool_name and action: some tools encode action as a
            # parameter; others embed it in the name as "tool.action".
            if "." in call.tool_name:
                tool_name, action = call.tool_name.split(".", 1)
            else:
                tool_name = call.tool_name
                action = call.arguments.pop("action", call.tool_name)

            step = ActionStep(
                tool_name=tool_name,
                action=action,
                parameters=call.arguments,
                risk_level=risk,
                description=description,
            )
            steps.append(step)

        return steps

    def _resolve_risk(self, raw: str) -> ActionRisk:
        try:
            return ActionRisk(raw.lower())
        except ValueError:
            return ActionRisk.LOW

    def _aggregate_risk(self, steps: list[ActionStep]) -> ActionRisk:
        if not steps:
            return ActionRisk.SAFE
        order = [
            ActionRisk.SAFE,
            ActionRisk.LOW,
            ActionRisk.MEDIUM,
            ActionRisk.HIGH,
            ActionRisk.CRITICAL,
        ]
        return max(steps, key=lambda s: order.index(s.risk_level)).risk_level
