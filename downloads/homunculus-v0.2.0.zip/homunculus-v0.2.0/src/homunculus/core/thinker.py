"""Thinker - the cognitive core that interprets perceptions via an AI model."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from homunculus.core.types import Perception, Thought
from homunculus.memory.recall import RecallStrategy

if TYPE_CHECKING:
    from homunculus.memory.bridge import MemoryBridge
    from homunculus.models.interface import ModelInterface

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompt constants
# ---------------------------------------------------------------------------

_THINKER_SYSTEM = """\
You are the cognitive core of an autonomous AI agent called Homunculus.
Your job is to THINK — not to respond to the user directly.

Given a perception (what just happened or was said) and relevant memories,
produce a structured internal monologue that decides what the agent should do.

Respond ONLY with this JSON structure — no markdown fences, no extra text:
{
  "reasoning": "<your step-by-step reasoning>",
  "should_act": <true if tools/actions are needed, false otherwise>,
  "should_respond": <true if a reply to the user is needed, false otherwise>,
  "confidence": <float 0.0-1.0 how certain you are>
}

Rules:
- should_act = true only when a concrete task needs tools (file ops, searches,
  shell commands, API calls, etc.)
- should_respond = true when the user or system expects a reply
- Both can be true simultaneously (act, then report back)
- confidence reflects how clear the situation is to you
"""

_CONTEXT_TEMPLATE = """\
=== CURRENT SITUATION ===
Source: {source}
Type: {input_type}
Content: {content}

{memory_section}\
{introspection_section}\
"""

_MEMORY_TEMPLATE = """\
=== RELEVANT MEMORIES ({count}) ===
{entries}

"""

_INTROSPECTION_TEMPLATE = """\
=== SELF-KNOWLEDGE ===
Confidence: {confidence:.0%}
Coverage gaps: {gaps}

"""


class Thinker:
    """Processes a Perception into a Thought using an AI model and memories."""

    def __init__(
        self,
        model: ModelInterface,
        memory: MemoryBridge,
        personality_prompt: str = "",
    ) -> None:
        self._model = model
        self._memory = memory
        self._recall = RecallStrategy()
        self._personality_prompt = personality_prompt

    async def think(self, perception: Perception) -> Thought:
        """Analyse a perception and return a structured Thought."""
        # 1. Recall relevant memories in parallel with introspection
        memories = await self._recall.for_thinking(self._memory, perception)
        introspection = await self._memory.introspect(perception.content[:200])

        # 2. Build the context block for the model
        context = self._build_context(perception, memories, introspection)

        # 3. Compose the system prompt (personality + thinker instructions)
        system = (
            f"{self._personality_prompt}\n\n{_THINKER_SYSTEM}"
            if self._personality_prompt
            else _THINKER_SYSTEM
        )

        # 4. Ask the model to think
        messages = [{"role": "user", "content": context}]
        try:
            raw = await self._model.chat(
                messages=messages,
                system=system,
                temperature=0.3,  # low temp for consistent structured output
                max_tokens=1024,
            )
            parsed = self._parse_response(raw)
        except Exception:
            logger.exception("Thinker model call failed; using safe defaults")
            parsed = {
                "reasoning": "Model call failed; defaulting to respond-only mode.",
                "should_act": False,
                "should_respond": True,
                "confidence": 0.0,
            }

        thought = Thought(
            perception=perception,
            recalled_memories=memories,
            reasoning=parsed.get("reasoning", ""),
            confidence=float(parsed.get("confidence", 0.0)),
            should_act=bool(parsed.get("should_act", False)),
            should_respond=bool(parsed.get("should_respond", True)),
        )

        logger.debug(
            "Thought: should_act=%s should_respond=%s confidence=%.2f",
            thought.should_act,
            thought.should_respond,
            thought.confidence,
        )
        return thought

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_context(
        self,
        perception: Perception,
        memories: list,
        introspection: dict,
    ) -> str:
        memory_section = ""
        if memories:
            entries = "\n".join(
                f"[zone={m.zone} score={m.score:.2f}] {m.content}"
                for m in memories
            )
            memory_section = _MEMORY_TEMPLATE.format(
                count=len(memories), entries=entries
            )

        introspection_section = ""
        if introspection.get("confidence", 0) > 0 or introspection.get("gaps"):
            gaps = ", ".join(introspection.get("gaps", [])) or "none identified"
            introspection_section = _INTROSPECTION_TEMPLATE.format(
                confidence=introspection.get("confidence", 0.0),
                gaps=gaps,
            )

        return _CONTEXT_TEMPLATE.format(
            source=perception.source or "unknown",
            input_type=perception.input_type.value,
            content=perception.content,
            memory_section=memory_section,
            introspection_section=introspection_section,
        )

    def _parse_response(self, raw: str) -> dict:
        """Parse JSON from the model response, tolerating minor formatting."""
        import json
        import re

        # Strip markdown fences if the model added them despite instructions
        cleaned = re.sub(r"```(?:json)?\s*", "", raw).strip().rstrip("`").strip()

        # Find the first complete JSON object in the response
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            raise ValueError(f"No JSON object found in model response: {raw[:200]}")

        return json.loads(match.group())
