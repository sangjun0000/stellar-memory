"""Create desktop shortcuts for each OS."""

from __future__ import annotations

import platform
import subprocess
from pathlib import Path


def create_desktop_shortcut(install_dir: Path, system: str | None = None) -> bool:
    if system is None:
        system = platform.system()

    desktop = _get_desktop_path(system)
    if not desktop or not desktop.exists():
        print(f"  [WARN] Desktop not found at {desktop}")
        return False

    if system == "Windows":
        return _create_windows_shortcut(install_dir, desktop)
    elif system == "Darwin":
        return _create_macos_shortcut(install_dir, desktop)
    else:
        return _create_linux_shortcut(install_dir, desktop)


def _get_desktop_path(system: str) -> Path | None:
    if system == "Windows":
        desktop = Path.home() / "Desktop"
        if not desktop.exists():
            # Try OneDrive desktop
            onedrive = Path.home() / "OneDrive" / "Desktop"
            if onedrive.exists():
                return onedrive
            # Korean Windows
            kr_desktop = Path.home() / "\ubc14\ud0d5 \ud654\uba74"
            if kr_desktop.exists():
                return kr_desktop
        return desktop
    elif system == "Darwin":
        return Path.home() / "Desktop"
    else:
        # XDG
        try:
            result = subprocess.run(
                ["xdg-user-dir", "DESKTOP"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                return Path(result.stdout.strip())
        except FileNotFoundError:
            pass
        return Path.home() / "Desktop"


def _create_windows_shortcut(install_dir: Path, desktop: Path) -> bool:
    """Create .lnk shortcut using PowerShell."""
    shortcut_path = desktop / "Homunculus.lnk"
    target = install_dir / "launch.bat"
    icon = install_dir / "assets" / "icon.ico"
    working_dir = install_dir

    ps_script = f'''
$ws = New-Object -ComObject WScript.Shell
$shortcut = $ws.CreateShortcut("{shortcut_path}")
$shortcut.TargetPath = "{target}"
$shortcut.WorkingDirectory = "{working_dir}"
$shortcut.Description = "Homunculus - Autonomous AI Agent"
$shortcut.WindowStyle = 1
if (Test-Path "{icon}") {{
    $shortcut.IconLocation = "{icon}"
}}
$shortcut.Save()
'''
    try:
        subprocess.run(
            ["powershell", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
            check=True, capture_output=True,
        )
        print(f"  -> Desktop shortcut created: {shortcut_path}")
        return True
    except Exception as e:
        print(f"  [WARN] Could not create shortcut: {e}")
        return False


def _create_macos_shortcut(install_dir: Path, desktop: Path) -> bool:
    """Create .command file on macOS."""
    shortcut_path = desktop / "Homunculus.command"
    launcher = install_dir / "launch.sh"

    shortcut_path.write_text(
        f'#!/bin/bash\n"{launcher}"\n',
        encoding="utf-8",
    )
    shortcut_path.chmod(0o755)
    print(f"  -> Desktop shortcut created: {shortcut_path}")
    return True


def _create_linux_shortcut(install_dir: Path, desktop: Path) -> bool:
    """Create .desktop file on Linux."""
    shortcut_path = desktop / "Homunculus.desktop"
    launcher = install_dir / "launch.sh"
    icon = install_dir / "assets" / "icon.ico"

    shortcut_path.write_text(
        f"""[Desktop Entry]
Name=Homunculus
Comment=Autonomous AI Agent
Exec="{launcher}"
Icon={icon}
Type=Application
Terminal=true
Categories=Utility;AI;
""",
        encoding="utf-8",
    )
    shortcut_path.chmod(0o755)
    print(f"  -> Desktop shortcut created: {shortcut_path}")
    return True
