"""Homunculus unified installer -- 5-step setup wizard."""

from __future__ import annotations

import platform
import shutil
import subprocess
import sys
from pathlib import Path

# installer.py runs with SYSTEM Python (not venv).
# Add source directory to path so we can import homunculus modules.
_THIS_DIR = Path(__file__).resolve().parent
_SRC_DIR = _THIS_DIR.parent
if str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))


def main(source_dir: str) -> None:
    source = Path(source_dir)
    system = platform.system()  # "Windows", "Darwin", "Linux"

    print_header()

    # Step 1: Install path
    install_dir = step_install_path(system)

    # Step 2: Copy files
    copy_project(source, install_dir)

    # Step 3: Create venv + install
    create_venv(install_dir)
    pip_install(install_dir)

    # Step 4: Run setup wizard (AI model, scope, safety)
    run_setup_wizard(install_dir)

    # Step 5: Create launcher + desktop shortcut
    create_launcher(install_dir, system)
    create_shortcut(install_dir, system)

    print_complete(install_dir, system)


def print_header() -> None:
    print()
    print("  Homunculus Setup Wizard")
    print("  " + "\u2500" * 35)
    print()


def step_install_path(system: str) -> Path:
    """Step 1/5: Choose install location."""
    print("  [Step 1/5] Install Location")
    print()

    default = Path.home() / "Homunculus"

    user_input = input(f"  Install to [{default}]: ").strip()
    install_dir = Path(user_input) if user_input else default

    install_dir.mkdir(parents=True, exist_ok=True)
    print(f"  -> {install_dir}")
    print()
    return install_dir


def copy_project(source: Path, dest: Path) -> None:
    """Copy source files to install directory."""
    print("  Copying files...")

    for item in ["src", "pyproject.toml", "launch.bat", "launch.sh", "assets"]:
        src = source / item
        dst = dest / item
        if src.is_dir():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        elif src.is_file():
            shutil.copy2(src, dst)

    print("  -> Files copied.")
    print()


def create_venv(install_dir: Path) -> None:
    """Create Python virtual environment."""
    print("  Creating virtual environment...")
    venv_dir = install_dir / ".venv"

    if venv_dir.exists():
        shutil.rmtree(venv_dir)

    python = sys.executable
    subprocess.run(
        [python, "-m", "venv", str(venv_dir)],
        check=True,
    )
    print("  -> venv created.")
    print()


def pip_install(install_dir: Path) -> None:
    """Install homunculus into venv."""
    print("  Installing dependencies (this may take a minute)...")

    system = platform.system()
    if system == "Windows":
        pip = install_dir / ".venv" / "Scripts" / "pip"
    else:
        pip = install_dir / ".venv" / "bin" / "pip"

    subprocess.run(
        [str(pip), "install", str(install_dir), "-q"],
        check=True,
    )
    print("  -> Dependencies installed.")
    print()


def run_setup_wizard(install_dir: Path) -> None:
    """Run the setup wizard (model, scope, safety)."""
    system = platform.system()
    if system == "Windows":
        python = install_dir / ".venv" / "Scripts" / "python"
    else:
        python = install_dir / ".venv" / "bin" / "python"

    subprocess.run(
        [str(python), "-m", "homunculus.installer_wizard", str(install_dir)],
        check=True,
    )


def create_launcher(install_dir: Path, system: str) -> None:
    """Ensure launch scripts have correct paths."""
    if system == "Windows":
        launcher = install_dir / "launch.bat"
        launcher.write_text(
            '@echo off\n'
            f'cd /d "{install_dir}"\n'
            'call .venv\\Scripts\\activate\n'
            'python -m homunculus\n',
            encoding="utf-8",
        )
    else:
        launcher = install_dir / "launch.sh"
        launcher.write_text(
            '#!/usr/bin/env bash\n'
            f'cd "{install_dir}"\n'
            'source .venv/bin/activate\n'
            'python -m homunculus\n',
            encoding="utf-8",
        )
        launcher.chmod(0o755)


def create_shortcut(install_dir: Path, system: str) -> None:
    """Create desktop shortcut."""
    from homunculus.shortcut import create_desktop_shortcut
    create_desktop_shortcut(install_dir, system)


def print_complete(install_dir: Path, system: str) -> None:
    print()
    print("  \u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557")
    print("  \u2551  Installation Complete!                \u2551")
    print("  \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d")
    print()
    print(f"  Installed to: {install_dir}")
    print()
    print("  A shortcut has been created on your Desktop.")
    print("  Double-click 'Homunculus' to start!")
    print()


if __name__ == "__main__":
    source_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    try:
        main(source_dir)
    except Exception as e:
        print(f"\n  [ERROR] {e}")
        input("\n  Press Enter to close...")
        sys.exit(1)
