"""Default configuration values for Homunculus."""

from __future__ import annotations

DEFAULT_CONFIG = {
    "homunculus": {
        "name": "Homunculus",
        "version": "0.2.0",
        "safety_level": "normal",  # strict | normal | permissive
        "log_level": "INFO",
        "log_path": "logs/",
        "data_path": "data/",
    },
    "model": {
        "provider": "ollama",
        "model_id": "llama3.2:3b",
        "temperature": 0.7,
        "max_tokens": 4096,
        "timeout": 60,
    },
    "memory": {
        "db_path": "data/homunculus_brain.db",
        "w_recall": 0.25,
        "w_freshness": 0.25,
        "w_arbitrary": 0.20,
        "w_context": 0.15,
        "w_emotion": 0.15,
        "emotion_enabled": True,
        "graph_enabled": True,
        "graph_auto_link_threshold": 0.65,
        "metacognition_enabled": True,
        "self_learning_enabled": True,
        "reasoning_enabled": True,
        "reorbit_interval": 300,
    },
    "tools": {
        "enabled": ["shell", "filesystem"],
        "plugin_dir": "plugins/",
        "shell_timeout": 30,
        "shell_blocked_commands": [
            "rm -rf /",
            "format",
            "mkfs",
            "dd if=/dev/zero",
            "shutdown",
            "reboot",
        ],
        "filesystem_allowed_dirs": [],  # empty = current dir and below
    },
    "personality": {
        "profile": "jarvis",
        "language": "auto",
    },
    "interface": {
        "show_thinking": False,
        "show_memory_stats": True,
    },
}
