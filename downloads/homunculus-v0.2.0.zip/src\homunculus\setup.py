"""Interactive setup wizard for first-time Homunculus configuration."""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

from homunculus.config.settings import Settings
from homunculus.models.manager import ModelManager
from homunculus.models.registry import ModelRegistry

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Confirm, IntPrompt, Prompt

    HAS_RICH = True
except ImportError:
    HAS_RICH = False


def _input(prompt: str, default: str = "") -> str:
    if HAS_RICH:
        return Prompt.ask(prompt, default=default)
    val = input(f"{prompt} [{default}]: " if default else f"{prompt}: ")
    return val.strip() or default


def _select(prompt: str, options: list[str]) -> int:
    print(f"\n{prompt}")
    for i, opt in enumerate(options, 1):
        print(f"  {i}. {opt}")
    while True:
        try:
            choice = int(input("\nSelect (number): "))
            if 1 <= choice <= len(options):
                return choice - 1
        except (ValueError, EOFError):
            pass
        print("Invalid selection, try again.")


async def run_setup() -> dict:
    """Run interactive setup. Returns config dict."""
    console = Console() if HAS_RICH else None

    if console:
        console.print(Panel(
            "[bold blue]Welcome to Homunculus![/bold blue]\n"
            "Let's set up your AI brain.",
            title="Setup",
        ))
    else:
        print("=== Welcome to Homunculus! ===")
        print("Let's set up your AI brain.\n")

    # Step 1: Choose execution mode
    mode_idx = _select(
        "How would you like to run your AI?",
        [
            "Local (Free, Private, Offline) - requires Ollama",
            "Cloud API (Fast, Powerful) - requires API key",
            "Both (Smart routing)",
        ],
    )

    config: dict = {
        "model": {},
        "homunculus": {"safety_level": "normal"},
    }

    registry = ModelRegistry()

    if mode_idx in (0, 2):  # Local
        local_models = registry.list_models("ollama")
        options = [
            f"{m.display_name} ({m.download_size_gb}GB, "
            f"{'Tool support' if m.supports_tools else 'No tools'})"
            for m in local_models
        ]
        model_idx = _select("Select a local model:", options)
        selected = local_models[model_idx]
        config["model"]["provider"] = "ollama"
        config["model"]["model_id"] = selected.model_id

        print(f"\nSelected: {selected.display_name}")
        print("Make sure Ollama is installed and running (https://ollama.com)")
        print(f"Run: ollama pull {selected.model_id}")

    if mode_idx in (1, 2):  # API
        api_providers = [
            ("anthropic", "Anthropic Claude (Recommended)"),
            ("openai", "OpenAI GPT"),
            ("deepseek", "DeepSeek (Affordable)"),
            ("google", "Google Gemini"),
        ]
        prov_idx = _select(
            "Select your AI provider:",
            [name for _, name in api_providers],
        )
        provider = api_providers[prov_idx][0]

        api_models = registry.list_models(provider)
        if api_models:
            options = [f"{m.display_name} ({m.model_id})" for m in api_models]
            model_idx = _select("Select a model:", options)
            selected = api_models[model_idx]
        else:
            selected = None

        if mode_idx == 1:  # API only
            config["model"]["provider"] = provider
            config["model"]["model_id"] = selected.model_id if selected else ""

        env_vars = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
            "google": "GOOGLE_API_KEY",
        }
        env_var = env_vars.get(provider, "")
        existing_key = os.environ.get(env_var, "")
        if not existing_key:
            key = _input(f"Enter your {provider} API key")
            if key:
                print(f"\nSet this in your environment: {env_var}={key[:8]}...")
                os.environ[env_var] = key

    # Step 2: Safety level
    safety_idx = _select(
        "Safety level for autonomous actions:",
        [
            "Strict - ask approval for most actions",
            "Normal (Recommended) - ask for risky actions only",
            "Permissive - minimal confirmations",
        ],
    )
    config["homunculus"]["safety_level"] = ["strict", "normal", "permissive"][safety_idx]

    # Write config
    config_path = Path("homunculus.toml")
    _write_toml(config_path, config)
    print(f"\nConfig saved to {config_path}")
    print("\nSetup complete! Run 'homunculus' to start.\n")

    return config


def _write_toml(path: Path, data: dict) -> None:
    lines = []
    for section, values in data.items():
        lines.append(f"[{section}]")
        for key, value in values.items():
            if isinstance(value, str):
                lines.append(f'{key} = "{value}"')
            elif isinstance(value, bool):
                lines.append(f"{key} = {'true' if value else 'false'}")
            elif isinstance(value, (int, float)):
                lines.append(f"{key} = {value}")
            elif isinstance(value, list):
                items = ", ".join(f'"{v}"' for v in value)
                lines.append(f"{key} = [{items}]")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
